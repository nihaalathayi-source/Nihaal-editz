package com.example.ui.editor

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Animation
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.data.local.TimelineClipEntity
import com.example.ui.theme.DarkBackground
import com.example.ui.theme.DarkCardBorder
import com.example.ui.theme.DarkSurfaceVariant
import com.example.ui.theme.EditorAccentYellow
import com.example.ui.theme.EditorPrimary
import com.example.ui.theme.EditorSecondary
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextSecondary
import kotlin.math.roundToInt

@Composable
fun TimelineView(
    clips: List<TimelineClipEntity>,
    selectedClipId: Long?,
    currentPositionMs: Long,
    pixelsPerSecond: Float,
    totalDurationMs: Long,
    onSeekTo: (Long) -> Unit,
    onSelectClip: (Long?) -> Unit,
    onTrimIn: (Long, Long) -> Unit,
    onTrimOut: (Long, Long) -> Unit,
    onCommitTrim: () -> Unit,
    onSplitTransitionClick: ((Long) -> Unit)? = null,
    modifier: Modifier = Modifier
) {
    val scrollState = rememberScrollState()
    val totalSeconds = (totalDurationMs / 1000f).coerceAtLeast(5f)
    val timelineWidthPx = totalSeconds * pixelsPerSecond + 160f
    val timelineWidthDp = (timelineWidthPx / 2.5f).dp.coerceAtLeast(360.dp)

    // Smooth scroll to follow playhead when playing
    LaunchedEffect(currentPositionMs) {
        val playheadPx = (currentPositionMs / 1000f) * pixelsPerSecond
        if (playheadPx > scrollState.value + 600 || playheadPx < scrollState.value) {
            scrollState.animateScrollTo(playheadPx.toInt().coerceAtLeast(0))
        }
    }

    Box(
        modifier = modifier
            .fillMaxWidth()
            .height(130.dp)
            .background(Color(0xFF0C0E14))
            .border(width = 1.dp, color = DarkCardBorder)
            .testTag("timeline_container")
    ) {
        // Horizontal Scroll Area
        Box(
            modifier = Modifier
                .fillMaxSize()
                .horizontalScroll(scrollState)
        ) {
            Box(
                modifier = Modifier
                    .width(timelineWidthDp)
                    .fillMaxHeight()
            ) {
                // 1. Time Ruler at Top
                TimeRuler(
                    pixelsPerSecond = pixelsPerSecond,
                    totalSeconds = totalSeconds,
                    onSeek = onSeekTo,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(24.dp)
                )

                // 2. Video Track with Clips
                Row(
                    modifier = Modifier
                        .padding(top = 28.dp, bottom = 12.dp)
                        .fillMaxWidth()
                        .height(68.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    clips.forEachIndexed { index, clip ->
                        val isSelected = clip.id == selectedClipId
                        val rawDurationMs = (clip.outMs - clip.inMs).coerceAtLeast(100L)
                        val speed = if (clip.speed > 0f) clip.speed else 1f
                        val clipDurationSecs = (rawDurationMs / speed) / 1000f
                        val clipWidthDp = (clipDurationSecs * pixelsPerSecond / 2.5f).dp.coerceAtLeast(42.dp)

                        TimelineClipItem(
                            clip = clip,
                            isSelected = isSelected,
                            widthDp = clipWidthDp,
                            pixelsPerSecond = pixelsPerSecond,
                            onClick = { onSelectClip(clip.id) },
                            onTrimIn = { newInMs -> onTrimIn(clip.id, newInMs) },
                            onTrimOut = { newOutMs -> onTrimOut(clip.id, newOutMs) },
                            onCommitTrim = onCommitTrim
                        )

                        // Split Transition Node between clips
                        if (index < clips.lastIndex) {
                            val nextClip = clips[index + 1]
                            val hasTransition = !nextClip.transitionName.isNullOrEmpty()
                            Box(
                                modifier = Modifier
                                    .padding(horizontal = 2.dp)
                                    .size(24.dp)
                                    .clip(RoundedCornerShape(6.dp))
                                    .background(if (hasTransition) EditorPrimary else Color(0xFF202636))
                                    .border(
                                        1.dp,
                                        if (hasTransition) Color.White else DarkCardBorder,
                                        RoundedCornerShape(6.dp)
                                    )
                                    .clickable { onSplitTransitionClick?.invoke(nextClip.id) }
                                    .testTag("split_transition_button_$index"),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Animation,
                                    contentDescription = "Split Transition",
                                    tint = if (hasTransition) Color.White else TextSecondary,
                                    modifier = Modifier.size(13.dp)
                                )
                            }
                        }
                    }
                }

                // 3. Playhead Vertical Line with Glow
                val playheadOffsetPx = (currentPositionMs / 1000f) * (pixelsPerSecond / 2.5f)
                Box(
                    modifier = Modifier
                        .offset { IntOffset(playheadOffsetPx.dp.roundToPx(), 0) }
                        .width(2.dp)
                        .fillMaxHeight()
                        .background(Color.White)
                        .testTag("playhead_indicator")
                ) {
                    // Playhead Top Cap
                    Box(
                        modifier = Modifier
                            .size(10.dp)
                            .offset(x = (-4).dp, y = 0.dp)
                            .clip(CircleShape)
                            .background(Color.White)
                    )
                }
            }
        }
    }
}

@Composable
fun TimeRuler(
    pixelsPerSecond: Float,
    totalSeconds: Float,
    onSeek: (Long) -> Unit,
    modifier: Modifier = Modifier
) {
    Canvas(
        modifier = modifier
            .pointerInput(pixelsPerSecond) {
                detectTapGestures { offset ->
                    val seekSecs = offset.x / (pixelsPerSecond / 2.5f)
                    onSeek((seekSecs * 1000f).toLong().coerceAtLeast(0L))
                }
            }
            .pointerInput(pixelsPerSecond) {
                detectDragGestures { change, _ ->
                    change.consume()
                    val seekSecs = change.position.x / (pixelsPerSecond / 2.5f)
                    onSeek((seekSecs * 1000f).toLong().coerceAtLeast(0L))
                }
            }
            .testTag("time_ruler")
    ) {
        val stepSec = if (pixelsPerSecond < 30f) 5 else if (pixelsPerSecond < 70f) 2 else 1
        val maxSecs = totalSeconds.toInt() + 5

        for (sec in 0..maxSecs step stepSec) {
            val x = sec * (pixelsPerSecond / 2.5f)
            // Major tick
            drawLine(
                color = Color(0xFF6B7285),
                start = Offset(x, 0f),
                end = Offset(x, 14f),
                strokeWidth = 1.5f
            )
            // Minor tick
            val midX = x + (stepSec * (pixelsPerSecond / 2.5f) / 2f)
            drawLine(
                color = Color(0xFF404756),
                start = Offset(midX, 4f),
                end = Offset(midX, 10f),
                strokeWidth = 1f
            )
        }
    }
}

@Composable
fun TimelineClipItem(
    clip: TimelineClipEntity,
    isSelected: Boolean,
    widthDp: androidx.compose.ui.unit.Dp,
    pixelsPerSecond: Float,
    onClick: () -> Unit,
    onTrimIn: (Long) -> Unit,
    onTrimOut: (Long) -> Unit,
    onCommitTrim: () -> Unit
) {
    Box(
        modifier = Modifier
            .width(widthDp)
            .fillMaxHeight()
            .padding(horizontal = 1.dp)
            .clip(RoundedCornerShape(6.dp))
            .background(Color(0xFF1B2232))
            .border(
                width = if (isSelected) 2.dp else 1.dp,
                color = if (isSelected) Color.White else DarkCardBorder,
                shape = RoundedCornerShape(6.dp)
            )
            .clickable(onClick = onClick)
            .testTag("clip_item_${clip.id}")
    ) {
        // Background thumbnail or gradient pattern
        if (!clip.mediaUri.startsWith("sample://") && clip.mediaUri.isNotEmpty()) {
            AsyncImage(
                model = clip.mediaUri,
                contentDescription = null,
                contentScale = ContentScale.Crop,
                modifier = Modifier
                    .fillMaxSize()
                    .clip(RoundedCornerShape(6.dp))
            )
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color.Black.copy(alpha = 0.4f))
            )
        }

        // Clip Info
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = if (isSelected) 16.dp else 6.dp, vertical = 4.dp)
        ) {
            Text(
                text = clip.mediaName,
                color = Color.White,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                maxLines = 1
            )
            val durationSecs = (clip.outMs - clip.inMs) / 1000f
            Text(
                text = String.format(java.util.Locale.US, "%.1fs", durationSecs),
                color = EditorAccentYellow,
                fontSize = 10.sp,
                fontWeight = FontWeight.Medium
            )
        }

        // Interactive Left & Right Trim Handles when Selected
        if (isSelected) {
            // Left Trim Handle (In point)
            Box(
                modifier = Modifier
                    .align(Alignment.CenterStart)
                    .width(14.dp)
                    .fillMaxHeight()
                    .background(Color.White)
                    .pointerInput(clip.id) {
                        detectDragGestures(
                            onDragEnd = { onCommitTrim() }
                        ) { change, dragAmount ->
                            change.consume()
                            val deltaSecs = dragAmount.x / (pixelsPerSecond / 2.5f)
                            val deltaMs = (deltaSecs * 1000f).toLong()
                            onTrimIn(clip.inMs + deltaMs)
                        }
                    }
                    .testTag("trim_handle_left_${clip.id}"),
                contentAlignment = Alignment.Center
            ) {
                Box(
                    modifier = Modifier
                        .width(2.dp)
                        .height(18.dp)
                        .background(Color(0xFF333333))
                )
            }

            // Right Trim Handle (Out point)
            Box(
                modifier = Modifier
                    .align(Alignment.CenterEnd)
                    .width(14.dp)
                    .fillMaxHeight()
                    .background(Color.White)
                    .pointerInput(clip.id) {
                        detectDragGestures(
                            onDragEnd = { onCommitTrim() }
                        ) { change, dragAmount ->
                            change.consume()
                            val deltaSecs = dragAmount.x / (pixelsPerSecond / 2.5f)
                            val deltaMs = (deltaSecs * 1000f).toLong()
                            onTrimOut(clip.outMs + deltaMs)
                        }
                    }
                    .testTag("trim_handle_right_${clip.id}"),
                contentAlignment = Alignment.Center
            ) {
                Box(
                    modifier = Modifier
                        .width(2.dp)
                        .height(18.dp)
                        .background(Color(0xFF333333))
                )
            }
        }
    }
}
