package com.example.ui.home

import android.app.Application
import android.net.Uri
import android.media.MediaMetadataRetriever
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.AppDatabase
import com.example.data.local.ProjectEntity
import com.example.data.local.TimelineClipEntity
import com.example.data.model.AspectRatio
import com.example.data.model.MediaItem
import com.example.data.model.SampleMediaProvider
import com.example.data.repository.ProjectRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

enum class HomeTab { HOME, PROJECTS, TEMPLATES, SETTINGS }
enum class MediaFilter { ALL, VIDEOS, PHOTOS }

data class HomeUiState(
    val activeTab: HomeTab = HomeTab.HOME,
    val mediaFilter: MediaFilter = MediaFilter.ALL,
    val showMediaPicker: Boolean = false,
    val mediaPickerFilter: MediaFilter = MediaFilter.ALL,
    val selectedMedia: List<MediaItem> = emptyList(),
    val availableMedia: List<MediaItem> = emptyList(),
    val activeProject: ProjectEntity? = null,
    val activeClips: List<TimelineClipEntity> = emptyList(),
    val isTamil: Boolean = false,
    val toastMessage: String? = null
)

class HomeViewModel(application: Application) : AndroidViewModel(application) {
    private val repository: ProjectRepository

    init {
        val db = AppDatabase.getDatabase(application)
        repository = ProjectRepository(db.projectDao())
    }

    val projects: StateFlow<List<ProjectEntity>> = repository.allProjects
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    private val _uiState = MutableStateFlow(
        HomeUiState(
            availableMedia = SampleMediaProvider.sampleVideos + SampleMediaProvider.samplePhotos
        )
    )
    val uiState: StateFlow<HomeUiState> = _uiState.asStateFlow()

    fun setTab(tab: HomeTab) {
        _uiState.value = _uiState.value.copy(activeTab = tab)
    }

    fun setMediaFilter(filter: MediaFilter) {
        _uiState.value = _uiState.value.copy(mediaFilter = filter)
    }

    fun toggleLanguage() {
        _uiState.value = _uiState.value.copy(isTamil = !_uiState.value.isTamil)
    }

    fun openMediaPicker(filter: MediaFilter = MediaFilter.ALL) {
        _uiState.value = _uiState.value.copy(
            showMediaPicker = true,
            mediaPickerFilter = filter,
            selectedMedia = emptyList()
        )
    }

    fun closeMediaPicker() {
        _uiState.value = _uiState.value.copy(
            showMediaPicker = false,
            selectedMedia = emptyList()
        )
    }

    fun setPickerFilter(filter: MediaFilter) {
        _uiState.value = _uiState.value.copy(mediaPickerFilter = filter)
    }

    fun toggleMediaItemSelection(item: MediaItem) {
        val current = _uiState.value.selectedMedia.toMutableList()
        val existingIndex = current.indexOfFirst { it.id == item.id }
        if (existingIndex >= 0) {
            current.removeAt(existingIndex)
        } else {
            current.add(item)
        }
        _uiState.value = _uiState.value.copy(selectedMedia = current)
    }

    fun addDeviceMediaUris(uris: List<Uri>, isVideo: Boolean) {
        viewModelScope.launch(Dispatchers.IO) {
            val newItems = uris.mapIndexed { index, uri ->
                val detectedVideo = getApplication<Application>().contentResolver.getType(uri)?.startsWith("video")
                    ?: isVideo
                val durationMs = if (detectedVideo) readVideoDurationMs(uri) else 3000L
                MediaItem(
                    id = "device_${System.currentTimeMillis()}_$index",
                    uri = uri.toString(),
                    name = uri.lastPathSegment?.substringAfterLast('/') ?: if (detectedVideo) "Video Clip" else "Photo",
                    isVideo = detectedVideo,
                    durationMs = durationMs.coerceAtLeast(100L),
                    thumbnailUri = uri.toString()
                )
            }
            _uiState.value = _uiState.value.copy(
                availableMedia = newItems + _uiState.value.availableMedia,
                selectedMedia = _uiState.value.selectedMedia + newItems
            )
        }
    }

    private fun readVideoDurationMs(uri: Uri): Long {
        val retriever = MediaMetadataRetriever()
        return try {
            retriever.setDataSource(getApplication<Application>(), uri)
            retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 5000L
        } catch (_: Exception) {
            5000L
        } finally {
            try { retriever.release() } catch (_: Exception) {}
        }
    }

    fun createProjectFromSelected(aspectRatio: AspectRatio = AspectRatio.RATIO_9_16) {
        val selected = _uiState.value.selectedMedia
        if (selected.isEmpty()) return

        val projectId = UUID.randomUUID().toString()
        val dateFormat = SimpleDateFormat("MMM dd, HH:mm", Locale.getDefault())
        val projectName = "Project ${dateFormat.format(Date())}"
        val totalDuration = selected.sumOf { it.durationMs }

        val project = ProjectEntity(
            id = projectId,
            name = projectName,
            aspectPreset = aspectRatio.label,
            canvasWidth = if (aspectRatio == AspectRatio.RATIO_16_9) 1920 else 1080,
            canvasHeight = if (aspectRatio == AspectRatio.RATIO_16_9) 1080 else 1920,
            fps = 30,
            durationMs = totalDuration,
            clipCount = selected.size,
            thumbnailUri = selected.firstOrNull()?.thumbnailUri ?: selected.firstOrNull()?.uri,
            isDraft = true
        )

        val clips = selected.mapIndexed { index, item ->
            TimelineClipEntity(
                projectId = projectId,
                orderIndex = index,
                mediaUri = item.uri,
                mediaName = item.name,
                isVideo = item.isVideo,
                inMs = 0L,
                outMs = item.durationMs,
                originalDurationMs = item.durationMs
            )
        }

        viewModelScope.launch {
            repository.saveProjectWithClips(project, clips)
            _uiState.value = _uiState.value.copy(
                showMediaPicker = false,
                selectedMedia = emptyList(),
                activeProject = project,
                activeClips = clips,
                toastMessage = "Project created: ${project.name}"
            )
        }
    }

    fun createBlankCanvas(aspectRatio: AspectRatio = AspectRatio.RATIO_9_16) {
        val projectId = UUID.randomUUID().toString()
        val dateFormat = SimpleDateFormat("MMM dd, HH:mm", Locale.getDefault())
        val projectName = "Blank ${aspectRatio.label.substringBefore(' ')} ${dateFormat.format(Date())}"

        val project = ProjectEntity(
            id = projectId,
            name = projectName,
            aspectPreset = aspectRatio.label,
            canvasWidth = if (aspectRatio == AspectRatio.RATIO_16_9) 1920 else 1080,
            canvasHeight = if (aspectRatio == AspectRatio.RATIO_16_9) 1080 else 1920,
            fps = 30,
            durationMs = 5000L,
            clipCount = 0,
            thumbnailUri = null,
            isDraft = true
        )

        viewModelScope.launch {
            repository.saveProject(project)
            _uiState.value = _uiState.value.copy(
                activeProject = project,
                activeClips = emptyList(),
                toastMessage = "Canvas created: $projectName"
            )
        }
    }

    fun openProject(project: ProjectEntity) {
        viewModelScope.launch {
            repository.getClips(project.id).collect { clips ->
                _uiState.value = _uiState.value.copy(
                    activeProject = project,
                    activeClips = clips
                )
            }
        }
    }

    fun closeProject() {
        _uiState.value = _uiState.value.copy(
            activeProject = null,
            activeClips = emptyList()
        )
    }

    fun deleteProject(project: ProjectEntity) {
        viewModelScope.launch {
            repository.deleteProject(project.id)
            if (_uiState.value.activeProject?.id == project.id) {
                closeProject()
            }
            _uiState.value = _uiState.value.copy(toastMessage = "Project deleted")
        }
    }

    fun clearToast() {
        _uiState.value = _uiState.value.copy(toastMessage = null)
    }

    fun createProjectFromTemplate(title: String, aspectRatio: AspectRatio = AspectRatio.RATIO_9_16) {
        val sampleItems = SampleMediaProvider.sampleVideos.take(3)
        val projectId = UUID.randomUUID().toString()
        val totalDuration = sampleItems.sumOf { it.durationMs }

        val project = ProjectEntity(
            id = projectId,
            name = "$title Edit",
            aspectPreset = aspectRatio.label,
            canvasWidth = 1080,
            canvasHeight = 1920,
            fps = 30,
            durationMs = totalDuration,
            clipCount = sampleItems.size,
            thumbnailUri = sampleItems.firstOrNull()?.thumbnailUri,
            isDraft = true
        )

        val clips = sampleItems.mapIndexed { index, item ->
            TimelineClipEntity(
                projectId = projectId,
                orderIndex = index,
                mediaUri = item.uri,
                mediaName = item.name,
                isVideo = item.isVideo,
                inMs = 0L,
                outMs = item.durationMs,
                originalDurationMs = item.durationMs,
                filterName = if (index == 0) "Cinematic" else if (index == 1) "Vivid" else null,
                transitionName = if (index > 0) "fade" else null
            )
        }

        viewModelScope.launch {
            repository.saveProjectWithClips(project, clips)
            _uiState.value = _uiState.value.copy(
                activeProject = project,
                activeClips = clips,
                toastMessage = "Template created: $title"
            )
        }
    }
}

