package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Professional Video Editor Palette (InShot / CapCut Inspired)
val EditorPrimary = Color(0xFFFF2D78) // Vibrant coral pink
val EditorSecondary = Color(0xFF5CC8E0) // Cyan electric
val EditorTertiary = Color(0xFF7B3CFF) // Neon violet
val EditorAccentYellow = Color(0xFFFFD400) // Accent golden yellow

val DarkBackground = Color(0xFF0F1016)
val DarkSurface = Color(0xFF171A23)
val DarkSurfaceVariant = Color(0xFF222634)
val DarkCardBorder = Color(0xFF323849)

val TextPrimary = Color(0xFFF2F4F8)
val TextSecondary = Color(0xFF9EA6BA)
val TextMuted = Color(0xFF6B7285)

val SuccessGreen = Color(0xFF3DDC97)
val WarningAmber = Color(0xFFFFAB00)
val DangerRed = Color(0xFFFF4D4F)
