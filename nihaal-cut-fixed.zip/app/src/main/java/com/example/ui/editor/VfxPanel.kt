package com.example.ui.editor

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.RestartAlt
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.TabRowDefaults
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.TimelineClipEntity
import com.example.ui.theme.DarkCardBorder
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.DarkSurfaceVariant
import com.example.ui.theme.EditorAccentYellow
import com.example.ui.theme.EditorPrimary
import com.example.ui.theme.EditorSecondary
import com.example.ui.theme.EditorTertiary
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@Composable
fun VfxPanel(
    clip: TimelineClipEntity,
    isTamil: Boolean,
    onEffectChange: (String?, Float, Float) -> Unit,
    onFilterChange: (String?, Float) -> Unit,
    onBrowseAllClick: () -> Unit = {},
    onClose: () -> Unit
) {
    var selectedTab by remember { mutableIntStateOf(0) }
    var vfxIntensity by remember { androidx.compose.runtime.mutableFloatStateOf(clip.vfxIntensity) }
    var vfxSpeed by remember { androidx.compose.runtime.mutableFloatStateOf(clip.vfxSpeed) }
    var filterIntensity by remember { androidx.compose.runtime.mutableFloatStateOf(clip.filterIntensity) }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(DarkSurface)
            .border(1.dp, DarkCardBorder)
            .padding(14.dp)
            .testTag("vfx_inspector_panel")
    ) {
        // Header
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            TabRow(
                selectedTabIndex = selectedTab,
                containerColor = Color.Transparent,
                contentColor = EditorSecondary,
                indicator = { tabPositions ->
                    TabRowDefaults.SecondaryIndicator(
                        Modifier.tabIndicatorOffset(tabPositions[selectedTab]),
                        color = EditorSecondary
                    )
                },
                modifier = Modifier.width(260.dp)
            ) {
                Tab(
                    selected = selectedTab == 0,
                    onClick = { selectedTab = 0 },
                    text = { Text(if (isTamil) "விஎஃப்எக்ஸ் (VFX)" else "VFX Effects", fontSize = 12.sp, fontWeight = FontWeight.Bold) }
                )
                Tab(
                    selected = selectedTab == 1,
                    onClick = { selectedTab = 1 },
                    text = { Text(if (isTamil) "வடிகட்டி" else "Color Filters", fontSize = 12.sp, fontWeight = FontWeight.Bold) }
                )
            }

            IconButton(onClick = onClose, modifier = Modifier.size(28.dp)) {
                Icon(Icons.Default.Close, contentDescription = "Close", tint = TextPrimary)
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Browse All 500+ VFX Button
        Button(
            onClick = onBrowseAllClick,
            colors = ButtonDefaults.buttonColors(containerColor = EditorSecondary.copy(alpha = 0.2f)),
            shape = RoundedCornerShape(10.dp),
            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
            modifier = Modifier.fillMaxWidth().testTag("browse_all_vfx_button")
        ) {
            Icon(Icons.Default.AutoAwesome, contentDescription = null, tint = EditorSecondary, modifier = Modifier.size(16.dp))
            Spacer(modifier = Modifier.width(6.dp))
            Text(
                text = if (isTamil) "500+ விஎஃப்எக்ஸ் எஃபெக்ட்களைத் திற (500+ VFX)" else "Browse 500+ VFX & Styles Library",
                color = EditorSecondary,
                fontWeight = FontWeight.Bold,
                fontSize = 12.sp
            )
        }

        Spacer(modifier = Modifier.height(8.dp))

        if (selectedTab == 0) {
            // VFX EFFECTS LIST
            val vfxItems = listOf(
                Pair("None", "None"),
                Pair("glitch", "RGB Glitch"),
                Pair("vhs", "Retro VHS"),
                Pair("shake", "Camera Shake"),
                Pair("zoom_pulse", "Zoom Pulse"),
                Pair("flash", "White Strobe"),
                Pair("film_grain", "Film Grain"),
                Pair("light_leak", "Light Leak"),
                Pair("chromatic", "Chromatic"),
                Pair("old_tv", "Old CRT TV"),
                Pair("pixelate", "8-Bit Pixels"),
                Pair("mirror", "Quad Mirror"),
                Pair("edge_glow", "Neon Glow"),
                Pair("wave", "Wave Ripple"),
                Pair("focus_blur", "Radial Blur"),
                Pair("invert", "Invert Color")
            )

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                vfxItems.forEach { (id, name) ->
                    val isSelected = (clip.effectName == id) || (clip.effectName == null && id == "None")
                    Box(
                        modifier = Modifier
                            .width(84.dp)
                            .height(58.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .background(if (isSelected) EditorSecondary else DarkSurfaceVariant)
                            .border(1.dp, if (isSelected) Color.White else DarkCardBorder, RoundedCornerShape(10.dp))
                            .clickable {
                                onEffectChange(if (id == "None") null else id, vfxIntensity, vfxSpeed)
                            },
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = name,
                            color = if (isSelected) Color.Black else TextPrimary,
                            fontWeight = FontWeight.Bold,
                            fontSize = 11.sp
                        )
                    }
                }
            }

            if (clip.effectName != null) {
                Spacer(modifier = Modifier.height(10.dp))
                // Intensity slider
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = String.format(java.util.Locale.US, "Intensity: %d%%", (vfxIntensity * 100).toInt()),
                        color = TextSecondary,
                        fontSize = 11.sp,
                        modifier = Modifier.width(96.dp)
                    )
                    Slider(
                        value = vfxIntensity,
                        onValueChange = {
                            vfxIntensity = it
                            onEffectChange(clip.effectName, vfxIntensity, vfxSpeed)
                        },
                        valueRange = 0.1f..1.0f,
                        colors = SliderDefaults.colors(
                            thumbColor = EditorSecondary,
                            activeTrackColor = EditorSecondary
                        ),
                        modifier = Modifier.weight(1f)
                    )
                }

                // Speed slider
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = String.format(java.util.Locale.US, "Speed: %.1f×", vfxSpeed),
                        color = TextSecondary,
                        fontSize = 11.sp,
                        modifier = Modifier.width(96.dp)
                    )
                    Slider(
                        value = vfxSpeed,
                        onValueChange = {
                            vfxSpeed = it
                            onEffectChange(clip.effectName, vfxIntensity, vfxSpeed)
                        },
                        valueRange = 0.2f..3.0f,
                        colors = SliderDefaults.colors(
                            thumbColor = EditorAccentYellow,
                            activeTrackColor = EditorAccentYellow
                        ),
                        modifier = Modifier.weight(1f)
                    )
                }
            }
        } else {
            // COLOR FILTERS LIST
            val filters = listOf(
                Pair("None", "Original"),
                Pair("Cinematic", "Cinematic"),
                Pair("Cyberpunk", "Cyberpunk"),
                Pair("Warm", "Warm Cafe"),
                Pair("Cool", "Cool Blue"),
                Pair("Vintage", "Vintage 70s"),
                Pair("B&W", "Noir Mono"),
                Pair("Vivid", "Vivid Pop"),
                Pair("GoldenHour", "Golden Hour"),
                Pair("Emerald", "Emerald"),
                Pair("NeonSunset", "Neon Sunset"),
                Pair("Moody", "Dark Moody")
            )

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                filters.forEach { (name, label) ->
                    val isSelected = (clip.filterName == name) || (clip.filterName == null && name == "None")
                    Box(
                        modifier = Modifier
                            .width(84.dp)
                            .height(58.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .background(if (isSelected) EditorPrimary else DarkSurfaceVariant)
                            .border(1.dp, if (isSelected) Color.White else DarkCardBorder, RoundedCornerShape(10.dp))
                            .clickable {
                                onFilterChange(if (name == "None") null else name, filterIntensity)
                            },
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = label,
                            color = if (isSelected) Color.White else TextPrimary,
                            fontWeight = FontWeight.Bold,
                            fontSize = 11.sp
                        )
                    }
                }
            }

            if (clip.filterName != null) {
                Spacer(modifier = Modifier.height(10.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = String.format(java.util.Locale.US, "Intensity: %d%%", (filterIntensity * 100).toInt()),
                        color = TextSecondary,
                        fontSize = 11.sp,
                        modifier = Modifier.width(96.dp)
                    )
                    Slider(
                        value = filterIntensity,
                        onValueChange = {
                            filterIntensity = it
                            onFilterChange(clip.filterName, filterIntensity)
                        },
                        valueRange = 0.1f..1.0f,
                        colors = SliderDefaults.colors(
                            thumbColor = EditorPrimary,
                            activeTrackColor = EditorPrimary
                        ),
                        modifier = Modifier.weight(1f)
                    )
                }
            }
        }
    }
}
