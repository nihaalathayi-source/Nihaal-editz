package com.example.ui.editor

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.RestartAlt
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.TabRowDefaults
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.TimelineClipEntity
import com.example.ui.theme.DarkCardBorder
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.DarkSurfaceVariant
import com.example.ui.theme.EditorPrimary
import com.example.ui.theme.EditorSecondary
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@Composable
fun FilterEffectPanel(
    clip: TimelineClipEntity,
    isTamil: Boolean,
    onFilterChange: (String?) -> Unit,
    onFilterIntensityChange: (Float) -> Unit,
    onEffectChange: (String?) -> Unit,
    onBrightnessChange: (Float) -> Unit,
    onContrastChange: (Float) -> Unit,
    onSaturationChange: (Float) -> Unit,
    onTemperatureChange: (Float) -> Unit,
    onBlurChange: (Float) -> Unit,
    onVignetteChange: (Float) -> Unit,
    onResetAdjustments: () -> Unit,
    onClose: () -> Unit
) {
    var selectedTab by remember { mutableIntStateOf(0) }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(DarkSurface)
            .border(1.dp, DarkCardBorder)
            .padding(14.dp)
            .testTag("filter_effect_inspector_panel")
    ) {
        // Header Tabs: Filters | Adjustments | VFX Effects
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            TabRow(
                selectedTabIndex = selectedTab,
                containerColor = Color.Transparent,
                contentColor = EditorPrimary,
                indicator = { tabPositions ->
                    TabRowDefaults.SecondaryIndicator(
                        Modifier.tabIndicatorOffset(tabPositions[selectedTab]),
                        color = EditorPrimary
                    )
                },
                modifier = Modifier.width(280.dp)
            ) {
                Tab(
                    selected = selectedTab == 0,
                    onClick = { selectedTab = 0 },
                    text = { Text(if (isTamil) "வடிகட்டி" else "Filters", fontSize = 12.sp) }
                )
                Tab(
                    selected = selectedTab == 1,
                    onClick = { selectedTab = 1 },
                    text = { Text(if (isTamil) "சரிசெய்" else "Adjust", fontSize = 12.sp) }
                )
                Tab(
                    selected = selectedTab == 2,
                    onClick = { selectedTab = 2 },
                    text = { Text(if (isTamil) "விளைவுகள்" else "VFX", fontSize = 12.sp) }
                )
            }

            IconButton(onClick = onClose, modifier = Modifier.size(28.dp)) {
                Icon(Icons.Default.Close, contentDescription = "Close", tint = TextPrimary)
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        when (selectedTab) {
            0 -> {
                // FILTERS TAB
                val filters = listOf(
                    Pair("None", "Original"),
                    Pair("Cinematic", "Cine"),
                    Pair("Warm", "Warm"),
                    Pair("Cool", "Cool"),
                    Pair("Vintage", "Retro"),
                    Pair("B&W", "Mono"),
                    Pair("Vivid", "Vivid"),
                    Pair("Film", "Film"),
                    Pair("Night", "Night"),
                    Pair("Moody", "Moody"),
                    Pair("Portrait", "Skin")
                )

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    filters.forEach { (name, label) ->
                        val isSelected = (clip.filterName == name) || (clip.filterName == null && name == "None")
                        Box(
                            modifier = Modifier
                                .size(64.dp, 64.dp)
                                .clip(RoundedCornerShape(10.dp))
                                .background(if (isSelected) EditorPrimary else DarkSurfaceVariant)
                                .border(
                                    width = if (isSelected) 2.dp else 1.dp,
                                    color = if (isSelected) Color.White else DarkCardBorder,
                                    shape = RoundedCornerShape(10.dp)
                                )
                                .clickable { onFilterChange(if (name == "None") null else name) },
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = label,
                                color = if (isSelected) Color.White else TextPrimary,
                                fontWeight = FontWeight.Bold,
                                fontSize = 12.sp
                            )
                        }
                    }
                }

                if (clip.filterName != null) {
                    Spacer(modifier = Modifier.height(10.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Intensity: ${(clip.filterIntensity * 100).toInt()}%",
                            color = TextSecondary,
                            fontSize = 11.sp,
                            modifier = Modifier.width(90.dp)
                        )
                        Slider(
                            value = clip.filterIntensity,
                            onValueChange = onFilterIntensityChange,
                            valueRange = 0f..1f,
                            colors = SliderDefaults.colors(
                                thumbColor = EditorPrimary,
                                activeTrackColor = EditorPrimary
                            ),
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
            }
            1 -> {
                // ADJUSTMENTS TAB (Brightness, Contrast, Saturation, Temp, Vignette)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(text = "Color Grading", color = TextSecondary, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                    Button(
                        onClick = onResetAdjustments,
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF382025)),
                        contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                        shape = RoundedCornerShape(6.dp)
                    ) {
                        Icon(Icons.Default.RestartAlt, contentDescription = null, modifier = Modifier.size(14.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(text = "Reset", fontSize = 10.sp)
                    }
                }

                Spacer(modifier = Modifier.height(6.dp))

                // Brightness
                AdjustmentSliderRow("Bright", clip.brightness, 0.4f..1.8f, onBrightnessChange)
                // Contrast
                AdjustmentSliderRow("Contrast", clip.contrast, 0.4f..1.8f, onContrastChange)
                // Saturation
                AdjustmentSliderRow("Saturate", clip.saturation, 0f..2.5f, onSaturationChange)
                // Temperature
                AdjustmentSliderRow("Temp", clip.temperature, -1f..1f, onTemperatureChange)
                // Vignette
                AdjustmentSliderRow("Vignette", clip.vignette, 0f..1f, onVignetteChange)
            }
            2 -> {
                // VFX TAB (Shake, Zoom Pulse, Flash, Glitch, VHS, RGB split, Blur)
                val vfxList = listOf(
                    Pair("None", "None"),
                    Pair("shake", "Shake"),
                    Pair("zoom", "Zoom Pulse"),
                    Pair("flash", "White Flash"),
                    Pair("glitch", "RGB Glitch"),
                    Pair("vhs", "Retro VHS"),
                    Pair("rgb", "Chromatic"),
                    Pair("blur", "Focus Blur")
                )

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    vfxList.forEach { (id, name) ->
                        val isSelected = (clip.effectName == id) || (clip.effectName == null && id == "None")
                        Box(
                            modifier = Modifier
                                .width(80.dp)
                                .height(56.dp)
                                .clip(RoundedCornerShape(10.dp))
                                .background(if (isSelected) EditorSecondary else DarkSurfaceVariant)
                                .border(
                                    width = if (isSelected) 2.dp else 1.dp,
                                    color = if (isSelected) Color.White else DarkCardBorder,
                                    shape = RoundedCornerShape(10.dp)
                                )
                                .clickable { onEffectChange(if (id == "None") null else id) },
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = name,
                                color = if (isSelected) Color.Black else TextPrimary,
                                fontWeight = FontWeight.Bold,
                                fontSize = 11.sp
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun AdjustmentSliderRow(
    label: String,
    value: Float,
    range: ClosedFloatingPointRange<Float>,
    onValueChange: (Float) -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = String.format(java.util.Locale.US, "%s: %.2f", label, value),
            color = TextSecondary,
            fontSize = 11.sp,
            modifier = Modifier.width(82.dp)
        )
        Slider(
            value = value,
            onValueChange = onValueChange,
            valueRange = range,
            colors = SliderDefaults.colors(
                thumbColor = EditorSecondary,
                activeTrackColor = EditorSecondary
            ),
            modifier = Modifier.weight(1f)
        )
    }
}
