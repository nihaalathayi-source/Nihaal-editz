package com.example.ui.editor

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Crop
import androidx.compose.material.icons.filled.FitScreen
import androidx.compose.material.icons.filled.RestartAlt
import androidx.compose.material.icons.filled.RotateRight
import androidx.compose.material.icons.filled.ZoomIn
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.TabRowDefaults
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.TimelineClipEntity
import com.example.ui.theme.DarkCardBorder
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.DarkSurfaceVariant
import com.example.ui.theme.EditorAccentYellow
import com.example.ui.theme.EditorPrimary
import com.example.ui.theme.EditorSecondary
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@Composable
fun TransformPanel(
    clip: TimelineClipEntity,
    isTamil: Boolean,
    onRotate: () -> Unit,
    onFreeRotateChange: (Float) -> Unit,
    onFlipH: () -> Unit,
    onFlipV: () -> Unit,
    onScaleChange: (Float) -> Unit,
    onTransXChange: (Float) -> Unit,
    onTransYChange: (Float) -> Unit,
    onFitModeChange: (String) -> Unit,
    onCropRatioChange: (String) -> Unit,
    onCenterAlign: () -> Unit,
    onReset: () -> Unit,
    onClose: () -> Unit
) {
    var selectedTab by remember { mutableIntStateOf(0) }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(DarkSurface)
            .border(1.dp, DarkCardBorder)
            .padding(14.dp)
            .testTag("transform_inspector_panel")
    ) {
        // Header
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            TabRow(
                selectedTabIndex = selectedTab,
                containerColor = Color.Transparent,
                contentColor = EditorPrimary,
                indicator = { tabPositions ->
                    TabRowDefaults.SecondaryIndicator(
                        Modifier.tabIndicatorOffset(tabPositions[selectedTab]),
                        color = EditorPrimary
                    )
                },
                modifier = Modifier.width(280.dp)
            ) {
                Tab(
                    selected = selectedTab == 0,
                    onClick = { selectedTab = 0 },
                    text = { Text(if (isTamil) "அளவு & நிலை" else "Scale & Pos", fontSize = 12.sp, fontWeight = FontWeight.Bold) }
                )
                Tab(
                    selected = selectedTab == 1,
                    onClick = { selectedTab = 1 },
                    text = { Text(if (isTamil) "சுழற்று & திருப்பு" else "Rotate & Flip", fontSize = 12.sp, fontWeight = FontWeight.Bold) }
                )
                Tab(
                    selected = selectedTab == 2,
                    onClick = { selectedTab = 2 },
                    text = { Text(if (isTamil) "க்ராப் & விகிதம்" else "Crop & Ratio", fontSize = 12.sp, fontWeight = FontWeight.Bold) }
                )
            }

            IconButton(onClick = onClose, modifier = Modifier.size(28.dp)) {
                Icon(Icons.Default.Close, contentDescription = "Close", tint = TextPrimary)
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        when (selectedTab) {
            0 -> {
                // SCALE & POSITION TAB
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = String.format(java.util.Locale.US, "Zoom %.2f×", clip.scale),
                        color = TextSecondary,
                        fontSize = 11.sp,
                        modifier = Modifier.width(80.dp)
                    )
                    Slider(
                        value = clip.scale,
                        onValueChange = onScaleChange,
                        valueRange = 0.5f..3.0f,
                        colors = SliderDefaults.colors(thumbColor = EditorPrimary, activeTrackColor = EditorPrimary),
                        modifier = Modifier.weight(1f)
                    )
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Move X: ${clip.transX.toInt()}%",
                        color = TextSecondary,
                        fontSize = 11.sp,
                        modifier = Modifier.width(80.dp)
                    )
                    Slider(
                        value = clip.transX,
                        onValueChange = onTransXChange,
                        valueRange = -50f..50f,
                        colors = SliderDefaults.colors(thumbColor = EditorSecondary, activeTrackColor = EditorSecondary),
                        modifier = Modifier.weight(1f)
                    )
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Move Y: ${clip.transY.toInt()}%",
                        color = TextSecondary,
                        fontSize = 11.sp,
                        modifier = Modifier.width(80.dp)
                    )
                    Slider(
                        value = clip.transY,
                        onValueChange = onTransYChange,
                        valueRange = -50f..50f,
                        colors = SliderDefaults.colors(thumbColor = EditorSecondary, activeTrackColor = EditorSecondary),
                        modifier = Modifier.weight(1f)
                    )
                }

                Spacer(modifier = Modifier.height(6.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Button(
                        onClick = onCenterAlign,
                        colors = ButtonDefaults.buttonColors(containerColor = DarkSurfaceVariant),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        Text(text = "Align Center", fontSize = 11.sp)
                    }
                    Button(
                        onClick = onReset,
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF382025)),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        Icon(Icons.Default.RestartAlt, contentDescription = null, modifier = Modifier.size(14.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(text = "Reset", fontSize = 11.sp)
                    }
                }
            }
            1 -> {
                // ROTATE & FLIP TAB
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Angle: ${clip.freeRotation.toInt()}°",
                        color = TextSecondary,
                        fontSize = 11.sp,
                        modifier = Modifier.width(80.dp)
                    )
                    Slider(
                        value = clip.freeRotation,
                        onValueChange = onFreeRotateChange,
                        valueRange = 0f..360f,
                        colors = SliderDefaults.colors(thumbColor = EditorPrimary, activeTrackColor = EditorPrimary),
                        modifier = Modifier.weight(1f)
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Button(
                        onClick = onRotate,
                        colors = ButtonDefaults.buttonColors(containerColor = DarkSurfaceVariant),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        Icon(Icons.Default.RotateRight, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(text = "+90°", fontSize = 11.sp)
                    }
                    Button(
                        onClick = onFlipH,
                        colors = ButtonDefaults.buttonColors(containerColor = if (clip.flipH) EditorPrimary else DarkSurfaceVariant),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        Text(text = "Flip H", fontSize = 11.sp)
                    }
                    Button(
                        onClick = onFlipV,
                        colors = ButtonDefaults.buttonColors(containerColor = if (clip.flipV) EditorPrimary else DarkSurfaceVariant),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        Text(text = "Flip V", fontSize = 11.sp)
                    }
                }
            }
            2 -> {
                // CROP & RATIO TAB
                Text(text = "Aspect Presets & Framing", color = TextSecondary, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                Spacer(modifier = Modifier.height(6.dp))
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    listOf("FIT", "FILL", "9:16", "16:9", "1:1", "4:5", "4:3", "3:4").forEach { preset ->
                        val isSelected = (clip.fitMode == "contain" && preset == "FIT") ||
                                (clip.fitMode == "cover" && preset == "FILL") ||
                                (clip.cropRatio == preset)
                        FilterChip(
                            selected = isSelected,
                            onClick = {
                                if (preset == "FIT") onFitModeChange("contain")
                                else if (preset == "FILL") onFitModeChange("cover")
                                else onCropRatioChange(preset)
                            },
                            label = { Text(preset, fontSize = 11.sp, fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = EditorPrimary,
                                selectedLabelColor = Color.White
                            )
                        )
                    }
                }
            }
        }
    }
}
