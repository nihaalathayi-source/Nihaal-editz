@file:OptIn(androidx.media3.common.util.UnstableApi::class)

package com.example.ui.editor

import android.view.ViewGroup
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackParameters
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView
import com.example.data.local.TimelineClipEntity
import com.example.data.media.VideoEffectEngine
import kotlinx.coroutines.delay

@Composable
fun EditorVideoPlayer(
    clips: List<TimelineClipEntity>,
    activeClip: TimelineClipEntity?,
    currentPositionMs: Long,
    isPlaying: Boolean,
    modifier: Modifier = Modifier
) {
    val videoClips = remember(clips) {
        clips.sortedBy { it.orderIndex }
            .filter { it.isVideo && it.mediaUri.isNotBlank() && !it.mediaUri.startsWith("sample://") }
    }
    val context = androidx.compose.ui.platform.LocalContext.current
    val player = remember(context) { ExoPlayer.Builder(context).build() }
    var lastSyncedGlobalMs by remember { mutableStateOf(Long.MIN_VALUE) }

    DisposableEffect(player) {
        onDispose { player.release() }
    }

    fun globalToVideoIndex(positionMs: Long): Pair<Int, Long>? {
        var elapsed = 0L
        for (clip in clips.sortedBy { it.orderIndex }) {
            val duration = (clip.outMs - clip.inMs).coerceAtLeast(100L) / clip.speed.coerceAtLeast(0.1f)
            val durationMs = duration.toLong().coerceAtLeast(1L)
            if (positionMs <= elapsed + durationMs) {
                if (!clip.isVideo) return null
                val index = videoClips.indexOfFirst { it.id == clip.id }
                if (index < 0) return null
                val localTimelineMs = (positionMs - elapsed).coerceIn(0L, durationMs)
                val sourcePositionMs = (localTimelineMs * clip.speed).toLong()
                return index to sourcePositionMs
            }
            elapsed += durationMs
        }
        val last = videoClips.lastOrNull() ?: return null
        return videoClips.lastIndex to ((last.outMs - last.inMs).coerceAtLeast(0L))
    }

    fun baseGlobalForVideoIndex(index: Int): Long {
        val target = videoClips.getOrNull(index) ?: return 0L
        var elapsed = 0L
        for (clip in clips.sortedBy { it.orderIndex }) {
            if (clip.id == target.id) break
            elapsed += ((clip.outMs - clip.inMs).coerceAtLeast(100L) / clip.speed.coerceAtLeast(0.1f)).toLong()
        }
        return elapsed
    }

    LaunchedEffect(videoClips.map { "${it.id}|${it.mediaUri}|${it.inMs}|${it.outMs}" }) {
        player.setMediaItems(videoClips.map { clip ->
            MediaItem.Builder()
                .setMediaId(clip.id.toString())
                .setUri(clip.mediaUri)
                .setClippingConfiguration(
                    MediaItem.ClippingConfiguration.Builder()
                        .setStartPositionMs(clip.inMs.coerceAtLeast(0L))
                        .setEndPositionMs(clip.outMs.coerceAtLeast(clip.inMs + 1L))
                        .build()
                )
                .build()
        })
        player.prepare()
    }

    LaunchedEffect(activeClip?.id, activeClip?.effectName, activeClip?.filterName, activeClip?.brightness, activeClip?.contrast, activeClip?.saturation, activeClip?.blurRadius) {
        val clip = activeClip?.takeIf { it.isVideo }
        player.setVideoEffects(clip?.let(VideoEffectEngine::buildEffects) ?: emptyList())
        if (clip != null) {
            player.playbackParameters = PlaybackParameters(clip.speed.coerceIn(0.1f, 4f), 1f)
        }
    }

    LaunchedEffect(isPlaying, activeClip?.id) {
        if (isPlaying && activeClip?.isVideo == true) {
            globalToVideoIndex(currentPositionMs)?.let { (index, localMs) ->
                if (player.currentMediaItemIndex != index || kotlin.math.abs(player.currentPosition - localMs) > 350L) {
                    player.seekTo(index, localMs)
                }
            }
            player.play()
        } else {
            player.pause()
        }
    }

    LaunchedEffect(currentPositionMs, isPlaying, activeClip?.id) {
        if (!isPlaying) {
            globalToVideoIndex(currentPositionMs)?.let { (index, localMs) ->
                player.seekTo(index, localMs)
                lastSyncedGlobalMs = currentPositionMs
            }
            return@LaunchedEffect
        }
        // The ViewModel clock remains authoritative. Correct drift occasionally while playing.
        if (activeClip?.isVideo == true && kotlin.math.abs(currentPositionMs - lastSyncedGlobalMs) > 500L) {
            globalToVideoIndex(currentPositionMs)?.let { (index, localMs) -> player.seekTo(index, localMs) }
            lastSyncedGlobalMs = currentPositionMs
        }
    }

    AndroidView(
        modifier = modifier.fillMaxSize(),
        factory = {
            PlayerView(it).apply {
                this.player = player
                useController = false
                resizeMode = AspectRatioFrameLayout.RESIZE_MODE_FIT
                layoutParams = ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
                setKeepContentOnPlayerReset(true)
            }
        },
        update = { view ->
            view.player = player
            view.resizeMode = if (activeClip?.fitMode == "cover") {
                AspectRatioFrameLayout.RESIZE_MODE_ZOOM
            } else {
                AspectRatioFrameLayout.RESIZE_MODE_FIT
            }
        }
    )

    // Touch/scrub sync is deliberately light: the timeline remains responsive and the player catches up on pause.
    LaunchedEffect(player) {
        while (true) {
            delay(120L)
            if (player.isPlaying) {
                val index = player.currentMediaItemIndex
                val clip = videoClips.getOrNull(index) ?: continue
                val speed = clip.speed.coerceAtLeast(0.1f)
                val localTimelineMs = (player.currentPosition / speed).toLong()
                lastSyncedGlobalMs = baseGlobalForVideoIndex(index) + localTimelineMs
            }
        }
    }
}

// AndroidView factory cannot directly capture the receiver property with the same name on older Compose compilers.
