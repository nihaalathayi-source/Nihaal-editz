package com.example.ui.home

import android.widget.Toast
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Animation
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.ContentCut
import androidx.compose.material.icons.filled.Crop
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.EmojiEmotions
import androidx.compose.material.icons.filled.Filter
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Layers
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.Photo
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Style
import androidx.compose.material.icons.filled.TextFields
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material.icons.filled.VideoLibrary
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import coil.compose.AsyncImage
import com.example.R
import com.example.data.local.ProjectEntity
import com.example.data.model.AspectRatio
import com.example.ui.components.QuickToolChip
import com.example.ui.editor.EditorPreviewStage
import com.example.ui.theme.DarkBackground
import com.example.ui.theme.DarkCardBorder
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.DarkSurfaceVariant
import com.example.ui.theme.EditorAccentYellow
import com.example.ui.theme.EditorPrimary
import com.example.ui.theme.EditorSecondary
import com.example.ui.theme.EditorTertiary
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun HomeScreen(viewModel: HomeViewModel) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    val projects by viewModel.projects.collectAsStateWithLifecycle()
    val context = LocalContext.current

    LaunchedEffect(uiState.toastMessage) {
        uiState.toastMessage?.let { msg ->
            Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()
            viewModel.clearToast()
        }
    }

    if (uiState.activeProject != null) {
        EditorPreviewStage(
            project = uiState.activeProject!!,
            clips = uiState.activeClips,
            isTamil = uiState.isTamil,
            onBack = { viewModel.closeProject() }
        )
        return
    }

    Scaffold(
        containerColor = DarkBackground,
        bottomBar = {
            NavigationBar(
                containerColor = DarkSurface,
                tonalElevation = 8.dp
            ) {
                NavigationBarItem(
                    selected = uiState.activeTab == HomeTab.HOME,
                    onClick = { viewModel.setTab(HomeTab.HOME) },
                    icon = { Icon(Icons.Default.Home, contentDescription = "Home") },
                    label = { Text(if (uiState.isTamil) "முகப்பு" else "Home") },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = EditorPrimary,
                        selectedTextColor = EditorPrimary,
                        unselectedIconColor = TextMuted,
                        unselectedTextColor = TextMuted,
                        indicatorColor = DarkSurfaceVariant
                    )
                )
                NavigationBarItem(
                    selected = uiState.activeTab == HomeTab.PROJECTS,
                    onClick = { viewModel.setTab(HomeTab.PROJECTS) },
                    icon = { Icon(Icons.Default.Folder, contentDescription = "Projects") },
                    label = { Text(if (uiState.isTamil) "திட்டங்கள்" else "Projects") },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = EditorPrimary,
                        selectedTextColor = EditorPrimary,
                        unselectedIconColor = TextMuted,
                        unselectedTextColor = TextMuted,
                        indicatorColor = DarkSurfaceVariant
                    )
                )
                NavigationBarItem(
                    selected = uiState.activeTab == HomeTab.TEMPLATES,
                    onClick = { viewModel.setTab(HomeTab.TEMPLATES) },
                    icon = { Icon(Icons.Default.Style, contentDescription = "Templates") },
                    label = { Text(if (uiState.isTamil) "வார்ப்புரு" else "Templates") },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = EditorPrimary,
                        selectedTextColor = EditorPrimary,
                        unselectedIconColor = TextMuted,
                        unselectedTextColor = TextMuted,
                        indicatorColor = DarkSurfaceVariant
                    )
                )
                NavigationBarItem(
                    selected = uiState.activeTab == HomeTab.SETTINGS,
                    onClick = { viewModel.setTab(HomeTab.SETTINGS) },
                    icon = { Icon(Icons.Default.Settings, contentDescription = "Settings") },
                    label = { Text(if (uiState.isTamil) "அமைப்புகள்" else "Settings") },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = EditorPrimary,
                        selectedTextColor = EditorPrimary,
                        unselectedIconColor = TextMuted,
                        unselectedTextColor = TextMuted,
                        indicatorColor = DarkSurfaceVariant
                    )
                )
            }
        }
    ) { padding ->
        when (uiState.activeTab) {
            HomeTab.HOME -> {
                LazyColumn(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(padding)
                        .testTag("home_screen"),
                    contentPadding = PaddingValues(bottom = 24.dp)
                ) {
                    // Header Bar
                    item {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 20.dp, vertical = 16.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Image(
                                    painter = painterResource(id = R.drawable.app_logo),
                                    contentDescription = "App Logo",
                                    modifier = Modifier
                                        .size(36.dp)
                                        .clip(RoundedCornerShape(10.dp))
                                )
                                Spacer(modifier = Modifier.width(10.dp))
                                Column {
                                    Text(
                                        text = "NIHAAL CUT",
                                        color = TextPrimary,
                                        fontSize = 18.sp,
                                        fontWeight = FontWeight.Black,
                                        letterSpacing = 1.sp
                                    )
                                    Text(
                                        text = "Video & Photo Editor",
                                        color = TextMuted,
                                        fontSize = 10.sp
                                    )
                                }
                            }

                            // Language Toggle
                            Button(
                                onClick = { viewModel.toggleLanguage() },
                                colors = ButtonDefaults.buttonColors(containerColor = DarkSurfaceVariant),
                                contentPadding = PaddingValues(horizontal = 14.dp, vertical = 6.dp),
                                shape = RoundedCornerShape(18.dp),
                                modifier = Modifier.testTag("language_toggle_button")
                            ) {
                                Text(
                                    text = if (uiState.isTamil) "English" else "தமிழ்",
                                    color = EditorSecondary,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 12.sp
                                )
                            }
                        }
                    }

                    // Big Hero Action: + New Project
                    item {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 20.dp)
                                .clip(RoundedCornerShape(22.dp))
                                .background(
                                    Brush.horizontalGradient(
                                        listOf(EditorPrimary, EditorTertiary, EditorSecondary)
                                    )
                                )
                                .clickable { viewModel.openMediaPicker(MediaFilter.ALL) }
                                .padding(20.dp)
                                .testTag("new_project_hero_button"),
                            contentAlignment = Alignment.Center
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.Center
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(44.dp)
                                        .clip(CircleShape)
                                        .background(Color.White.copy(alpha = 0.25f)),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Add,
                                        contentDescription = "Add",
                                        tint = Color.White,
                                        modifier = Modifier.size(28.dp)
                                    )
                                }
                                Spacer(modifier = Modifier.width(16.dp))
                                Column {
                                    Text(
                                        text = if (uiState.isTamil) "+ புதிய திட்டம்" else "+ New Project",
                                        color = Color.White,
                                        fontSize = 20.sp,
                                        fontWeight = FontWeight.Black
                                    )
                                    Text(
                                        text = if (uiState.isTamil)
                                            "வீடியோ அல்லது படங்களை இறக்குமதி செய்து தொடங்கவும்"
                                        else
                                            "Tap to import clips & start editing",
                                        color = Color.White.copy(alpha = 0.85f),
                                        fontSize = 12.sp
                                    )
                                }
                            }
                        }
                    }

                    // Quick Creation Action Cards (Video / Photo / Blank Canvas)
                    item {
                        Spacer(modifier = Modifier.height(18.dp))
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 20.dp),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            // Video Card
                            Card(
                                modifier = Modifier
                                    .weight(1f)
                                    .clickable { viewModel.openMediaPicker(MediaFilter.VIDEOS) }
                                    .testTag("action_video_card"),
                                colors = CardDefaults.cardColors(containerColor = DarkSurface),
                                shape = RoundedCornerShape(16.dp),
                                border = androidx.compose.foundation.BorderStroke(1.dp, DarkCardBorder)
                            ) {
                                Column(
                                    modifier = Modifier.padding(14.dp),
                                    horizontalAlignment = Alignment.CenterHorizontally
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .size(42.dp)
                                            .clip(CircleShape)
                                            .background(EditorPrimary.copy(alpha = 0.15f)),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.Movie,
                                            contentDescription = "Video",
                                            tint = EditorPrimary,
                                            modifier = Modifier.size(22.dp)
                                        )
                                    }
                                    Spacer(modifier = Modifier.height(8.dp))
                                    Text(
                                        text = if (uiState.isTamil) "வீடியோ" else "Video",
                                        color = TextPrimary,
                                        fontSize = 13.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }

                            // Photo Card
                            Card(
                                modifier = Modifier
                                    .weight(1f)
                                    .clickable { viewModel.openMediaPicker(MediaFilter.PHOTOS) }
                                    .testTag("action_photo_card"),
                                colors = CardDefaults.cardColors(containerColor = DarkSurface),
                                shape = RoundedCornerShape(16.dp),
                                border = androidx.compose.foundation.BorderStroke(1.dp, DarkCardBorder)
                            ) {
                                Column(
                                    modifier = Modifier.padding(14.dp),
                                    horizontalAlignment = Alignment.CenterHorizontally
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .size(42.dp)
                                            .clip(CircleShape)
                                            .background(EditorSecondary.copy(alpha = 0.15f)),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.Photo,
                                            contentDescription = "Photo",
                                            tint = EditorSecondary,
                                            modifier = Modifier.size(22.dp)
                                        )
                                    }
                                    Spacer(modifier = Modifier.height(8.dp))
                                    Text(
                                        text = if (uiState.isTamil) "படம்" else "Photo",
                                        color = TextPrimary,
                                        fontSize = 13.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }

                            // Blank Canvas Card
                            Card(
                                modifier = Modifier
                                    .weight(1f)
                                    .clickable { viewModel.createBlankCanvas(AspectRatio.RATIO_9_16) }
                                    .testTag("action_blank_canvas_card"),
                                colors = CardDefaults.cardColors(containerColor = DarkSurface),
                                shape = RoundedCornerShape(16.dp),
                                border = androidx.compose.foundation.BorderStroke(1.dp, DarkCardBorder)
                            ) {
                                Column(
                                    modifier = Modifier.padding(14.dp),
                                    horizontalAlignment = Alignment.CenterHorizontally
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .size(42.dp)
                                            .clip(CircleShape)
                                            .background(EditorAccentYellow.copy(alpha = 0.15f)),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.Crop,
                                            contentDescription = "Blank Canvas",
                                            tint = EditorAccentYellow,
                                            modifier = Modifier.size(22.dp)
                                        )
                                    }
                                    Spacer(modifier = Modifier.height(8.dp))
                                    Text(
                                        text = if (uiState.isTamil) "வெற்று கேன்வாஸ்" else "Blank",
                                        color = TextPrimary,
                                        fontSize = 13.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                        }
                    }

                    // Quick Tools Section
                    item {
                        Spacer(modifier = Modifier.height(24.dp))
                        Text(
                            text = if (uiState.isTamil) "விரைவு கருவிகள்" else "Quick Tools",
                            color = TextPrimary,
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 20.dp)
                        )
                        Spacer(modifier = Modifier.height(12.dp))

                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .horizontalScroll(rememberScrollState())
                                .padding(horizontal = 12.dp),
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            QuickToolChip(Icons.Default.ContentCut, "Trim", EditorPrimary) {
                                viewModel.openMediaPicker()
                            }
                            QuickToolChip(Icons.Default.Crop, "Canvas", EditorSecondary) {
                                viewModel.openMediaPicker()
                            }
                            QuickToolChip(Icons.Default.TextFields, "Text", EditorTertiary) {
                                viewModel.openMediaPicker()
                            }
                            QuickToolChip(Icons.Default.EmojiEmotions, "Stickers", EditorAccentYellow) {
                                viewModel.openMediaPicker()
                            }
                            QuickToolChip(Icons.Default.Filter, "Filters", EditorSecondary) {
                                viewModel.openMediaPicker()
                            }
                            QuickToolChip(Icons.Default.AutoAwesome, "Effects", EditorPrimary) {
                                viewModel.openMediaPicker()
                            }
                            QuickToolChip(Icons.Default.Animation, "Transitions", EditorTertiary) {
                                viewModel.openMediaPicker()
                            }
                            QuickToolChip(Icons.Default.MusicNote, "Audio", EditorSecondary) {
                                viewModel.openMediaPicker()
                            }
                            QuickToolChip(Icons.Default.Layers, "PiP", EditorAccentYellow) {
                                viewModel.openMediaPicker()
                            }
                        }
                    }

                    // Recent Projects & Drafts Section
                    item {
                        Spacer(modifier = Modifier.height(28.dp))
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 20.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = if (uiState.isTamil) "சமீபத்திய திட்டங்கள்" else "Recent Projects",
                                color = TextPrimary,
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "${projects.size} saved",
                                color = TextMuted,
                                fontSize = 12.sp
                            )
                        }
                        Spacer(modifier = Modifier.height(12.dp))
                    }

                    if (projects.isEmpty()) {
                        item {
                            Card(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 20.dp),
                                colors = CardDefaults.cardColors(containerColor = DarkSurface),
                                shape = RoundedCornerShape(16.dp),
                                border = androidx.compose.foundation.BorderStroke(1.dp, DarkCardBorder)
                            ) {
                                Column(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(28.dp),
                                    horizontalAlignment = Alignment.CenterHorizontally
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.VideoLibrary,
                                        contentDescription = null,
                                        tint = TextMuted,
                                        modifier = Modifier.size(48.dp)
                                    )
                                    Spacer(modifier = Modifier.height(12.dp))
                                    Text(
                                        text = if (uiState.isTamil)
                                            "இன்னும் திட்டம் இல்லை. புதிய திட்டத்தை தட்டவும்."
                                        else
                                            "No projects yet. Tap New Project to start.",
                                        color = TextSecondary,
                                        fontSize = 13.sp,
                                        fontWeight = FontWeight.Normal
                                    )
                                    Spacer(modifier = Modifier.height(16.dp))
                                    Button(
                                        onClick = { viewModel.openMediaPicker() },
                                        colors = ButtonDefaults.buttonColors(containerColor = DarkSurfaceVariant),
                                        shape = RoundedCornerShape(12.dp),
                                        modifier = Modifier.testTag("try_sample_media_button")
                                    ) {
                                        Text(
                                            text = if (uiState.isTamil) "மாதிரி கிளிப்புகள் தேர்வு செய்" else "Try Sample Media Clips",
                                            color = EditorSecondary,
                                            fontSize = 12.sp,
                                            fontWeight = FontWeight.Bold
                                        )
                                    }
                                }
                            }
                        }
                    } else {
                        items(projects, key = { it.id }) { project ->
                            ProjectCardItem(
                                project = project,
                                isTamil = uiState.isTamil,
                                onClick = { viewModel.openProject(project) },
                                onDelete = { viewModel.deleteProject(project) }
                            )
                            Spacer(modifier = Modifier.height(10.dp))
                        }
                    }
                }
            }

            HomeTab.PROJECTS -> {
                // PROJECTS TAB
                LazyColumn(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(padding)
                        .padding(horizontal = 20.dp),
                    contentPadding = PaddingValues(vertical = 16.dp)
                ) {
                    item {
                        Text(
                            text = if (uiState.isTamil) "அனைத்து திட்டங்கள் & வரைவுகள்" else "All Projects & Drafts",
                            color = TextPrimary,
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "${projects.size} projects in local storage",
                            color = TextMuted,
                            fontSize = 12.sp
                        )
                        Spacer(modifier = Modifier.height(16.dp))
                    }

                    if (projects.isEmpty()) {
                        item {
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 40.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = if (uiState.isTamil) "திட்டங்கள் எதுவும் இல்லை" else "No saved projects found.",
                                    color = TextMuted,
                                    fontSize = 14.sp
                                )
                            }
                        }
                    } else {
                        items(projects, key = { it.id }) { project ->
                            ProjectCardItem(
                                project = project,
                                isTamil = uiState.isTamil,
                                onClick = { viewModel.openProject(project) },
                                onDelete = { viewModel.deleteProject(project) }
                            )
                            Spacer(modifier = Modifier.height(10.dp))
                        }
                    }
                }
            }

            HomeTab.TEMPLATES -> {
                // TEMPLATES TAB
                LazyColumn(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(padding)
                        .padding(horizontal = 20.dp),
                    contentPadding = PaddingValues(vertical = 16.dp)
                ) {
                    item {
                        Text(
                            text = if (uiState.isTamil) "பிரபலமான வார்ப்புருக்கள்" else "Trending Video Templates",
                            color = TextPrimary,
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "Tap any template to create a ready-to-edit project",
                            color = TextMuted,
                            fontSize = 12.sp
                        )
                        Spacer(modifier = Modifier.height(16.dp))
                    }

                    val templateList = listOf(
                        Triple("Velocity Reels Beat", "9:16", "High-energy fast beat cuts with kinetic zoom transitions"),
                        Triple("Cyberpunk Night Walk", "9:16", "Neon glow color grade with RGB glitch effects"),
                        Triple("Cinematic Travel Vlog", "16:9", "Smooth dissolves, slow-mo curves, and cinematic warmth"),
                        Triple("Retro 90s Camcorder", "4:5", "Vintage tape filter, VHS tracking lines, and warm tones")
                    )

                    items(templateList) { (title, ratio, desc) ->
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    val r = if (ratio == "16:9") AspectRatio.RATIO_16_9 else if (ratio == "4:5") AspectRatio.RATIO_4_5 else AspectRatio.RATIO_9_16
                                    viewModel.createProjectFromTemplate(title, r)
                                },
                            colors = CardDefaults.cardColors(containerColor = DarkSurface),
                            shape = RoundedCornerShape(16.dp),
                            border = androidx.compose.foundation.BorderStroke(1.dp, DarkCardBorder)
                        ) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(text = title, color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                                    Box(
                                        modifier = Modifier
                                            .background(EditorPrimary.copy(alpha = 0.2f), RoundedCornerShape(4.dp))
                                            .padding(horizontal = 6.dp, vertical = 2.dp)
                                    ) {
                                        Text(text = ratio, color = EditorPrimary, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                    }
                                }
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(text = desc, color = TextSecondary, fontSize = 12.sp)
                                Spacer(modifier = Modifier.height(12.dp))
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.End
                                ) {
                                    Button(
                                        onClick = {
                                            val r = if (ratio == "16:9") AspectRatio.RATIO_16_9 else if (ratio == "4:5") AspectRatio.RATIO_4_5 else AspectRatio.RATIO_9_16
                                            viewModel.createProjectFromTemplate(title, r)
                                        },
                                        colors = ButtonDefaults.buttonColors(containerColor = EditorSecondary),
                                        shape = RoundedCornerShape(10.dp),
                                        contentPadding = PaddingValues(horizontal = 14.dp, vertical = 6.dp)
                                    ) {
                                        Text(text = "Use Template", color = Color.Black, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                    }
                                }
                            }
                        }
                        Spacer(modifier = Modifier.height(12.dp))
                    }
                }
            }

            HomeTab.SETTINGS -> {
                // SETTINGS TAB
                var hwAccel by remember { mutableStateOf(true) }
                LazyColumn(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(padding)
                        .padding(horizontal = 20.dp),
                    contentPadding = PaddingValues(vertical = 16.dp)
                ) {
                    item {
                        Text(
                            text = if (uiState.isTamil) "பயன்பாட்டு அமைப்புகள்" else "Application Settings",
                            color = TextPrimary,
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.height(16.dp))
                    }

                    item {
                        Card(
                            colors = CardDefaults.cardColors(containerColor = DarkSurface),
                            shape = RoundedCornerShape(16.dp),
                            border = androidx.compose.foundation.BorderStroke(1.dp, DarkCardBorder),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Text(text = "Export Defaults", color = EditorSecondary, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                Spacer(modifier = Modifier.height(8.dp))
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(text = "Default Resolution", color = TextPrimary, fontSize = 14.sp)
                                    Text(text = "1080p FHD", color = TextMuted, fontSize = 13.sp)
                                }
                                Spacer(modifier = Modifier.height(12.dp))
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(text = "Default FPS", color = TextPrimary, fontSize = 14.sp)
                                    Text(text = "30 fps", color = TextMuted, fontSize = 13.sp)
                                }
                                Spacer(modifier = Modifier.height(12.dp))
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(text = "GPU Hardware Acceleration", color = TextPrimary, fontSize = 14.sp)
                                    Switch(
                                        checked = hwAccel,
                                        onCheckedChange = { hwAccel = it },
                                        colors = SwitchDefaults.colors(
                                            checkedThumbColor = EditorPrimary,
                                            checkedTrackColor = EditorPrimary.copy(alpha = 0.5f)
                                        )
                                    )
                                }
                            }
                        }
                        Spacer(modifier = Modifier.height(16.dp))
                    }

                    item {
                        Card(
                            colors = CardDefaults.cardColors(containerColor = DarkSurface),
                            shape = RoundedCornerShape(16.dp),
                            border = androidx.compose.foundation.BorderStroke(1.dp, DarkCardBorder),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Text(text = "Language & Storage", color = EditorSecondary, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                Spacer(modifier = Modifier.height(8.dp))
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(text = "App Language", color = TextPrimary, fontSize = 14.sp)
                                    Button(
                                        onClick = { viewModel.toggleLanguage() },
                                        colors = ButtonDefaults.buttonColors(containerColor = DarkSurfaceVariant),
                                        shape = RoundedCornerShape(10.dp)
                                    ) {
                                        Text(text = if (uiState.isTamil) "தமிழ்" else "English", color = EditorSecondary)
                                    }
                                }
                                Spacer(modifier = Modifier.height(12.dp))
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(text = "Media Cache", color = TextPrimary, fontSize = 14.sp)
                                    Button(
                                        onClick = {
                                            Toast.makeText(context, "Cache cleared", Toast.LENGTH_SHORT).show()
                                        },
                                        colors = ButtonDefaults.buttonColors(containerColor = DarkSurfaceVariant),
                                        shape = RoundedCornerShape(10.dp)
                                    ) {
                                        Text(text = "Clear Cache", color = TextSecondary, fontSize = 12.sp)
                                    }
                                }
                            }
                        }
                        Spacer(modifier = Modifier.height(16.dp))
                    }

                    item {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 12.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text(text = "Nihaal Cut v1.0.0", color = TextMuted, fontSize = 12.sp)
                                Text(text = "Professional Mobile Video & Photo Editor", color = TextMuted, fontSize = 10.sp)
                            }
                        }
                    }
                }
            }
        }
    }

    if (uiState.showMediaPicker) {
        MediaPickerSheet(viewModel = viewModel, uiState = uiState)
    }
}

@Composable
fun ProjectCardItem(
    project: ProjectEntity,
    isTamil: Boolean,
    onClick: () -> Unit,
    onDelete: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 20.dp)
            .clickable(onClick = onClick)
            .testTag("project_item_${project.id}"),
        colors = CardDefaults.cardColors(containerColor = DarkSurface),
        shape = RoundedCornerShape(14.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, DarkCardBorder)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Thumbnail
            Box(
                modifier = Modifier
                    .size(68.dp, 68.dp)
                    .clip(RoundedCornerShape(10.dp))
                    .background(DarkSurfaceVariant),
                contentAlignment = Alignment.Center
            ) {
                if (!project.thumbnailUri.isNullOrEmpty()) {
                    AsyncImage(
                        model = project.thumbnailUri,
                        contentDescription = project.name,
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize()
                    )
                } else {
                    Icon(
                        imageVector = Icons.Default.Movie,
                        contentDescription = null,
                        tint = EditorSecondary,
                        modifier = Modifier.size(28.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.width(14.dp))

            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = project.name,
                    color = TextPrimary,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    maxLines = 1
                )
                Spacer(modifier = Modifier.height(4.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .background(EditorTertiary.copy(alpha = 0.2f), RoundedCornerShape(4.dp))
                            .padding(horizontal = 6.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = project.aspectPreset,
                            color = EditorTertiary,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "${project.clipCount} clips · ${(project.durationMs / 1000f)}s",
                        color = TextMuted,
                        fontSize = 11.sp
                    )
                }
                Spacer(modifier = Modifier.height(4.dp))
                val dateStr = SimpleDateFormat("MMM d, yyyy", Locale.getDefault()).format(Date(project.modifiedAt))
                Text(
                    text = "Edited $dateStr",
                    color = TextMuted,
                    fontSize = 10.sp
                )
            }

            IconButton(
                onClick = onDelete,
                modifier = Modifier.testTag("delete_project_${project.id}")
            ) {
                Icon(
                    imageVector = Icons.Default.Delete,
                    contentDescription = "Delete",
                    tint = TextMuted
                )
            }
        }
    }
}
