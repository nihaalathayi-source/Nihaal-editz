package com.example.ui.editor

import androidx.activity.compose.BackHandler
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.Animation
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.ContentCut
import androidx.compose.material.icons.filled.Crop
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.EmojiEmotions
import androidx.compose.material.icons.filled.Filter
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Redo
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.TextFields
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material.icons.filled.Undo
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material.icons.filled.ZoomIn
import androidx.compose.material.icons.filled.ZoomOut
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.graphics.ColorMatrix
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import coil.compose.AsyncImage
import com.example.data.local.AppDatabase
import com.example.data.local.ProjectEntity
import com.example.data.local.TimelineClipEntity
import com.example.data.repository.ProjectRepository
import com.example.ui.theme.DarkBackground
import com.example.ui.theme.DarkCardBorder
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.DarkSurfaceVariant
import com.example.ui.theme.EditorAccentYellow
import com.example.ui.theme.EditorPrimary
import com.example.ui.theme.EditorSecondary
import com.example.ui.theme.EditorTertiary
import com.example.ui.theme.SuccessGreen
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import kotlin.math.cos
import kotlin.math.sin

@Composable
fun EditorPreviewStage(
    project: ProjectEntity,
    clips: List<TimelineClipEntity>,
    isTamil: Boolean,
    onBack: () -> Unit
) {
    val context = LocalContext.current
    val repository = remember { ProjectRepository(AppDatabase.getDatabase(context).projectDao()) }
    val editorViewModel = remember { EditorViewModel(repository) }

    LaunchedEffect(project.id) {
        editorViewModel.initProject(project, clips)
    }

    val editorState by editorViewModel.uiState.collectAsStateWithLifecycle()

    BackHandler {
        editorViewModel.pause()
        onBack()
    }

    val aspect = when {
        project.aspectPreset.contains("16:9") -> 16f / 9f
        project.aspectPreset.contains("1:1") -> 1f
        project.aspectPreset.contains("4:5") -> 4f / 5f
        project.aspectPreset.contains("4:3") -> 4f / 3f
        project.aspectPreset.contains("3:4") -> 3f / 4f
        else -> 9f / 16f
    }

    val totalDurationMs = editorViewModel.getTotalDurationMs()
    val activeClipInfo = editorViewModel.getClipAtPosition(editorState.currentPositionMs)
    val activeClip = activeClipInfo?.first
    val clipElapsedMs = activeClipInfo?.second ?: 0L
    val selectedClip = editorState.clips.find { it.id == editorState.selectedClipId } ?: activeClip

    var showAllTransitionsDialog by remember { mutableStateOf(false) }
    var targetTransitionClipId by remember { mutableStateOf<Long?>(null) }
    var showAllAnimationsDialog by remember { mutableStateOf(false) }
    var animDialogGroup by remember { mutableStateOf("IN") }
    var showAllVfxDialog by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(DarkBackground)
            .testTag("editor_screen")
    ) {
        // 1. Top Bar
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(DarkSurface)
                .padding(horizontal = 8.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            IconButton(
                onClick = {
                    editorViewModel.pause()
                    onBack()
                },
                modifier = Modifier.testTag("editor_back_button")
            ) {
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                    contentDescription = "Back",
                    tint = TextPrimary
                )
            }

            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(
                    text = editorState.project?.name ?: project.name,
                    color = TextPrimary,
                    fontWeight = FontWeight.Bold,
                    fontSize = 15.sp,
                    maxLines = 1
                )
                Text(
                    text = "${project.aspectPreset} · ${editorState.clips.size} clips",
                    color = TextMuted,
                    fontSize = 11.sp
                )
            }

            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(
                    onClick = { editorViewModel.undo() },
                    enabled = editorState.canUndo,
                    modifier = Modifier.testTag("editor_undo_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.Undo,
                        contentDescription = "Undo",
                        tint = if (editorState.canUndo) TextPrimary else TextMuted.copy(alpha = 0.4f)
                    )
                }
                IconButton(
                    onClick = { editorViewModel.redo() },
                    enabled = editorState.canRedo,
                    modifier = Modifier.testTag("editor_redo_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.Redo,
                        contentDescription = "Redo",
                        tint = if (editorState.canRedo) TextPrimary else TextMuted.copy(alpha = 0.4f)
                    )
                }
                Button(
                    onClick = { editorViewModel.openExport() },
                    colors = ButtonDefaults.buttonColors(containerColor = EditorPrimary),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.testTag("editor_export_button")
                ) {
                    Text(
                        text = if (isTamil) "ஏற்றுமதி" else "Export",
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp
                    )
                }
            }
        }

        // 2. Video Preview Canvas Area (Live GPU Shaders, Animations, VFX, Transforms)
        Box(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .background(Color.Black)
                .padding(10.dp),
            contentAlignment = Alignment.Center
        ) {
            Box(
                modifier = Modifier
                    .fillMaxHeight(0.97f)
                    .aspectRatio(aspect)
                    .clip(RoundedCornerShape(8.dp))
                    .background(Color(0xFF141720))
                    .border(1.dp, DarkCardBorder, RoundedCornerShape(8.dp))
                    .clickable { editorViewModel.togglePlayPause() }
                    .testTag("preview_canvas_player"),
                contentAlignment = Alignment.Center
            ) {
                val clipToRender = activeClip
                if (clipToRender != null) {
                    val clipDurationMs = editorViewModel.getEffectiveClipDurationMs(clipToRender)
                    val tIn = clipElapsedMs
                    val tOut = (clipDurationMs - clipElapsedMs).coerceAtLeast(0L)

                    // --- ANIMATION CALCULATIONS ---
                    var animAlpha = 1f
                    var animScale = 1f
                    var animRotZ = 0f
                    var animTransX = 0f
                    var animTransY = 0f

                    // 1. IN Animation
                    if (clipToRender.inAnimation != null && tIn < clipToRender.inAnimDurationMs) {
                        val progress = (tIn.toFloat() / clipToRender.inAnimDurationMs).coerceIn(0f, 1f)
                        when (clipToRender.inAnimation) {
                            "fade_in" -> animAlpha *= progress
                            "zoom_in" -> animScale *= (0.3f + 0.7f * progress)
                            "bounce_in" -> animScale *= if (progress < 0.7f) (progress / 0.7f * 1.15f) else (1.15f - (progress - 0.7f) / 0.3f * 0.15f)
                            "slide_up" -> animTransY += (1f - progress) * 200f
                            "slide_down" -> animTransY -= (1f - progress) * 200f
                            "slide_left" -> animTransX += (1f - progress) * 200f
                            "slide_right" -> animTransX -= (1f - progress) * 200f
                            "spin_in" -> animRotZ += (1f - progress) * 360f
                            "pop_in" -> animScale *= progress * progress
                            "glitch_in" -> {
                                animTransX += if (progress < 0.5f) (sin(progress * 40.0) * 16.0).toFloat() else 0f
                                animAlpha *= if (progress < 0.3f) 0.5f else 1f
                            }
                        }
                    }

                    // 2. OUT Animation
                    if (clipToRender.outAnimation != null && tOut < clipToRender.outAnimDurationMs) {
                        val progress = (tOut.toFloat() / clipToRender.outAnimDurationMs).coerceIn(0f, 1f)
                        when (clipToRender.outAnimation) {
                            "fade_out" -> animAlpha *= progress
                            "zoom_out" -> animScale *= (0.3f + 0.7f * progress)
                            "drop_out" -> animTransY += (1f - progress) * 250f
                            "slide_down" -> animTransY += (1f - progress) * 200f
                            "slide_up" -> animTransY -= (1f - progress) * 200f
                            "slide_left" -> animTransX -= (1f - progress) * 200f
                            "slide_right" -> animTransX += (1f - progress) * 200f
                            "spin_out" -> animRotZ += (1f - progress) * 360f
                        }
                    }

                    // 3. COMBO / LOOP Animation
                    if (clipToRender.comboAnimation != null) {
                        val timeSec = (clipElapsedMs / 1000.0) * clipToRender.comboSpeed
                        when (clipToRender.comboAnimation) {
                            "pulse" -> animScale *= (1f + sin(timeSec * 6.0) * 0.08f).toFloat()
                            "float" -> animTransY += (sin(timeSec * 4.0) * 14f).toFloat()
                            "wobble" -> animRotZ += (sin(timeSec * 7.0) * 6f).toFloat()
                            "breathe" -> animScale *= (1f + sin(timeSec * 2.5) * 0.05f).toFloat()
                            "shake" -> {
                                animTransX += (sin(timeSec * 35.0) * 8f).toFloat()
                                animTransY += (cos(timeSec * 35.0) * 8f).toFloat()
                            }
                            "heartbeat" -> {
                                val beat = (sin(timeSec * 5.0).coerceAtLeast(0.0)).toFloat()
                                animScale *= (1f + beat * 0.12f)
                            }
                            "pendulum" -> animRotZ += (sin(timeSec * 3.5) * 12f).toFloat()
                            "strobe" -> {
                                if ((clipElapsedMs / 100) % 2 == 0L) animAlpha *= 0.6f
                            }
                        }
                    }

                    // --- VFX CALCULATIONS ---
                    var vfxShakeX = 0f
                    var vfxShakeY = 0f
                    var vfxScaleBoost = 1f
                    val vfxTime = (editorState.currentPositionMs / 1000.0) * clipToRender.vfxSpeed

                    when (clipToRender.effectName) {
                        "shake" -> {
                            vfxShakeX = (sin(vfxTime * 40.0) * 14f * clipToRender.vfxIntensity).toFloat()
                            vfxShakeY = (cos(vfxTime * 35.0) * 10f * clipToRender.vfxIntensity).toFloat()
                        }
                        "zoom_pulse" -> {
                            vfxScaleBoost = (1f + sin(vfxTime * 8.0) * 0.15f * clipToRender.vfxIntensity).toFloat()
                        }
                        "glitch" -> {
                            if ((editorState.currentPositionMs / 80) % 3 == 0L) {
                                vfxShakeX = (sin(vfxTime * 50.0) * 18f * clipToRender.vfxIntensity).toFloat()
                            }
                        }
                    }

                    // Composite Transforms
                    val totalRotZ = clipToRender.rotation.toFloat() + clipToRender.freeRotation + animRotZ
                    val totalScX = (if (clipToRender.flipH) -1f else 1f) * clipToRender.scale * animScale * vfxScaleBoost
                    val totalScY = (if (clipToRender.flipV) -1f else 1f) * clipToRender.scale * animScale * vfxScaleBoost
                    val totalTx = clipToRender.transX * 3.5f + animTransX + vfxShakeX
                    val totalTy = clipToRender.transY * 3.5f + animTransY + vfxShakeY
                    val contentScale = if (clipToRender.fitMode == "cover") ContentScale.Crop else ContentScale.Fit

                    // Color Matrix for Filter Preset
                    val colorFilter = remember(clipToRender.filterName, clipToRender.filterIntensity, clipToRender.brightness, clipToRender.contrast) {
                        when (clipToRender.filterName) {
                            "B&W" -> ColorFilter.colorMatrix(ColorMatrix().apply { setToSaturation(1f - clipToRender.filterIntensity) })
                            "Vivid" -> ColorFilter.colorMatrix(ColorMatrix().apply { setToSaturation(1f + 0.8f * clipToRender.filterIntensity) })
                            "Warm" -> ColorFilter.tint(Color(0xFFFFA500).copy(alpha = 0.18f * clipToRender.filterIntensity))
                            "Cool" -> ColorFilter.tint(Color(0xFF00BFFF).copy(alpha = 0.18f * clipToRender.filterIntensity))
                            "Vintage" -> ColorFilter.tint(Color(0xFFD2B48C).copy(alpha = 0.28f * clipToRender.filterIntensity))
                            "Cinematic" -> ColorFilter.tint(Color(0xFF00CED1).copy(alpha = 0.16f * clipToRender.filterIntensity))
                            "Cyberpunk" -> ColorFilter.tint(Color(0xFFFF007F).copy(alpha = 0.20f * clipToRender.filterIntensity))
                            "GoldenHour" -> ColorFilter.tint(Color(0xFFFFD700).copy(alpha = 0.22f * clipToRender.filterIntensity))
                            "Emerald" -> ColorFilter.tint(Color(0xFF00FF7F).copy(alpha = 0.16f * clipToRender.filterIntensity))
                            else -> null
                        }
                    }

                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .graphicsLayer {
                                rotationZ = totalRotZ
                                scaleX = totalScX
                                scaleY = totalScY
                                translationX = totalTx
                                translationY = totalTy
                                alpha = animAlpha.coerceIn(0f, 1f)
                            },
                        contentAlignment = Alignment.Center
                    ) {
                        if (!clipToRender.mediaUri.startsWith("sample://") && clipToRender.mediaUri.isNotEmpty()) {
                            if (clipToRender.isVideo) {
                                EditorVideoPlayer(
                                    clips = editorState.clips,
                                    activeClip = clipToRender,
                                    currentPositionMs = editorState.currentPositionMs,
                                    isPlaying = editorState.isPlaying,
                                    modifier = Modifier.fillMaxSize()
                                )
                            } else {
                                AsyncImage(
                                    model = clipToRender.mediaUri,
                                    contentDescription = clipToRender.mediaName,
                                    contentScale = contentScale,
                                    colorFilter = colorFilter,
                                    modifier = Modifier.fillMaxSize()
                                )
                            }
                        } else {
                            Box(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .background(
                                        Brush.verticalGradient(
                                            listOf(Color(0xFF2A1535), Color(0xFF0F172A))
                                        )
                                    ),
                                contentAlignment = Alignment.Center
                            ) {
                                Column(
                                    horizontalAlignment = Alignment.CenterHorizontally,
                                    modifier = Modifier.padding(16.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Movie,
                                        contentDescription = null,
                                        tint = EditorSecondary,
                                        modifier = Modifier.size(44.dp)
                                    )
                                    Spacer(modifier = Modifier.height(8.dp))
                                    Text(
                                        text = clipToRender.mediaName,
                                        color = TextPrimary,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 13.sp
                                    )
                                    Text(
                                        text = "In: ${clipToRender.inAnimation ?: "None"} · VFX: ${clipToRender.effectName ?: "None"}",
                                        color = EditorAccentYellow,
                                        fontSize = 10.sp
                                    )
                                }
                            }
                        }
                    }

                    // VFX Shaders Overlays
                    if (clipToRender.effectName == "flash" && editorState.isPlaying && (editorState.currentPositionMs % 500 < 80)) {
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .background(Color.White.copy(alpha = 0.75f * clipToRender.vfxIntensity))
                        )
                    }
                    if (clipToRender.effectName == "light_leak") {
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .background(
                                    Brush.radialGradient(
                                        listOf(Color(0xFFFF9900).copy(alpha = 0.35f * clipToRender.vfxIntensity), Color.Transparent),
                                        center = Offset(200f, 150f),
                                        radius = 450f
                                    )
                                )
                        )
                    }
                    if (clipToRender.effectName == "vhs" || clipToRender.effectName == "old_tv") {
                        // Scanlines Canvas
                        Canvas(modifier = Modifier.fillMaxSize()) {
                            val lineGap = 6f
                            var y = 0f
                            while (y < size.height) {
                                drawLine(
                                    color = Color.Black.copy(alpha = 0.18f * clipToRender.vfxIntensity),
                                    start = Offset(0f, y),
                                    end = Offset(size.width, y),
                                    strokeWidth = 2f
                                )
                                y += lineGap
                            }
                        }
                    }
                    if (clipToRender.effectName == "edge_glow") {
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .border(4.dp, EditorPrimary.copy(alpha = 0.8f * clipToRender.vfxIntensity), RoundedCornerShape(8.dp))
                        )
                    }
                    if (clipToRender.vignette > 0f) {
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .background(
                                    Brush.radialGradient(
                                        listOf(Color.Transparent, Color.Black.copy(alpha = clipToRender.vignette * 0.85f))
                                    )
                                )
                        )
                    }
                }

                // 3. Render Real-Time Text & Sticker Overlays
                editorState.textLayers.forEach { layer ->
                    val isVisible = editorState.currentPositionMs in layer.startTimeMs until (layer.startTimeMs + layer.durationMs)
                    if (isVisible) {
                        val elapsed = (editorState.currentPositionMs - layer.startTimeMs) / 1000f
                        val animScale by animateFloatAsState(
                            targetValue = if (layer.animType == "pop") {
                                (1f + (sin(elapsed * 8.0) * 0.05f)).toFloat().coerceAtLeast(0.8f)
                            } else 1f,
                            animationSpec = tween(150),
                            label = "TextAnim"
                        )
                        val animAlpha = if (layer.animType == "fade") {
                            (elapsed * 2f).coerceIn(0f, 1f)
                        } else 1f

                        Box(
                            modifier = Modifier
                                .align(Alignment.Center)
                                .offset(
                                    x = ((layer.posX - 0.5f) * 280).dp,
                                    y = ((layer.posY - 0.5f) * 420).dp
                                )
                                .scale(animScale)
                                .alpha(animAlpha)
                                .clip(RoundedCornerShape(8.dp))
                                .background(
                                    when (layer.stylePreset) {
                                        "Pill" -> Color.White
                                        "Typewriter" -> Color.Black.copy(alpha = 0.75f)
                                        else -> Color.Transparent
                                    }
                                )
                                .border(
                                    width = if (layer.stylePreset == "Neon") 1.5.dp else 0.dp,
                                    color = if (layer.stylePreset == "Neon") EditorPrimary else Color.Transparent,
                                    shape = RoundedCornerShape(8.dp)
                                )
                                .padding(horizontal = 8.dp, vertical = 4.dp)
                        ) {
                            Text(
                                text = layer.text,
                                color = when (layer.stylePreset) {
                                    "Pill" -> Color.Black
                                    "Neon" -> EditorPrimary
                                    else -> Color.White
                                },
                                fontWeight = if (layer.stylePreset == "Classic" || layer.stylePreset == "Pill") FontWeight.Bold else FontWeight.Normal,
                                fontStyle = if (layer.stylePreset == "Serif") FontStyle.Italic else FontStyle.Normal,
                                fontFamily = if (layer.stylePreset == "Typewriter") FontFamily.Monospace else FontFamily.Default,
                                fontSize = 18.sp,
                                textAlign = TextAlign.Center
                            )
                        }
                    }
                }

                // Play / Pause overlay indicator
                if (!editorState.isPlaying) {
                    Box(
                        modifier = Modifier
                            .size(52.dp)
                            .clip(CircleShape)
                            .background(Color.Black.copy(alpha = 0.55f))
                            .border(1.dp, Color.White.copy(alpha = 0.4f), CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.PlayArrow,
                            contentDescription = "Play",
                            tint = Color.White,
                            modifier = Modifier.size(30.dp)
                        )
                    }
                }
            }
        }

        // 3. Playback Control Bar (Timecode, Play/Pause, Timeline Zoom)
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(DarkSurface)
                .padding(horizontal = 14.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            val curSec = editorState.currentPositionMs / 1000f
            val totSec = totalDurationMs / 1000f
            Text(
                text = String.format(java.util.Locale.US, "%02d:%04.1f / %02d:%04.1f",
                    (curSec / 60).toInt(), curSec % 60,
                    (totSec / 60).toInt(), totSec % 60
                ),
                color = TextPrimary,
                fontSize = 12.sp,
                fontWeight = FontWeight.SemiBold
            )

            Box(
                modifier = Modifier
                    .size(40.dp)
                    .clip(CircleShape)
                    .background(Color.White)
                    .clickable { editorViewModel.togglePlayPause() }
                    .testTag("timeline_play_pause_button"),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = if (editorState.isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                    contentDescription = if (editorState.isPlaying) "Pause" else "Play",
                    tint = Color.Black,
                    modifier = Modifier.size(24.dp)
                )
            }

            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(
                    onClick = { editorViewModel.setTimelineZoom(editorState.pixelsPerSecond * 0.8f) },
                    modifier = Modifier.size(32.dp).testTag("zoom_out_button")
                ) {
                    Icon(Icons.Default.ZoomOut, contentDescription = "Zoom Out", tint = TextSecondary, modifier = Modifier.size(18.dp))
                }
                IconButton(
                    onClick = { editorViewModel.setTimelineZoom(editorState.pixelsPerSecond * 1.25f) },
                    modifier = Modifier.size(32.dp).testTag("zoom_in_button")
                ) {
                    Icon(Icons.Default.ZoomIn, contentDescription = "Zoom In", tint = TextSecondary, modifier = Modifier.size(18.dp))
                }
            }
        }

        // 4. Interactive Timeline Component (Ruler + Tracks + Trim Handles + Playhead + Split Transitions)
        TimelineView(
            clips = editorState.clips,
            selectedClipId = editorState.selectedClipId,
            currentPositionMs = editorState.currentPositionMs,
            pixelsPerSecond = editorState.pixelsPerSecond,
            totalDurationMs = totalDurationMs,
            onSeekTo = { posMs -> editorViewModel.seekTo(posMs) },
            onSelectClip = { clipId -> editorViewModel.selectClip(clipId) },
            onTrimIn = { id, inMs -> editorViewModel.trimClipIn(id, inMs) },
            onTrimOut = { id, outMs -> editorViewModel.trimClipOut(id, outMs) },
            onCommitTrim = { editorViewModel.commitTrim() },
            onSplitTransitionClick = { nextClipId ->
                targetTransitionClipId = nextClipId
                showAllTransitionsDialog = true
            }
        )

        // 5. Active Tool Panel / Action Bar (Animation, VFX, Transform, Speed, Volume, etc.)
        when (editorState.activeToolPanel) {
            EditorToolPanel.ANIMATION -> {
                selectedClip?.let { clip ->
                    AnimationPanel(
                        clip = clip,
                        isTamil = isTamil,
                        onInAnimChange = { anim, dur -> editorViewModel.updateClipInAnim(clip.id, anim, dur) },
                        onOutAnimChange = { anim, dur -> editorViewModel.updateClipOutAnim(clip.id, anim, dur) },
                        onComboAnimChange = { anim, spd -> editorViewModel.updateClipComboAnim(clip.id, anim, spd) },
                        onBrowseAllClick = { group ->
                            animDialogGroup = group
                            showAllAnimationsDialog = true
                        },
                        onClose = { editorViewModel.closeToolPanel() }
                    )
                }
            }
            EditorToolPanel.VFX, EditorToolPanel.EFFECT -> {
                selectedClip?.let { clip ->
                    VfxPanel(
                        clip = clip,
                        isTamil = isTamil,
                        onEffectChange = { ef, intens, spd -> editorViewModel.updateClipVfx(clip.id, ef, intens, spd) },
                        onFilterChange = { f, intens ->
                            editorViewModel.updateClipFilter(clip.id, f)
                            editorViewModel.updateClipFilterIntensity(clip.id, intens)
                        },
                        onBrowseAllClick = {
                            showAllVfxDialog = true
                        },
                        onClose = { editorViewModel.closeToolPanel() }
                    )
                }
            }
            EditorToolPanel.TRANSFORM -> {
                selectedClip?.let { clip ->
                    TransformPanel(
                        clip = clip,
                        isTamil = isTamil,
                        onRotate = { editorViewModel.rotateClip(clip.id) },
                        onFreeRotateChange = { ang -> editorViewModel.updateClipFreeRotate(clip.id, ang) },
                        onFlipH = { editorViewModel.flipClipH(clip.id) },
                        onFlipV = { editorViewModel.flipClipV(clip.id) },
                        onScaleChange = { sc -> editorViewModel.updateClipTransform(clip.id, sc, clip.transX, clip.transY) },
                        onTransXChange = { tx -> editorViewModel.updateClipTransform(clip.id, clip.scale, tx, clip.transY) },
                        onTransYChange = { ty -> editorViewModel.updateClipTransform(clip.id, clip.scale, clip.transX, ty) },
                        onFitModeChange = { mode -> editorViewModel.updateClipFitMode(clip.id, mode) },
                        onCropRatioChange = { cr -> editorViewModel.updateClipCropRatio(clip.id, cr) },
                        onCenterAlign = { editorViewModel.centerAlignClip(clip.id) },
                        onReset = { editorViewModel.resetClipTransform(clip.id) },
                        onClose = { editorViewModel.closeToolPanel() }
                    )
                }
            }
            EditorToolPanel.SPEED -> {
                selectedClip?.let { clip ->
                    SpeedPanel(
                        clip = clip,
                        isTamil = isTamil,
                        onSpeedChange = { spd: Float -> editorViewModel.updateClipSpeed(clip.id, spd) },
                        onCurveSelect = { crv: String -> editorViewModel.updateClipSpeed(clip.id, clip.speed, crv) },
                        onClose = { editorViewModel.closeToolPanel() }
                    )
                }
            }
            EditorToolPanel.VOLUME -> {
                selectedClip?.let { clip ->
                    VolumePanel(
                        clip = clip,
                        isTamil = isTamil,
                        onVolumeChange = { vol: Float -> editorViewModel.updateClipVolume(clip.id, vol) },
                        onFadeInChange = { fi: Float -> editorViewModel.updateClipFades(clip.id, fi, clip.fadeOutSec) },
                        onFadeOutChange = { fo: Float -> editorViewModel.updateClipFades(clip.id, clip.fadeInSec, fo) },
                        onClose = { editorViewModel.closeToolPanel() }
                    )
                }
            }
            EditorToolPanel.FILTER, EditorToolPanel.ADJUST -> {
                selectedClip?.let { clip ->
                    FilterEffectPanel(
                        clip = clip,
                        isTamil = isTamil,
                        onFilterChange = { f -> editorViewModel.updateClipFilter(clip.id, f) },
                        onFilterIntensityChange = { i -> editorViewModel.updateClipFilterIntensity(clip.id, i) },
                        onEffectChange = { ef -> editorViewModel.updateClipEffect(clip.id, ef) },
                        onBrightnessChange = { b -> editorViewModel.updateClipBrightness(clip.id, b) },
                        onContrastChange = { c -> editorViewModel.updateClipContrast(clip.id, c) },
                        onSaturationChange = { s -> editorViewModel.updateClipSaturation(clip.id, s) },
                        onTemperatureChange = { t -> editorViewModel.updateClipTemperature(clip.id, t) },
                        onBlurChange = {},
                        onVignetteChange = { vg -> editorViewModel.updateClipVignette(clip.id, vg) },
                        onResetAdjustments = { editorViewModel.resetClipAdjustments(clip.id) },
                        onClose = { editorViewModel.closeToolPanel() }
                    )
                }
            }
            EditorToolPanel.TRANSITION, EditorToolPanel.AUDIO -> {
                selectedClip?.let { clip ->
                    TransitionAudioPanel(
                        clip = clip,
                        isTamil = isTamil,
                        onTransitionChange = { tr, dur -> editorViewModel.updateClipTransition(clip.id, tr, dur) },
                        onApplyToAll = { tr, dur -> editorViewModel.applyTransitionToAll(tr, dur) },
                        onClose = { editorViewModel.closeToolPanel() }
                    )
                }
            }
            EditorToolPanel.TEXT, EditorToolPanel.STICKERS -> {
                TextStickerPanel(
                    textLayers = editorState.textLayers,
                    selectedLayerId = editorState.selectedTextLayerId,
                    currentPosMs = editorState.currentPositionMs,
                    isTamil = isTamil,
                    onAddText = { txt, st, col, anim -> editorViewModel.addTextLayer(txt, st, col, anim) },
                    onUpdateLayer = { l -> editorViewModel.updateTextLayer(l) },
                    onDeleteLayer = { id -> editorViewModel.deleteTextLayer(id) },
                    onSelectLayer = { id -> editorViewModel.selectTextLayer(id) },
                    onClose = { editorViewModel.closeToolPanel() }
                )
            }
            EditorToolPanel.NONE -> {
                // Selected Clip Quick Actions Bar
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(DarkSurfaceVariant)
                        .horizontalScroll(rememberScrollState())
                        .padding(horizontal = 12.dp, vertical = 6.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Button(
                        onClick = { editorViewModel.splitAtPlayhead() },
                        colors = ButtonDefaults.buttonColors(containerColor = EditorPrimary),
                        shape = RoundedCornerShape(10.dp),
                        contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 12.dp, vertical = 5.dp),
                        modifier = Modifier.testTag("action_split_button")
                    ) {
                        Icon(Icons.Default.ContentCut, contentDescription = "Split", tint = Color.White, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(text = if (isTamil) "பிரி" else "Split", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    }

                    Button(
                        onClick = { selectedClip?.let { editorViewModel.duplicateClip(it.id) } },
                        enabled = selectedClip != null,
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2C3242), disabledContainerColor = Color(0xFF1E222D)),
                        shape = RoundedCornerShape(10.dp),
                        contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 10.dp, vertical = 5.dp),
                        modifier = Modifier.testTag("action_duplicate_button")
                    ) {
                        Icon(Icons.Default.ContentCopy, contentDescription = null, modifier = Modifier.size(15.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(text = if (isTamil) "நகலெடு" else "Duplicate", fontSize = 12.sp)
                    }

                    Button(
                        onClick = { selectedClip?.let { editorViewModel.moveClip(it.id, -1) } },
                        enabled = selectedClip != null && editorState.clips.indexOfFirst { it.id == selectedClip.id } > 0,
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2C3242), disabledContainerColor = Color(0xFF1E222D)),
                        shape = RoundedCornerShape(10.dp),
                        contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 10.dp, vertical = 5.dp),
                        modifier = Modifier.testTag("action_move_left_button")
                    ) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = null, modifier = Modifier.size(15.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(text = "Left", fontSize = 11.sp)
                    }

                    Button(
                        onClick = { selectedClip?.let { editorViewModel.moveClip(it.id, 1) } },
                        enabled = selectedClip != null && editorState.clips.indexOfFirst { it.id == selectedClip.id } < editorState.clips.lastIndex,
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2C3242), disabledContainerColor = Color(0xFF1E222D)),
                        shape = RoundedCornerShape(10.dp),
                        contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 10.dp, vertical = 5.dp),
                        modifier = Modifier.testTag("action_move_right_button")
                    ) {
                        Text(text = "Right", fontSize = 11.sp)
                        Spacer(modifier = Modifier.width(4.dp))
                        Icon(Icons.AutoMirrored.Filled.ArrowForward, contentDescription = null, modifier = Modifier.size(15.dp))
                    }

                    Button(
                        onClick = { selectedClip?.let { editorViewModel.deleteClip(it.id) } },
                        enabled = selectedClip != null && editorState.clips.size > 1,
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF4A1A24), disabledContainerColor = Color(0xFF1E222D)),
                        shape = RoundedCornerShape(10.dp),
                        contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 10.dp, vertical = 5.dp),
                        modifier = Modifier.testTag("action_delete_clip_button")
                    ) {
                        Icon(Icons.Default.Delete, contentDescription = null, tint = Color(0xFFFF4D4F), modifier = Modifier.size(15.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(text = if (isTamil) "நீக்கு" else "Delete", color = Color(0xFFFF4D4F), fontSize = 12.sp)
                    }
                }
            }
        }

        // 6. Bottom Master Editing Toolstrip (Full Animation, VFX, Transform, Speed, Volume, etc.)
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(DarkBackground)
                .horizontalScroll(rememberScrollState())
                .padding(vertical = 8.dp, horizontal = 12.dp),
            horizontalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            val tools = listOf(
                Triple(Icons.Default.Crop, if (isTamil) "கேன்வாஸ்" else "Canvas", EditorToolPanel.TRANSFORM),
                Triple(Icons.Default.Animation, if (isTamil) "அனிமேஷன்" else "Animation", EditorToolPanel.ANIMATION),
                Triple(Icons.Default.AutoAwesome, if (isTamil) "விஎஃப்எக்ஸ்" else "VFX", EditorToolPanel.VFX),
                Triple(Icons.Default.Speed, if (isTamil) "வேகம்" else "Speed", EditorToolPanel.SPEED),
                Triple(Icons.Default.VolumeUp, if (isTamil) "ஒலியளவு" else "Volume", EditorToolPanel.VOLUME),
                Triple(Icons.Default.Filter, if (isTamil) "வடிகட்டி" else "Filters", EditorToolPanel.FILTER),
                Triple(Icons.Default.TextFields, if (isTamil) "எழுத்து" else "Text", EditorToolPanel.TEXT),
                Triple(Icons.Default.EmojiEmotions, if (isTamil) "ஸ்டிக்கர்" else "Stickers", EditorToolPanel.STICKERS),
                Triple(Icons.Default.Animation, if (isTamil) "மாற்றம்" else "Transition", EditorToolPanel.TRANSITION),
                Triple(Icons.Default.MusicNote, if (isTamil) "இசை" else "Audio", EditorToolPanel.AUDIO),
                Triple(Icons.Default.Tune, if (isTamil) "சரிசெய்" else "Adjust", EditorToolPanel.ADJUST)
            )

            tools.forEach { (icon, name, panel) ->
                val isActive = editorState.activeToolPanel == panel && panel != EditorToolPanel.NONE
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier
                        .width(58.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .background(if (isActive) EditorPrimary.copy(alpha = 0.2f) else Color.Transparent)
                        .clickable {
                            if (panel == EditorToolPanel.TRANSITION) {
                                targetTransitionClipId = selectedClip?.id
                                showAllTransitionsDialog = true
                            } else {
                                editorViewModel.openToolPanel(panel)
                            }
                        }
                        .padding(vertical = 4.dp)
                        .testTag("tool_button_${name.lowercase()}")
                ) {
                    Icon(
                        imageVector = icon,
                        contentDescription = name,
                        tint = if (isActive) EditorPrimary else TextSecondary,
                        modifier = Modifier.size(22.dp)
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = name,
                        color = if (isActive) Color.White else TextSecondary,
                        fontSize = 10.sp,
                        fontWeight = if (isActive) FontWeight.Bold else FontWeight.Medium
                    )
                }
            }
        }
    }

    // 7. Full-Featured Export Dialog Saving Directly to Gallery
    if (editorState.showExportDialog) {
        ExportDialog(
            projectName = editorState.project?.name ?: "NihaalCut_Video",
            clips = editorState.clips,
            totalDurationSecs = totalDurationMs / 1000f,
            isTamil = isTamil,
            onDismiss = { editorViewModel.closeExport() }
        )
    }

    // 8. 500+ Transitions Catalog Dialog (Split Cuts & Clip Transitions)
    if (showAllTransitionsDialog) {
        val targetClip = editorState.clips.find { it.id == targetTransitionClipId } ?: selectedClip
        AllTransitionsSheet(
            currentTransitionName = targetClip?.transitionName,
            currentDurationMs = targetClip?.transitionDurationMs ?: 600L,
            isTamil = isTamil,
            onSelectTransition = { transName, durMs ->
                targetClip?.let { editorViewModel.updateClipTransition(it.id, transName, durMs) }
            },
            onApplyToAll = { transName, durMs ->
                editorViewModel.applyTransitionToAll(transName, durMs)
            },
            onClose = { showAllTransitionsDialog = false }
        )
    }

    // 9. 500+ Animations Catalog Dialog (IN, OUT, COMBO)
    if (showAllAnimationsDialog) {
        val currentClip = selectedClip
        AllAnimationsSheet(
            initialGroup = animDialogGroup,
            currentAnimName = when (animDialogGroup) {
                "OUT" -> currentClip?.outAnimation
                "COMBO" -> currentClip?.comboAnimation
                else -> currentClip?.inAnimation
            },
            currentDurationMs = when (animDialogGroup) {
                "OUT" -> currentClip?.outAnimDurationMs ?: 600L
                else -> currentClip?.inAnimDurationMs ?: 600L
            },
            isTamil = isTamil,
            onSelectAnimation = { group, animName, durMs ->
                currentClip?.let {
                    when (group) {
                        "OUT" -> editorViewModel.updateClipOutAnim(it.id, animName, durMs)
                        "COMBO" -> editorViewModel.updateClipComboAnim(it.id, animName, 1.0f)
                        else -> editorViewModel.updateClipInAnim(it.id, animName, durMs)
                    }
                }
            },
            onClose = { showAllAnimationsDialog = false }
        )
    }

    // 10. 500+ VFX Effects & Color Styles Dialog
    if (showAllVfxDialog) {
        val currentClip = selectedClip
        AllVfxSheet(
            currentEffectName = currentClip?.effectName ?: currentClip?.filterName,
            currentIntensity = currentClip?.vfxIntensity ?: 1.0f,
            currentSpeed = currentClip?.vfxSpeed ?: 1.0f,
            isTamil = isTamil,
            onSelectVfx = { effectName, intensity, speed, isColorGrade ->
                currentClip?.let {
                    if (isColorGrade) {
                        editorViewModel.updateClipVfx(it.id, null, 1f, speed)
                        editorViewModel.updateClipFilter(it.id, effectName)
                        editorViewModel.updateClipFilterIntensity(it.id, intensity)
                    } else {
                        editorViewModel.updateClipFilter(it.id, null)
                        editorViewModel.updateClipVfx(it.id, effectName, intensity, speed)
                    }
                }
            },
            onClose = { showAllVfxDialog = false }
        )
    }
}
