package com.example.ui.editor

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Key
import androidx.compose.material.icons.filled.RestartAlt
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.TabRowDefaults
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.TimelineClipEntity
import com.example.ui.theme.DarkCardBorder
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.DarkSurfaceVariant
import com.example.ui.theme.EditorAccentYellow
import com.example.ui.theme.EditorPrimary
import com.example.ui.theme.EditorSecondary
import com.example.ui.theme.EditorTertiary
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@Composable
fun AnimationPanel(
    clip: TimelineClipEntity,
    isTamil: Boolean,
    onInAnimChange: (String?, Long) -> Unit,
    onOutAnimChange: (String?, Long) -> Unit,
    onComboAnimChange: (String?, Float) -> Unit,
    onBrowseAllClick: (String) -> Unit = {},
    onClose: () -> Unit
) {
    var selectedTab by remember { mutableIntStateOf(0) }
    var inDurMs by remember { androidx.compose.runtime.mutableLongStateOf(clip.inAnimDurationMs) }
    var outDurMs by remember { androidx.compose.runtime.mutableLongStateOf(clip.outAnimDurationMs) }
    var comboSpd by remember { androidx.compose.runtime.mutableFloatStateOf(clip.comboSpeed) }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(DarkSurface)
            .border(1.dp, DarkCardBorder)
            .padding(14.dp)
            .testTag("animation_inspector_panel")
    ) {
        // Header
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            TabRow(
                selectedTabIndex = selectedTab,
                containerColor = Color.Transparent,
                contentColor = EditorPrimary,
                indicator = { tabPositions ->
                    TabRowDefaults.SecondaryIndicator(
                        Modifier.tabIndicatorOffset(tabPositions[selectedTab]),
                        color = EditorPrimary
                    )
                },
                modifier = Modifier.width(280.dp)
            ) {
                Tab(
                    selected = selectedTab == 0,
                    onClick = { selectedTab = 0 },
                    text = { Text(if (isTamil) "உள் (IN)" else "IN", fontSize = 12.sp, fontWeight = FontWeight.Bold) }
                )
                Tab(
                    selected = selectedTab == 1,
                    onClick = { selectedTab = 1 },
                    text = { Text(if (isTamil) "வெளி (OUT)" else "OUT", fontSize = 12.sp, fontWeight = FontWeight.Bold) }
                )
                Tab(
                    selected = selectedTab == 2,
                    onClick = { selectedTab = 2 },
                    text = { Text(if (isTamil) "கலவை (COMBO)" else "COMBO", fontSize = 12.sp, fontWeight = FontWeight.Bold) }
                )
            }

            IconButton(onClick = onClose, modifier = Modifier.size(28.dp)) {
                Icon(Icons.Default.Close, contentDescription = "Close", tint = TextPrimary)
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Browse All 500+ Animations Button
        Button(
            onClick = {
                val group = when (selectedTab) {
                    1 -> "OUT"
                    2 -> "COMBO"
                    else -> "IN"
                }
                onBrowseAllClick(group)
            },
            colors = ButtonDefaults.buttonColors(containerColor = EditorPrimary.copy(alpha = 0.2f)),
            shape = RoundedCornerShape(10.dp),
            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
            modifier = Modifier.fillMaxWidth().testTag("browse_all_animations_button")
        ) {
            Icon(Icons.Default.AutoAwesome, contentDescription = null, tint = EditorPrimary, modifier = Modifier.size(16.dp))
            Spacer(modifier = Modifier.width(6.dp))
            Text(
                text = if (isTamil) "500+ அனிமேஷன்கள் பட்டியலைத் திற (500+ Animations)" else "Browse 500+ Animations Library",
                color = EditorPrimary,
                fontWeight = FontWeight.Bold,
                fontSize = 12.sp
            )
        }

        Spacer(modifier = Modifier.height(8.dp))

        when (selectedTab) {
            0 -> {
                // IN ANIMATIONS
                val inList = listOf(
                    Pair("None", "None"),
                    Pair("fade_in", "Fade In"),
                    Pair("zoom_in", "Zoom In"),
                    Pair("bounce_in", "Bounce"),
                    Pair("slide_up", "Slide Up"),
                    Pair("slide_down", "Slide Down"),
                    Pair("slide_left", "Slide L"),
                    Pair("slide_right", "Slide R"),
                    Pair("spin_in", "Spin In"),
                    Pair("pop_in", "Pop In"),
                    Pair("glitch_in", "Glitch"),
                    Pair("whip_in", "Whip Pan")
                )

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    inList.forEach { (id, label) ->
                        val isSelected = (clip.inAnimation == id) || (clip.inAnimation == null && id == "None")
                        Box(
                            modifier = Modifier
                                .width(74.dp)
                                .height(56.dp)
                                .clip(RoundedCornerShape(10.dp))
                                .background(if (isSelected) EditorPrimary else DarkSurfaceVariant)
                                .border(1.dp, if (isSelected) Color.White else DarkCardBorder, RoundedCornerShape(10.dp))
                                .clickable {
                                    onInAnimChange(if (id == "None") null else id, inDurMs)
                                },
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = label,
                                color = if (isSelected) Color.White else TextPrimary,
                                fontWeight = FontWeight.Bold,
                                fontSize = 11.sp
                            )
                        }
                    }
                }

                if (clip.inAnimation != null) {
                    Spacer(modifier = Modifier.height(10.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = String.format(java.util.Locale.US, "Duration: %.1fs", inDurMs / 1000f),
                            color = TextSecondary,
                            fontSize = 11.sp,
                            modifier = Modifier.width(90.dp)
                        )
                        Slider(
                            value = inDurMs.toFloat(),
                            onValueChange = {
                                inDurMs = it.toLong()
                                onInAnimChange(clip.inAnimation, inDurMs)
                            },
                            valueRange = 100f..3000f,
                            colors = SliderDefaults.colors(
                                thumbColor = EditorPrimary,
                                activeTrackColor = EditorPrimary
                            ),
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
            }
            1 -> {
                // OUT ANIMATIONS
                val outList = listOf(
                    Pair("None", "None"),
                    Pair("fade_out", "Fade Out"),
                    Pair("zoom_out", "Zoom Out"),
                    Pair("slide_down", "Slide Down"),
                    Pair("slide_up", "Slide Up"),
                    Pair("slide_left", "Slide L"),
                    Pair("slide_right", "Slide R"),
                    Pair("spin_out", "Spin Out"),
                    Pair("drop_out", "Drop Out"),
                    Pair("whip_out", "Whip Pan")
                )

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    outList.forEach { (id, label) ->
                        val isSelected = (clip.outAnimation == id) || (clip.outAnimation == null && id == "None")
                        Box(
                            modifier = Modifier
                                .width(74.dp)
                                .height(56.dp)
                                .clip(RoundedCornerShape(10.dp))
                                .background(if (isSelected) EditorSecondary else DarkSurfaceVariant)
                                .border(1.dp, if (isSelected) Color.White else DarkCardBorder, RoundedCornerShape(10.dp))
                                .clickable {
                                    onOutAnimChange(if (id == "None") null else id, outDurMs)
                                },
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = label,
                                color = if (isSelected) Color.Black else TextPrimary,
                                fontWeight = FontWeight.Bold,
                                fontSize = 11.sp
                            )
                        }
                    }
                }

                if (clip.outAnimation != null) {
                    Spacer(modifier = Modifier.height(10.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = String.format(java.util.Locale.US, "Duration: %.1fs", outDurMs / 1000f),
                            color = TextSecondary,
                            fontSize = 11.sp,
                            modifier = Modifier.width(90.dp)
                        )
                        Slider(
                            value = outDurMs.toFloat(),
                            onValueChange = {
                                outDurMs = it.toLong()
                                onOutAnimChange(clip.outAnimation, outDurMs)
                            },
                            valueRange = 100f..3000f,
                            colors = SliderDefaults.colors(
                                thumbColor = EditorSecondary,
                                activeTrackColor = EditorSecondary
                            ),
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
            }
            2 -> {
                // COMBO / LOOP ANIMATIONS
                val comboList = listOf(
                    Pair("None", "None"),
                    Pair("pulse", "Pulse"),
                    Pair("float", "Float Sine"),
                    Pair("wobble", "Wobble"),
                    Pair("breathe", "Breathe"),
                    Pair("shake", "Shake"),
                    Pair("heartbeat", "Heartbeat"),
                    Pair("pendulum", "Pendulum"),
                    Pair("strobe", "Strobe")
                )

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    comboList.forEach { (id, label) ->
                        val isSelected = (clip.comboAnimation == id) || (clip.comboAnimation == null && id == "None")
                        Box(
                            modifier = Modifier
                                .width(74.dp)
                                .height(56.dp)
                                .clip(RoundedCornerShape(10.dp))
                                .background(if (isSelected) EditorTertiary else DarkSurfaceVariant)
                                .border(1.dp, if (isSelected) Color.White else DarkCardBorder, RoundedCornerShape(10.dp))
                                .clickable {
                                    onComboAnimChange(if (id == "None") null else id, comboSpd)
                                },
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = label,
                                color = Color.White,
                                fontWeight = FontWeight.Bold,
                                fontSize = 11.sp
                            )
                        }
                    }
                }

                if (clip.comboAnimation != null) {
                    Spacer(modifier = Modifier.height(10.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = String.format(java.util.Locale.US, "Speed: %.1f×", comboSpd),
                            color = TextSecondary,
                            fontSize = 11.sp,
                            modifier = Modifier.width(90.dp)
                        )
                        Slider(
                            value = comboSpd,
                            onValueChange = {
                                comboSpd = it
                                onComboAnimChange(clip.comboAnimation, comboSpd)
                            },
                            valueRange = 0.2f..3.0f,
                            colors = SliderDefaults.colors(
                                thumbColor = EditorTertiary,
                                activeTrackColor = EditorTertiary
                            ),
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Keyframe Quick Bar
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(8.dp))
                .background(Color(0xFF141923))
                .padding(horizontal = 10.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Key, contentDescription = null, tint = EditorAccentYellow, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text(text = "Keyframes", color = TextPrimary, fontSize = 12.sp, fontWeight = FontWeight.Bold)
            }
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                Button(
                    onClick = { /* Add keyframe */ },
                    colors = ButtonDefaults.buttonColors(containerColor = DarkSurfaceVariant),
                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                    shape = RoundedCornerShape(6.dp)
                ) {
                    Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(12.dp))
                    Text(text = "Keyframe", fontSize = 10.sp)
                }
                Button(
                    onClick = {
                        onInAnimChange(null, 600L)
                        onOutAnimChange(null, 600L)
                        onComboAnimChange(null, 1.0f)
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF382025)),
                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                    shape = RoundedCornerShape(6.dp)
                ) {
                    Icon(Icons.Default.RestartAlt, contentDescription = null, modifier = Modifier.size(12.dp))
                    Text(text = "Reset", fontSize = 10.sp)
                }
            }
        }
    }
}
