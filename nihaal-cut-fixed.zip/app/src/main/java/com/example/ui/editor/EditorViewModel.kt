package com.example.ui.editor

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.ProjectEntity
import com.example.data.local.TextLayerEntity
import com.example.data.local.TimelineClipEntity
import com.example.data.repository.ProjectRepository
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

enum class EditorToolPanel {
    NONE,
    TRANSFORM,
    SPEED,
    VOLUME,
    FILTER,
    EFFECT,
    VFX,
    ANIMATION,
    ADJUST,
    TRANSITION,
    AUDIO,
    TEXT,
    STICKERS
}

data class EditorUiState(
    val project: ProjectEntity? = null,
    val clips: List<TimelineClipEntity> = emptyList(),
    val textLayers: List<TextLayerEntity> = emptyList(),
    val selectedClipId: Long? = null,
    val selectedTextLayerId: Long? = null,
    val currentPositionMs: Long = 0L,
    val isPlaying: Boolean = false,
    val pixelsPerSecond: Float = 40f,
    val canUndo: Boolean = false,
    val canRedo: Boolean = false,
    val activeToolPanel: EditorToolPanel = EditorToolPanel.NONE,
    val showExportDialog: Boolean = false
)

class EditorViewModel(
    private val repository: ProjectRepository
) : ViewModel() {

    private val _uiState = MutableStateFlow(EditorUiState())
    val uiState: StateFlow<EditorUiState> = _uiState.asStateFlow()

    private var playbackJob: Job? = null
    private val undoStack = mutableListOf<Pair<List<TimelineClipEntity>, List<TextLayerEntity>>>()
    private val redoStack = mutableListOf<Pair<List<TimelineClipEntity>, List<TextLayerEntity>>>()

    fun initProject(project: ProjectEntity, initialClips: List<TimelineClipEntity>) {
        _uiState.value = _uiState.value.copy(
            project = project,
            clips = initialClips,
            selectedClipId = initialClips.firstOrNull()?.id,
            currentPositionMs = 0L,
            isPlaying = false,
            activeToolPanel = EditorToolPanel.NONE,
            showExportDialog = false
        )
        undoStack.clear()
        redoStack.clear()
        updateUndoRedoStatus()

        // Load existing text layers from Room
        viewModelScope.launch {
            repository.getTextLayers(project.id).collect { layers ->
                _uiState.value = _uiState.value.copy(textLayers = layers)
            }
        }
    }

    fun openToolPanel(panel: EditorToolPanel) {
        if (_uiState.value.selectedClipId == null && _uiState.value.clips.isNotEmpty()) {
            val clipAtHead = getClipAtPosition(_uiState.value.currentPositionMs)?.first
            _uiState.value = _uiState.value.copy(
                selectedClipId = clipAtHead?.id ?: _uiState.value.clips.first().id
            )
        }
        _uiState.value = _uiState.value.copy(
            activeToolPanel = if (_uiState.value.activeToolPanel == panel) EditorToolPanel.NONE else panel
        )
    }

    fun closeToolPanel() {
        _uiState.value = _uiState.value.copy(activeToolPanel = EditorToolPanel.NONE)
    }

    fun openExport() {
        pause()
        _uiState.value = _uiState.value.copy(showExportDialog = true)
    }

    fun closeExport() {
        _uiState.value = _uiState.value.copy(showExportDialog = false)
    }

    private fun pushUndoState() {
        val currentClips = _uiState.value.clips.map { it.copy() }
        val currentLayers = _uiState.value.textLayers.map { it.copy() }
        undoStack.add(Pair(currentClips, currentLayers))
        if (undoStack.size > 50) undoStack.removeAt(0)
        redoStack.clear()
        updateUndoRedoStatus()
    }

    private fun updateUndoRedoStatus() {
        _uiState.value = _uiState.value.copy(
            canUndo = undoStack.isNotEmpty(),
            canRedo = redoStack.isNotEmpty()
        )
    }

    fun undo() {
        if (undoStack.isEmpty()) return
        pause()
        val currentClips = _uiState.value.clips.map { it.copy() }
        val currentLayers = _uiState.value.textLayers.map { it.copy() }
        redoStack.add(Pair(currentClips, currentLayers))
        val (previousClips, previousLayers) = undoStack.removeAt(undoStack.lastIndex)
        _uiState.value = _uiState.value.copy(
            clips = previousClips,
            textLayers = previousLayers
        )
        updateUndoRedoStatus()
        syncProjectDuration()
    }

    fun redo() {
        if (redoStack.isEmpty()) return
        pause()
        val currentClips = _uiState.value.clips.map { it.copy() }
        val currentLayers = _uiState.value.textLayers.map { it.copy() }
        undoStack.add(Pair(currentClips, currentLayers))
        val (nextClips, nextLayers) = redoStack.removeAt(redoStack.lastIndex)
        _uiState.value = _uiState.value.copy(
            clips = nextClips,
            textLayers = nextLayers
        )
        updateUndoRedoStatus()
        syncProjectDuration()
    }

    fun togglePlayPause() {
        if (_uiState.value.isPlaying) {
            pause()
        } else {
            play()
        }
    }

    fun play() {
        val totalMs = getTotalDurationMs()
        if (totalMs <= 0L) return
        if (_uiState.value.currentPositionMs >= totalMs) {
            _uiState.value = _uiState.value.copy(currentPositionMs = 0L)
        }
        _uiState.value = _uiState.value.copy(isPlaying = true)
        playbackJob?.cancel()
        playbackJob = viewModelScope.launch {
            val tickInterval = 33L // ~30 fps
            while (_uiState.value.isPlaying) {
                delay(tickInterval)
                val current = _uiState.value.currentPositionMs
                val speed = getClipAtPosition(current)?.first?.speed?.coerceIn(0.1f, 4f) ?: 1f
                val newPos = current + (tickInterval * speed).toLong().coerceAtLeast(1L)
                val maxDur = getTotalDurationMs()
                if (newPos >= maxDur) {
                    _uiState.value = _uiState.value.copy(
                        currentPositionMs = maxDur,
                        isPlaying = false
                    )
                    break
                } else {
                    _uiState.value = _uiState.value.copy(currentPositionMs = newPos)
                }
            }
        }
    }

    fun pause() {
        _uiState.value = _uiState.value.copy(isPlaying = false)
        playbackJob?.cancel()
        playbackJob = null
    }

    fun seekTo(positionMs: Long) {
        val maxDur = getTotalDurationMs()
        val clamped = positionMs.coerceIn(0L, maxDur)
        _uiState.value = _uiState.value.copy(currentPositionMs = clamped)
    }

    fun selectClip(clipId: Long?) {
        _uiState.value = _uiState.value.copy(selectedClipId = clipId)
    }

    fun setTimelineZoom(pps: Float) {
        _uiState.value = _uiState.value.copy(
            pixelsPerSecond = pps.coerceIn(15f, 150f)
        )
    }

    fun getTotalDurationMs(): Long {
        return _uiState.value.clips.sumOf { getEffectiveClipDurationMs(it) }
    }

    fun getEffectiveClipDurationMs(clip: TimelineClipEntity): Long {
        val rawDuration = (clip.outMs - clip.inMs).coerceAtLeast(100L)
        val speed = if (clip.speed > 0f) clip.speed else 1f
        return (rawDuration / speed).toLong()
    }

    fun getClipAtPosition(positionMs: Long): Pair<TimelineClipEntity, Long>? {
        var elapsed = 0L
        for (clip in _uiState.value.clips) {
            val clipDuration = getEffectiveClipDurationMs(clip)
            if (positionMs < elapsed + clipDuration || clip == _uiState.value.clips.last()) {
                val offset = (positionMs - elapsed).coerceIn(0L, clipDuration)
                return Pair(clip, offset)
            }
            elapsed += clipDuration
        }
        return null
    }

    fun splitAtPlayhead() {
        val currentPos = _uiState.value.currentPositionMs
        val clips = _uiState.value.clips.toMutableList()
        var elapsed = 0L
        var targetIndex = -1
        var offsetInClip = 0L

        for (i in clips.indices) {
            val clipDur = getEffectiveClipDurationMs(clips[i])
            if (currentPos > elapsed + 100L && currentPos < elapsed + clipDur - 100L) {
                targetIndex = i
                offsetInClip = currentPos - elapsed
                break
            }
            elapsed += clipDur
        }

        if (targetIndex >= 0) {
            pushUndoState()
            val original = clips[targetIndex]
            val speed = if (original.speed > 0f) original.speed else 1f
            val splitTimeInSource = original.inMs + (offsetInClip * speed).toLong()

            val leftClip = original.copy(outMs = splitTimeInSource)
            val rightClip = original.copy(
                id = System.currentTimeMillis(),
                inMs = splitTimeInSource,
                orderIndex = original.orderIndex + 1
            )

            clips[targetIndex] = leftClip
            clips.add(targetIndex + 1, rightClip)

            for (j in (targetIndex + 2)..clips.lastIndex) {
                clips[j] = clips[j].copy(orderIndex = j)
            }

            _uiState.value = _uiState.value.copy(
                clips = clips,
                selectedClipId = rightClip.id
            )
            syncProjectDuration()
        }
    }

    fun trimClipIn(clipId: Long, newInMs: Long) {
        val clips = _uiState.value.clips.toMutableList()
        val index = clips.indexOfFirst { it.id == clipId }
        if (index >= 0) {
            val clip = clips[index]
            val clampedIn = newInMs.coerceIn(0L, clip.outMs - 200L)
            clips[index] = clip.copy(inMs = clampedIn)
            _uiState.value = _uiState.value.copy(clips = clips)
            syncProjectDuration()
        }
    }

    fun trimClipOut(clipId: Long, newOutMs: Long) {
        val clips = _uiState.value.clips.toMutableList()
        val index = clips.indexOfFirst { it.id == clipId }
        if (index >= 0) {
            val clip = clips[index]
            val maxBound = if (clip.originalDurationMs > 0L) clip.originalDurationMs else 60000L
            val clampedOut = newOutMs.coerceIn(clip.inMs + 200L, maxBound)
            clips[index] = clip.copy(outMs = clampedOut)
            _uiState.value = _uiState.value.copy(clips = clips)
            syncProjectDuration()
        }
    }

    fun commitTrim() {
        pushUndoState()
        syncProjectDuration()
    }

    fun deleteClip(clipId: Long) {
        val clips = _uiState.value.clips.toMutableList()
        val index = clips.indexOfFirst { it.id == clipId }
        if (index >= 0) {
            pushUndoState()
            clips.removeAt(index)
            val newSelected = clips.getOrNull(index.coerceAtMost(clips.lastIndex))?.id
            _uiState.value = _uiState.value.copy(
                clips = clips,
                selectedClipId = newSelected
            )
            seekTo(_uiState.value.currentPositionMs)
            syncProjectDuration()
        }
    }

    fun duplicateClip(clipId: Long) {
        val clips = _uiState.value.clips.toMutableList()
        val index = clips.indexOfFirst { it.id == clipId }
        if (index >= 0) {
            pushUndoState()
            val original = clips[index]
            val dup = original.copy(
                id = System.currentTimeMillis(),
                mediaName = "${original.mediaName} (Copy)",
                orderIndex = index + 1
            )
            clips.add(index + 1, dup)
            for (j in (index + 2)..clips.lastIndex) {
                clips[j] = clips[j].copy(orderIndex = j)
            }
            _uiState.value = _uiState.value.copy(
                clips = clips,
                selectedClipId = dup.id
            )
            syncProjectDuration()
        }
    }

    fun moveClip(clipId: Long, delta: Int) {
        val clips = _uiState.value.clips.toMutableList()
        val index = clips.indexOfFirst { it.id == clipId }
        val targetIndex = index + delta
        if (index >= 0 && targetIndex in 0..clips.lastIndex) {
            pushUndoState()
            val item = clips.removeAt(index)
            clips.add(targetIndex, item)
            val reindexed = clips.mapIndexed { i, c -> c.copy(orderIndex = i) }
            _uiState.value = _uiState.value.copy(clips = reindexed)
            syncProjectDuration()
        }
    }

    // --- TRANSFORM, ROTATE, FLIP, SCALE, POSITION, CROP ---

    fun rotateClip(clipId: Long) {
        val clips = _uiState.value.clips.toMutableList()
        val index = clips.indexOfFirst { it.id == clipId }
        if (index >= 0) {
            pushUndoState()
            val clip = clips[index]
            val newRot = (clip.rotation + 90) % 360
            clips[index] = clip.copy(rotation = newRot)
            _uiState.value = _uiState.value.copy(clips = clips)
            syncProjectDuration()
        }
    }

    fun flipClipH(clipId: Long) {
        val clips = _uiState.value.clips.toMutableList()
        val index = clips.indexOfFirst { it.id == clipId }
        if (index >= 0) {
            pushUndoState()
            val clip = clips[index]
            clips[index] = clip.copy(flipH = !clip.flipH)
            _uiState.value = _uiState.value.copy(clips = clips)
            syncProjectDuration()
        }
    }

    fun flipClipV(clipId: Long) {
        val clips = _uiState.value.clips.toMutableList()
        val index = clips.indexOfFirst { it.id == clipId }
        if (index >= 0) {
            pushUndoState()
            val clip = clips[index]
            clips[index] = clip.copy(flipV = !clip.flipV)
            _uiState.value = _uiState.value.copy(clips = clips)
            syncProjectDuration()
        }
    }

    fun updateClipTransform(clipId: Long, scale: Float, transX: Float, transY: Float) {
        val clips = _uiState.value.clips.toMutableList()
        val index = clips.indexOfFirst { it.id == clipId }
        if (index >= 0) {
            val clip = clips[index]
            clips[index] = clip.copy(
                scale = scale.coerceIn(0.5f, 3.0f),
                transX = transX.coerceIn(-60f, 60f),
                transY = transY.coerceIn(-60f, 60f)
            )
            _uiState.value = _uiState.value.copy(clips = clips)
            syncProjectDuration()
        }
    }

    fun updateClipFitMode(clipId: Long, fitMode: String) {
        val clips = _uiState.value.clips.toMutableList()
        val index = clips.indexOfFirst { it.id == clipId }
        if (index >= 0) {
            pushUndoState()
            val clip = clips[index]
            clips[index] = clip.copy(fitMode = fitMode)
            _uiState.value = _uiState.value.copy(clips = clips)
            syncProjectDuration()
        }
    }

    fun resetClipTransform(clipId: Long) {
        val clips = _uiState.value.clips.toMutableList()
        val index = clips.indexOfFirst { it.id == clipId }
        if (index >= 0) {
            pushUndoState()
            val clip = clips[index]
            clips[index] = clip.copy(
                rotation = 0,
                freeRotation = 0f,
                flipH = false,
                flipV = false,
                scale = 1.0f,
                transX = 0f,
                transY = 0f,
                fitMode = "contain",
                cropRatio = null
            )
            _uiState.value = _uiState.value.copy(clips = clips)
            syncProjectDuration()
        }
    }

    fun updateClipFreeRotate(clipId: Long, angle: Float) {
        val clips = _uiState.value.clips.toMutableList()
        val index = clips.indexOfFirst { it.id == clipId }
        if (index >= 0) {
            clips[index] = clips[index].copy(freeRotation = angle % 360f)
            _uiState.value = _uiState.value.copy(clips = clips)
            syncProjectDuration()
        }
    }

    fun updateClipCropRatio(clipId: Long, ratio: String) {
        val clips = _uiState.value.clips.toMutableList()
        val index = clips.indexOfFirst { it.id == clipId }
        if (index >= 0) {
            pushUndoState()
            clips[index] = clips[index].copy(cropRatio = ratio, fitMode = "cover")
            _uiState.value = _uiState.value.copy(clips = clips)
            syncProjectDuration()
        }
    }

    fun centerAlignClip(clipId: Long) {
        val clips = _uiState.value.clips.toMutableList()
        val index = clips.indexOfFirst { it.id == clipId }
        if (index >= 0) {
            pushUndoState()
            clips[index] = clips[index].copy(transX = 0f, transY = 0f)
            _uiState.value = _uiState.value.copy(clips = clips)
            syncProjectDuration()
        }
    }

    // --- ANIMATION ENGINE (IN, OUT, COMBO) ---

    fun updateClipInAnim(clipId: Long, inAnim: String?, durMs: Long) {
        val clips = _uiState.value.clips.toMutableList()
        val index = clips.indexOfFirst { it.id == clipId }
        if (index >= 0) {
            pushUndoState()
            clips[index] = clips[index].copy(
                inAnimation = inAnim,
                inAnimDurationMs = durMs
            )
            _uiState.value = _uiState.value.copy(clips = clips)
            syncProjectDuration()
        }
    }

    fun updateClipOutAnim(clipId: Long, outAnim: String?, durMs: Long) {
        val clips = _uiState.value.clips.toMutableList()
        val index = clips.indexOfFirst { it.id == clipId }
        if (index >= 0) {
            pushUndoState()
            clips[index] = clips[index].copy(
                outAnimation = outAnim,
                outAnimDurationMs = durMs
            )
            _uiState.value = _uiState.value.copy(clips = clips)
            syncProjectDuration()
        }
    }

    fun updateClipComboAnim(clipId: Long, comboAnim: String?, speed: Float) {
        val clips = _uiState.value.clips.toMutableList()
        val index = clips.indexOfFirst { it.id == clipId }
        if (index >= 0) {
            pushUndoState()
            clips[index] = clips[index].copy(
                comboAnimation = comboAnim,
                comboSpeed = speed
            )
            _uiState.value = _uiState.value.copy(clips = clips)
            syncProjectDuration()
        }
    }

    // --- VFX ENGINE ---

    fun updateClipVfx(clipId: Long, effectName: String?, intensity: Float, speed: Float) {
        val clips = _uiState.value.clips.toMutableList()
        val index = clips.indexOfFirst { it.id == clipId }
        if (index >= 0) {
            pushUndoState()
            clips[index] = clips[index].copy(
                effectName = effectName,
                vfxIntensity = intensity.coerceIn(0f, 1f),
                vfxSpeed = speed.coerceIn(0.2f, 3.0f)
            )
            _uiState.value = _uiState.value.copy(clips = clips)
            syncProjectDuration()
        }
    }

    // --- SPEED ---

    fun updateClipSpeed(clipId: Long, speed: Float, curve: String? = null) {
        val clips = _uiState.value.clips.toMutableList()
        val index = clips.indexOfFirst { it.id == clipId }
        if (index >= 0) {
            pushUndoState()
            val clip = clips[index]
            val clamped = speed.coerceIn(0.1f, 4.0f)
            clips[index] = clip.copy(
                speed = clamped,
                speedCurve = curve
            )
            _uiState.value = _uiState.value.copy(clips = clips)
            syncProjectDuration()
        }
    }

    // --- VOLUME & FADES ---

    fun updateClipVolume(clipId: Long, volume: Float) {
        val clips = _uiState.value.clips.toMutableList()
        val index = clips.indexOfFirst { it.id == clipId }
        if (index >= 0) {
            val clip = clips[index]
            clips[index] = clip.copy(volume = volume.coerceIn(0f, 1f))
            _uiState.value = _uiState.value.copy(clips = clips)
            syncProjectDuration()
        }
    }

    fun updateClipFades(clipId: Long, fadeInSec: Float, fadeOutSec: Float) {
        val clips = _uiState.value.clips.toMutableList()
        val index = clips.indexOfFirst { it.id == clipId }
        if (index >= 0) {
            val clip = clips[index]
            clips[index] = clip.copy(
                fadeInSec = fadeInSec.coerceIn(0f, 3f),
                fadeOutSec = fadeOutSec.coerceIn(0f, 3f)
            )
            _uiState.value = _uiState.value.copy(clips = clips)
            syncProjectDuration()
        }
    }

    // --- FILTERS & EFFECTS & ADJUSTMENTS ---

    fun updateClipFilter(clipId: Long, filterName: String?) {
        val clips = _uiState.value.clips.toMutableList()
        val index = clips.indexOfFirst { it.id == clipId }
        if (index >= 0) {
            pushUndoState()
            clips[index] = clips[index].copy(filterName = filterName)
            _uiState.value = _uiState.value.copy(clips = clips)
            syncProjectDuration()
        }
    }

    fun updateClipFilterIntensity(clipId: Long, intensity: Float) {
        val clips = _uiState.value.clips.toMutableList()
        val index = clips.indexOfFirst { it.id == clipId }
        if (index >= 0) {
            clips[index] = clips[index].copy(filterIntensity = intensity.coerceIn(0f, 1f))
            _uiState.value = _uiState.value.copy(clips = clips)
            syncProjectDuration()
        }
    }

    fun updateClipEffect(clipId: Long, effectName: String?) {
        val clips = _uiState.value.clips.toMutableList()
        val index = clips.indexOfFirst { it.id == clipId }
        if (index >= 0) {
            pushUndoState()
            clips[index] = clips[index].copy(effectName = effectName)
            _uiState.value = _uiState.value.copy(clips = clips)
            syncProjectDuration()
        }
    }

    fun updateClipBrightness(clipId: Long, b: Float) {
        val clips = _uiState.value.clips.toMutableList()
        val index = clips.indexOfFirst { it.id == clipId }
        if (index >= 0) {
            clips[index] = clips[index].copy(brightness = b.coerceIn(0.4f, 1.8f))
            _uiState.value = _uiState.value.copy(clips = clips)
            syncProjectDuration()
        }
    }

    fun updateClipContrast(clipId: Long, c: Float) {
        val clips = _uiState.value.clips.toMutableList()
        val index = clips.indexOfFirst { it.id == clipId }
        if (index >= 0) {
            clips[index] = clips[index].copy(contrast = c.coerceIn(0.4f, 1.8f))
            _uiState.value = _uiState.value.copy(clips = clips)
            syncProjectDuration()
        }
    }

    fun updateClipSaturation(clipId: Long, s: Float) {
        val clips = _uiState.value.clips.toMutableList()
        val index = clips.indexOfFirst { it.id == clipId }
        if (index >= 0) {
            clips[index] = clips[index].copy(saturation = s.coerceIn(0f, 2.5f))
            _uiState.value = _uiState.value.copy(clips = clips)
            syncProjectDuration()
        }
    }

    fun updateClipTemperature(clipId: Long, t: Float) {
        val clips = _uiState.value.clips.toMutableList()
        val index = clips.indexOfFirst { it.id == clipId }
        if (index >= 0) {
            clips[index] = clips[index].copy(temperature = t.coerceIn(-1f, 1f))
            _uiState.value = _uiState.value.copy(clips = clips)
            syncProjectDuration()
        }
    }

    fun updateClipVignette(clipId: Long, vg: Float) {
        val clips = _uiState.value.clips.toMutableList()
        val index = clips.indexOfFirst { it.id == clipId }
        if (index >= 0) {
            clips[index] = clips[index].copy(vignette = vg.coerceIn(0f, 1f))
            _uiState.value = _uiState.value.copy(clips = clips)
            syncProjectDuration()
        }
    }

    fun resetClipAdjustments(clipId: Long) {
        val clips = _uiState.value.clips.toMutableList()
        val index = clips.indexOfFirst { it.id == clipId }
        if (index >= 0) {
            pushUndoState()
            clips[index] = clips[index].copy(
                brightness = 1.0f,
                contrast = 1.0f,
                saturation = 1.0f,
                temperature = 0f,
                vignette = 0f,
                blurRadius = 0f
            )
            _uiState.value = _uiState.value.copy(clips = clips)
            syncProjectDuration()
        }
    }

    // --- TRANSITIONS ---

    fun updateClipTransition(clipId: Long, transitionName: String?, durationMs: Long) {
        val clips = _uiState.value.clips.toMutableList()
        val index = clips.indexOfFirst { it.id == clipId }
        if (index >= 0) {
            pushUndoState()
            clips[index] = clips[index].copy(
                transitionName = transitionName,
                transitionDurationMs = durationMs
            )
            _uiState.value = _uiState.value.copy(clips = clips)
            syncProjectDuration()
        }
    }

    fun applyTransitionToAll(transitionName: String?, durationMs: Long) {
        pushUndoState()
        val updated = _uiState.value.clips.map {
            it.copy(transitionName = transitionName, transitionDurationMs = durationMs)
        }
        _uiState.value = _uiState.value.copy(clips = updated)
        syncProjectDuration()
    }

    // --- TEXT & STICKER LAYERS ---

    fun addTextLayer(text: String, style: String, color: Long, anim: String) {
        val projId = _uiState.value.project?.id ?: return
        pushUndoState()
        val newLayer = TextLayerEntity(
            projectId = projId,
            text = text,
            startTimeMs = _uiState.value.currentPositionMs,
            durationMs = 3000L,
            posX = 0.5f,
            posY = 0.75f,
            stylePreset = style,
            textColor = color,
            animType = anim
        )
        val updated = _uiState.value.textLayers + newLayer
        _uiState.value = _uiState.value.copy(
            textLayers = updated,
            selectedTextLayerId = newLayer.id
        )
        viewModelScope.launch {
            repository.saveTextLayers(projId, updated)
        }
    }

    fun updateTextLayer(layer: TextLayerEntity) {
        val projId = _uiState.value.project?.id ?: return
        val current = _uiState.value.textLayers.toMutableList()
        val index = current.indexOfFirst { it.id == layer.id }
        if (index >= 0) {
            current[index] = layer
            _uiState.value = _uiState.value.copy(textLayers = current)
            viewModelScope.launch {
                repository.saveTextLayers(projId, current)
            }
        }
    }

    fun deleteTextLayer(id: Long) {
        val projId = _uiState.value.project?.id ?: return
        pushUndoState()
        val current = _uiState.value.textLayers.filter { it.id != id }
        _uiState.value = _uiState.value.copy(
            textLayers = current,
            selectedTextLayerId = null
        )
        viewModelScope.launch {
            repository.saveTextLayers(projId, current)
        }
    }

    fun selectTextLayer(id: Long?) {
        _uiState.value = _uiState.value.copy(selectedTextLayerId = id)
    }

    private fun syncProjectDuration() {
        val proj = _uiState.value.project ?: return
        val totalMs = getTotalDurationMs()
        val updatedProject = proj.copy(
            durationMs = totalMs,
            clipCount = _uiState.value.clips.size,
            modifiedAt = System.currentTimeMillis()
        )
        _uiState.value = _uiState.value.copy(project = updatedProject)
        viewModelScope.launch {
            repository.saveProjectWithClips(updatedProject, _uiState.value.clips)
        }
    }
}
