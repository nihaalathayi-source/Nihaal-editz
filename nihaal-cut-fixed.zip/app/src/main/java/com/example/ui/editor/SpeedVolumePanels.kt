package com.example.ui.editor

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.VolumeMute
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.TimelineClipEntity
import com.example.ui.theme.DarkCardBorder
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.DarkSurfaceVariant
import com.example.ui.theme.EditorAccentYellow
import com.example.ui.theme.EditorPrimary
import com.example.ui.theme.EditorSecondary
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@Composable
fun SpeedPanel(
    clip: TimelineClipEntity,
    isTamil: Boolean,
    onSpeedChange: (Float) -> Unit,
    onCurveSelect: (String) -> Unit,
    onClose: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(DarkSurface)
            .border(1.dp, DarkCardBorder)
            .padding(14.dp)
            .testTag("speed_inspector_panel")
    ) {
        // Header
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = String.format(java.util.Locale.US, "%s: %.2f×",
                    if (isTamil) "வேகம்" else "Speed", clip.speed),
                color = TextPrimary,
                fontWeight = FontWeight.Bold,
                fontSize = 14.sp
            )
            IconButton(onClick = onClose, modifier = Modifier.size(28.dp)) {
                Icon(Icons.Default.Close, contentDescription = "Close", tint = TextPrimary)
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Speed presets row
        val presets = listOf(0.1f, 0.25f, 0.5f, 0.75f, 1f, 1.25f, 1.5f, 2f, 3f, 4f)
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            presets.forEach { preset ->
                val isSelected = kotlin.math.abs(clip.speed - preset) < 0.05f
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .background(if (isSelected) EditorPrimary else DarkSurfaceVariant)
                        .clickable { onSpeedChange(preset) }
                        .padding(horizontal = 10.dp, vertical = 6.dp)
                ) {
                    Text(
                        text = "${preset}×",
                        color = if (isSelected) Color.White else TextPrimary,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Continuous Slider
        Slider(
            value = clip.speed,
            onValueChange = onSpeedChange,
            valueRange = 0.1f..4.0f,
            colors = SliderDefaults.colors(
                thumbColor = EditorPrimary,
                activeTrackColor = EditorPrimary
            )
        )

        Spacer(modifier = Modifier.height(8.dp))

        // Speed Curves
        Text(
            text = if (isTamil) "வேக வளைவுகள் (Curves)" else "Speed Curves",
            color = TextSecondary,
            fontSize = 12.sp,
            fontWeight = FontWeight.SemiBold
        )
        Spacer(modifier = Modifier.height(6.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            listOf("Standard", "Montage Ramp", "Hero Slow-Mo", "Bullet Time").forEach { curve ->
                val isSelected = clip.speedCurve == curve
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(8.dp))
                        .background(if (isSelected) EditorSecondary.copy(alpha = 0.25f) else DarkSurfaceVariant)
                        .border(
                            1.dp,
                            if (isSelected) EditorSecondary else Color.Transparent,
                            RoundedCornerShape(8.dp)
                        )
                        .clickable { onCurveSelect(curve) }
                        .padding(vertical = 8.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = curve.substringBefore(' '),
                        color = if (isSelected) Color.White else TextSecondary,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    }
}

@Composable
fun VolumePanel(
    clip: TimelineClipEntity,
    isTamil: Boolean,
    onVolumeChange: (Float) -> Unit,
    onFadeInChange: (Float) -> Unit,
    onFadeOutChange: (Float) -> Unit,
    onClose: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(DarkSurface)
            .border(1.dp, DarkCardBorder)
            .padding(14.dp)
            .testTag("volume_inspector_panel")
    ) {
        // Header
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = if (clip.volume == 0f) Icons.Default.VolumeMute else Icons.Default.VolumeUp,
                    contentDescription = null,
                    tint = EditorSecondary,
                    modifier = Modifier.size(20.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = String.format(java.util.Locale.US, "%s: %d%%",
                        if (isTamil) "ஒலியளவு" else "Volume", (clip.volume * 100).toInt()),
                    color = TextPrimary,
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp
                )
            }
            IconButton(onClick = onClose, modifier = Modifier.size(28.dp)) {
                Icon(Icons.Default.Close, contentDescription = "Close", tint = TextPrimary)
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Volume Slider with Mute button
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Slider(
                value = clip.volume,
                onValueChange = onVolumeChange,
                valueRange = 0f..1f,
                colors = SliderDefaults.colors(
                    thumbColor = EditorSecondary,
                    activeTrackColor = EditorSecondary
                ),
                modifier = Modifier.weight(1f)
            )
            Spacer(modifier = Modifier.width(8.dp))
            Button(
                onClick = { onVolumeChange(if (clip.volume > 0f) 0f else 1f) },
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (clip.volume == 0f) EditorPrimary else DarkSurfaceVariant
                ),
                shape = RoundedCornerShape(8.dp),
                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp)
            ) {
                Text(text = if (clip.volume == 0f) "Unmute" else "Mute", fontSize = 11.sp)
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Fade in slider
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = String.format(java.util.Locale.US, "Fade In: %.1fs", clip.fadeInSec),
                color = TextSecondary,
                fontSize = 11.sp,
                modifier = Modifier.width(86.dp)
            )
            Slider(
                value = clip.fadeInSec,
                onValueChange = onFadeInChange,
                valueRange = 0f..3f,
                colors = SliderDefaults.colors(
                    thumbColor = EditorAccentYellow,
                    activeTrackColor = EditorAccentYellow
                ),
                modifier = Modifier.weight(1f)
            )
        }

        // Fade out slider
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = String.format(java.util.Locale.US, "Fade Out: %.1fs", clip.fadeOutSec),
                color = TextSecondary,
                fontSize = 11.sp,
                modifier = Modifier.width(86.dp)
            )
            Slider(
                value = clip.fadeOutSec,
                onValueChange = onFadeOutChange,
                valueRange = 0f..3f,
                colors = SliderDefaults.colors(
                    thumbColor = EditorAccentYellow,
                    activeTrackColor = EditorAccentYellow
                ),
                modifier = Modifier.weight(1f)
            )
        }
    }
}
