package com.example.data.model

enum class AspectRatio(val label: String, val ratio: Float, val iconDescription: String) {
    RATIO_9_16("9:16 Reels", 9f / 16f, "Vertical Reels / Shorts / TikTok"),
    RATIO_16_9("16:9 Cinema", 16f / 9f, "Horizontal YouTube / Landscape"),
    RATIO_1_1("1:1 Square", 1f, "Square Instagram / Post"),
    RATIO_4_5("4:5 Feed", 4f / 5f, "Portrait Instagram Feed"),
    RATIO_4_3("4:3 Standard", 4f / 3f, "Classic Video"),
    RATIO_3_4("3:4 Portrait", 3f / 4f, "Classic Portrait"),
    FIT("Original", 0f, "Original Media Ratio")
}

data class MediaItem(
    val id: String,
    val uri: String,
    val name: String,
    val isVideo: Boolean,
    val durationMs: Long = 0L,
    val width: Int = 1080,
    val height: Int = 1920,
    val thumbnailUri: String? = null,
    val selected: Boolean = false
)
