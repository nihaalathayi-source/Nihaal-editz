package com.example.data.catalog

data class AnimationItem(
    val id: String,
    val name: String,
    val tamilName: String,
    val group: String, // "IN", "OUT", "COMBO"
    val category: String,
    val defaultDurationMs: Long = 600L
)

object AnimationCatalog {
    val groups = listOf("IN", "OUT", "COMBO")

    val inCategories = listOf("All", "Basic Fades", "Zoom & Scale", "Slide & Push", "Spin & 3D", "Bounce & Pop", "Creative & Glitch")
    val outCategories = listOf("All", "Basic Fades", "Zoom & Scale", "Slide & Push", "Spin & 3D", "Drop & Fall", "Creative & Glitch")
    val comboCategories = listOf("All", "Pulse & Heartbeat", "Wave & Float", "Shake & Wobble", "Pendulum & Swing", "Strobe & Disco")

    val allAnimations: List<AnimationItem> by lazy {
        val list = mutableListOf<AnimationItem>()

        // ==========================
        // 1. IN ANIMATIONS (180 items)
        // ==========================
        val inNames = listOf(
            // Basic Fades (25)
            "Fade In Classic", "Fade In Soft", "Fade In Crisp", "Fade In Exponential", "Fade In Linear",
            "Fade In Deep Shadow", "Fade In Bright", "Fade In Ethereal", "Fade In Foggy", "Fade In Warm",
            "Fade In Cool", "Fade In Dreamy", "Fade In Fast Cut", "Fade In Cinematic", "Fade In Velvet",
            "Fade In Silk", "Fade In Charcoal", "Fade In Watercolor", "Fade In Pastel", "Fade In Glow",
            "Fade In Contrast", "Fade In Silhouette", "Fade In Dawn", "Fade In Twilight", "Fade In Twilight Glow",

            // Zoom & Scale (30)
            "Zoom In Smooth", "Zoom In Elastic", "Zoom In Bounce", "Zoom In Pop", "Zoom In Deep Center",
            "Zoom In Snap", "Zoom In Overshoot", "Zoom In Stagger", "Zoom In Wide", "Zoom In Macro",
            "Zoom In Telephoto", "Zoom In Crash", "Zoom In Whiplash", "Zoom In Dynamic", "Zoom In Floating",
            "Zoom In Squeeze", "Zoom In Pulse", "Zoom In Gentle", "Zoom In Rapid", "Zoom In Cinema",
            "Zoom In Spiral", "Zoom In Vortex", "Zoom In Ripple", "Zoom In Hexagon", "Zoom In Diamond",
            "Zoom In Corner TL", "Zoom In Corner TR", "Zoom In Corner BL", "Zoom In Corner BR", "Zoom In Horizon",

            // Slide & Push (35)
            "Slide In Up Swift", "Slide In Down Swift", "Slide In Left Swift", "Slide In Right Swift",
            "Slide In Diagonal TL", "Slide In Diagonal TR", "Slide In Diagonal BL", "Slide In Diagonal BR",
            "Push In Up Smooth", "Push In Down Smooth", "Push In Left Smooth", "Push In Right Smooth",
            "Push In Diagonal TL", "Push In Diagonal TR", "Push In Diagonal BL", "Push In Diagonal BR",
            "Whip Slide Left", "Whip Slide Right", "Whip Slide Up", "Whip Slide Down",
            "Elastic Slide Left", "Elastic Slide Right", "Elastic Slide Up", "Elastic Slide Down",
            "Skylight Drop In", "Floor Lift In", "Side Panel Slide L", "Side Panel Slide R",
            "Parallax Slide In L", "Parallax Slide In R", "Stagger Slide In L", "Stagger Slide In R",
            "Glide In Up Soft", "Glide In Down Soft", "Dash In From Center",

            // Spin & 3D (30)
            "Spin In Clockwise 360°", "Spin In Counter 360°", "Spin In Clockwise 720°", "Spin In Counter 720°",
            "3D Flip In Horizontal", "3D Flip In Vertical", "3D Cube In Left", "3D Cube In Right",
            "3D Door Swing In Left", "3D Door Swing In Right", "3D Box Fall In", "3D Cylinder Spin In",
            "3D Carousel Turn In", "3D Horizon Flip In", "3D Corkscrew Spin In", "3D Barrel Roll In",
            "3D Unfold In Top", "3D Unfold In Bottom", "3D Origami Unfold", "3D Card Reveal In",
            "3D Coin Spin In", "3D Gyroscope In", "3D Tilt Spin In", "3D Tornado Twist In",
            "3D Helix Spin In", "3D Sphere Roll In", "3D Prism Turn In", "3D Tunnel Zoom In",
            "3D Depth Snap In", "3D Space Warp In",

            // Bounce & Pop (30)
            "Bounce In Classic", "Bounce In High Drop", "Bounce In Double", "Bounce In Triple",
            "Bounce In Jelly", "Bounce In Rubber", "Bounce In Spring", "Bounce In Trampoline",
            "Pop In Standard", "Pop In Cartoon", "Pop In Fast Snap", "Pop In Overshoot",
            "Pop In Bubble", "Pop In Balloon", "Pop In Staccato", "Pop In Impact",
            "Drop In Heavy", "Drop In Feather", "Drop In Bouncy", "Drop In Stumble",
            "Elastic Snap In", "Recoil Pop In", "Jack In The Box", "Pogo Bounce In",
            "Rubber Band Snap", "Springboard Leap", "Air Cushion Land", "Soft Pill Pop",
            "Explosive Pop In", "Echo Bounce In",

            // Creative & Glitch (30)
            "Glitch In RGB Split", "Glitch In Digital Tear", "Glitch In VHS Static", "Glitch In Byte Stutter",
            "Glitch In Scanline", "Glitch In Holo Beam", "Glitch In Cyber Dash", "Glitch In Signal Lock",
            "Unfold In Map Style", "Spiral In Galaxy", "Blur Reveal Gaussian", "Blur Reveal Radial",
            "Shutter Flash In", "Light Leak Beam In", "Neon Outline In", "Ink Bleed In",
            "Water Drop Ripple In", "Fire Burn Edge In", "Smoke Cloud Reveal", "Pixelate In 8-Bit",
            "Halftone Dot In", "Prism Rainbow In", "Chromatic Aberration In", "Tape Chew In",
            "CRT TV Power On", "Laser Scan In", "Matrix Code In", "Strobe Flash In",
            "Shockwave Burst In", "Cosmic Stardust In"
        )
        inNames.forEachIndexed { i, name ->
            val cat = when {
                i < 25 -> "Basic Fades"
                i < 55 -> "Zoom & Scale"
                i < 90 -> "Slide & Push"
                i < 120 -> "Spin & 3D"
                i < 150 -> "Bounce & Pop"
                else -> "Creative & Glitch"
            }
            list.add(AnimationItem("in_${i + 1}", name, "உள் $name", "IN", cat))
        }

        // ==========================
        // 2. OUT ANIMATIONS (150 items)
        // ==========================
        val outNames = listOf(
            // Basic Fades (25)
            "Fade Out Classic", "Fade Out Soft", "Fade Out Crisp", "Fade Out Exponential", "Fade Out Linear",
            "Fade Out Deep Shadow", "Fade Out Bright White", "Fade Out Ethereal", "Fade Out Foggy", "Fade Out Warm",
            "Fade Out Cool", "Fade Out Dreamy", "Fade Out Fast Cut", "Fade Out Cinematic", "Fade Out Velvet",
            "Fade Out Silk", "Fade Out Charcoal", "Fade Out Watercolor", "Fade Out Pastel", "Fade Out Glow",
            "Fade Out Contrast", "Fade Out Silhouette", "Fade Out Dusk", "Fade Out Midnight", "Fade Out Sunset Glow",

            // Zoom & Scale (25)
            "Zoom Out Smooth", "Zoom Out Elastic", "Zoom Out Snap", "Zoom Out To Nothing", "Zoom Out To Dot",
            "Zoom Out Wide Sink", "Zoom Out Whiplash", "Zoom Out Dynamic", "Zoom Out Floating", "Zoom Out Squeeze",
            "Zoom Out Pulse Sink", "Zoom Out Gentle", "Zoom Out Rapid", "Zoom Out Cinema", "Zoom Out Spiral",
            "Zoom Out Vortex", "Zoom Out Ripple", "Zoom Out Hexagon", "Zoom Out Diamond", "Zoom Out Corner TL",
            "Zoom Out Corner TR", "Zoom Out Corner BL", "Zoom Out Corner BR", "Zoom Out Horizon", "Zoom Out Black Hole",

            // Slide & Push (30)
            "Slide Out Up Swift", "Slide Out Down Swift", "Slide Out Left Swift", "Slide Out Right Swift",
            "Slide Out Diagonal TL", "Slide Out Diagonal TR", "Slide Out Diagonal BL", "Slide Out Diagonal BR",
            "Push Out Up Smooth", "Push Out Down Smooth", "Push Out Left Smooth", "Push Out Right Smooth",
            "Whip Slide Out Left", "Whip Slide Out Right", "Whip Slide Out Up", "Whip Slide Out Down",
            "Elastic Slide Out L", "Elastic Slide Out R", "Elastic Slide Out U", "Elastic Slide Out D",
            "Skylight Ascend Out", "Floor Drop Out", "Side Panel Exit L", "Side Panel Exit R",
            "Parallax Slide Out L", "Parallax Slide Out R", "Stagger Slide Out L", "Stagger Slide Out R",
            "Glide Out Up Soft", "Glide Out Down Soft",

            // Spin & 3D (25)
            "Spin Out Clockwise 360°", "Spin Out Counter 360°", "Spin Out Clockwise 720°", "Spin Out Counter 720°",
            "3D Flip Out Horizontal", "3D Flip Out Vertical", "3D Cube Out Left", "3D Cube Out Right",
            "3D Door Swing Out L", "3D Door Swing Out R", "3D Box Drop Out", "3D Cylinder Spin Out",
            "3D Carousel Turn Out", "3D Horizon Flip Out", "3D Corkscrew Spin Out", "3D Barrel Roll Out",
            "3D Fold Out Top", "3D Fold Out Bottom", "3D Origami Fold Out", "3D Card Exit Out",
            "3D Coin Spin Out", "3D Gyroscope Out", "3D Tilt Spin Out", "3D Tornado Twist Out", "3D Helix Spin Out",

            // Drop & Fall (20)
            "Drop Down Off Screen", "Fall Back Floor", "Drop Out Heavy", "Drop Out Feather",
            "Drop Out Stumble", "Gravity Collapse Out", "Sink Into Abyss", "Submerge Down Out",
            "Trapdoor Drop Out", "Parachute Fall Out", "Plummet Swift Out", "Tumble Down Left",
            "Tumble Down Right", "Cascade Drop Out", "Slide Down Chute", "Vertical Drain Out",
            "Weight Drop Thud", "Freefall Exit Out", "Pendulum Fall Out", "Avalanche Drop Out",

            // Creative & Glitch (25)
            "Glitch Out RGB Split", "Glitch Out Digital Tear", "Glitch Out VHS Static", "Glitch Out Byte Stutter",
            "Glitch Out Scanline", "Glitch Out Holo Fade", "Glitch Out Signal Lost", "Glitch Out Power Off",
            "Fold Out Letter Style", "Spiral Out Vortex", "Blur Fade Gaussian", "Blur Fade Radial",
            "Shutter Flash Out", "Light Burn Out", "Neon Extinguish Out", "Ink Dissolve Out",
            "Water Evaporate Out", "Fire Ash Fade Out", "Smoke Disperse Out", "Pixelate Out 8-Bit",
            "Halftone Dot Out", "Prism Rainbow Out", "Tape Chew Out", "CRT TV Power Down", "Cosmic Dust Out"
        )
        outNames.forEachIndexed { i, name ->
            val cat = when {
                i < 25 -> "Basic Fades"
                i < 50 -> "Zoom & Scale"
                i < 80 -> "Slide & Push"
                i < 105 -> "Spin & 3D"
                i < 125 -> "Drop & Fall"
                else -> "Creative & Glitch"
            }
            list.add(AnimationItem("out_${i + 1}", name, "வெளி $name", "OUT", cat))
        }

        // ==========================
        // 3. COMBO & LOOP ANIMATIONS (180 items)
        // ==========================
        val comboNames = listOf(
            // Pulse & Heartbeat (35)
            "Pulse Rhythm Standard", "Pulse Rhythm Fast", "Pulse Rhythm Slow", "Pulse Heartbeat Double",
            "Pulse Heartbeat Triple", "Pulse Bass Drop", "Pulse Kick Drum", "Pulse Sub-Bass Swell",
            "Pulse Neon Glow", "Pulse Breathing Deep", "Pulse Breathing Soft", "Pulse Breathing Fast",
            "Pulse Radial Burst", "Pulse Staccato", "Pulse Jelly Wiggle", "Pulse Rubber Elastic",
            "Pulse Spring Tension", "Pulse Zoom Snap", "Pulse Micro Beat", "Pulse Heavy Impact",
            "Pulse Halo Bloom", "Pulse Inverted Flash", "Pulse Audio Wave", "Pulse Dynamic Squeeze",
            "Pulse Scale Pop", "Pulse Euphoria", "Pulse Synthesizer", "Pulse Club Beat",
            "Pulse Trap Snare", "Pulse Lo-Fi Soft", "Pulse Cinematic Hit", "Pulse Heart Strings",
            "Pulse Adrenaline", "Pulse Vital Signs", "Pulse Infinite Loop",

            // Wave & Float (35)
            "Float Sine Wave Up/Down", "Float Sine Wave Left/Right", "Float Diagonal Wave", "Float Figure 8 Orbit",
            "Float Circular Orbit", "Float Ocean Swell", "Float Zero Gravity", "Float Cloud Drift",
            "Float Feather Drift", "Float Balloon Hover", "Float Underwater Drift", "Float Cosmic Float",
            "Float Magnetic Levitate", "Float Hovercraft", "Float Drone Hover", "Float Magic Carpet",
            "Float Gentle Breeze", "Float Thermal Updraft", "Float Helium Lift", "Float Leaf in Wind",
            "Float Ripple Surface", "Float Moonwalk Drift", "Float Starlight Drift", "Float Ethereal Drift",
            "Float Parallax Layer", "Float Fluid Wave", "Float Waveform Sine", "Float Smooth Cruise",
            "Float Dream State", "Float Astral Projection", "Float Serene Glide", "Float Gentle Rocking",
            "Float Suspended Time", "Float Horizon Bob", "Float Buoyant Lift",

            // Shake & Wobble (40)
            "Camera Shake Subtle", "Camera Shake Medium", "Camera Shake Violent", "Camera Shake Handheld POV",
            "Camera Shake Earthquake", "Camera Shake Action Punch", "Camera Shake Gunfire Recoil", "Camera Shake Car Ride",
            "Camera Shake Helicopter", "Camera Shake Speedboat", "Camera Shake Running POV", "Camera Shake Walking Sway",
            "Camera Shake Explosion Hit", "Camera Shake Bass Quake", "Camera Shake Jitter High Freq", "Camera Shake Jitter Low Freq",
            "Wobble Tilt Angle", "Wobble Elastic Jelly", "Wobble Pendulum Swing", "Wobble Teeter Totter",
            "Wobble Drunken Sway", "Wobble Bobble Head", "Wobble Spring Back", "Wobble Rubber Stamp",
            "Wobble Cardboard Flap", "Wobble Water Drop", "Wobble Plate Spin", "Wobble Tuning Fork",
            "Wobble Seismic Tremor", "Wobble Shock Absorption", "Wobble Stumble Step", "Wobble Wind Gust",
            "Wobble Dynamic Balance", "Wobble Tilt Axis X", "Wobble Tilt Axis Y", "Wobble Diagonal Sway",
            "Wobble High Velocity", "Wobble Soft Tremble", "Wobble Unstable Orbit", "Wobble Kinetic Bounce",

            // Pendulum & Swing (35)
            "Pendulum Swing Classic", "Pendulum Swing Wide", "Pendulum Swing Fast", "Pendulum Swing Clock",
            "Pendulum Swing Metronome", "Pendulum Swing Chandelier", "Pendulum Swing Trapeze", "Pendulum Swing Hammock",
            "Pendulum Swing Bell Ring", "Pendulum Swing Rope Swing", "Pendulum Swing Gravity Arc", "Pendulum Swing Newton Cradle",
            "Swing In Left Arc", "Swing In Right Arc", "Swing Pivot Top", "Swing Pivot Bottom",
            "Swing Pivot Left", "Swing Pivot Right", "Swing Gate Open/Close", "Swing Saloon Door",
            "Swing Wind Chime", "Swing Pendulum 3D", "Swing Compound Arc", "Swing Elliptical",
            "Swing Resonant", "Swing Damped Oscillation", "Swing Perpetual", "Swing Kinetic Balance",
            "Swing Gentle Rocker", "Swing Baby Cradle", "Swing Tree Branch", "Swing Ship at Sea",
            "Swing Compass Needle", "Swing Gyro Horizon", "Swing Free Pendulum",

            // Strobe & Disco (35)
            "Strobe Flash High Speed", "Strobe Flash Medium Pace", "Strobe Flash Low Speed", "Strobe Staccato Beat",
            "Strobe Neon Flicker", "Strobe Disco Club", "Strobe Lightning Pulse", "Strobe Camera Flash Array",
            "Strobe Cyber Matrix", "Strobe Rave Strobe", "Strobe Voltage Surge", "Strobe Fluorescent Tube",
            "Strobe Warning Beacon", "Strobe Lighthouse Beam", "Strobe Police Light Shift", "Strobe Fire Alarm Flash",
            "Strobe Subliminal Flash", "Strobe Ghost Frame", "Strobe Jitter Opacity", "Strobe Strobe Glitch",
            "Strobe Sunset Pulse", "Strobe Color Flash RGB", "Strobe Alpha Invert", "Strobe Silhouette Flash",
            "Strobe Solar Flare Hit", "Strobe Particle Spark", "Strobe High Energy Drop", "Strobe Bass Flicker",
            "Strobe Electro Shock", "Strobe Laser Beam Blink", "Strobe Twilight Pulse", "Strobe Intermittent Beam",
            "Strobe Star Blink", "Strobe Hologram Glitch", "Strobe Hyperdrive Pulse"
        )
        comboNames.forEachIndexed { i, name ->
            val cat = when {
                i < 35 -> "Pulse & Heartbeat"
                i < 70 -> "Wave & Float"
                i < 110 -> "Shake & Wobble"
                i < 145 -> "Pendulum & Swing"
                else -> "Strobe & Disco"
            }
            list.add(AnimationItem("combo_${i + 1}", name, "கலவை $name", "COMBO", cat))
        }

        // Count: 180 IN + 150 OUT + 180 COMBO = 510 distinct animations!
        list
    }
}
