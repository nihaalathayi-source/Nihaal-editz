package com.example.data.catalog

data class VfxItem(
    val id: String,
    val name: String,
    val tamilName: String,
    val category: String,
    val isColorGrade: Boolean = false
)

object VfxCatalog {
    val categories = listOf(
        "All",
        "Glitch & Retro Tech",
        "Film & Vintage",
        "Blurs & Optics",
        "Distortions & Warps",
        "Atmospheric & Light",
        "Cinematic Color LUTs"
    )

    val allVfx: List<VfxItem> by lazy {
        val list = mutableListOf<VfxItem>()

        // ======================================
        // 1. Glitch & Retro Tech (90 items)
        // ======================================
        val glitchNames = listOf(
            "RGB Split Glitch", "Retro VHS 1985 Tape", "CRT Monitor Scanlines", "Datamosh Block Artifacts",
            "Digital Signal Noise", "Byte Error Inversion", "Cathode Ray Tube Jump", "Holographic Flickering",
            "Line Tearing Glitch", "Corrupted Video Packet", "Cyberpunk Neon Glitch", "Matrix Digital Rain",
            "Arcade Game CRT", "Thermal Vision Heatmap", "Night Vision Infrared Green", "Old TV Antenna Static",
            "Pixelate 8-Bit Retro", "Pixelate 16-Bit Classic", "Interlaced Scanlines", "Audio React Glitch",
            "Color Channel Scramble", "Magnetic Tape Chew", "VCR Playback Tracking", "VCR Fast Forward Jitter",
            "VCR Rewind Lines", "VCR Blue Screen Freeze", "Analog Sync Loss", "RGB Delay Trail",
            "Chrominance Bleed", "Luminance Noise", "Dithering 1-Bit B&W", "Game Boy Monochrome Green",
            "Virtual Boy Crimson", "C64 Palette Glitch", "NES Color Burst", "Floppy Disk Read Error",
            "Laser Disc Skip", "Satellite Feed Glitch", "Security Cam 480i", "Dashcam Timestamp Overlay",
            "Body Cam Fish Eye", "Drone FPV Static", "Baby Monitor Radio Grain", "Walkie Talkie Video",
            "Strobe Glitch Extreme", "Quantum State Flicker", "Neural Net Glitch", "AI Latent Space Warp",
            "Deep Fry Contrast", "Meme Glitch Impact", "Compression Artifacts", "Macroblock Compression",
            "Frame Drop Stutter", "Broken LCD Screen", "Liquid Crystal Leak", "Phosphor Afterglow",
            "Green Screen Artifact", "Chroma Key Leak", "Bad HDMI Cable", "Signal Lost Color Bars",
            "Static White Noise", "Static Pink Noise", "Audio Spectrum Glitch", "Sub-Zero Freeze Glitch",
            "High Voltage Zap", "Tesla Coil Glitch", "Electromagnetic Pulse", "Solar Radiation Glitch",
            "Radioactive Grain", "Cyber Slicer Horizontal", "Cyber Slicer Vertical", "Glitch Pop Invert",
            "Chromatic Stutter", "RGB Separation Left", "RGB Separation Right", "RGB Separation Top",
            "RGB Separation Bottom", "Ghosting Analog Frame", "Temporal Frame Smear", "De-interlace Lines",
            "Comb Filter Artifact", "PAL System Lines", "NTSC Rainbow Edge", "SECAM Color Shift",
            "Component Video Mismatch", "S-Video Chroma Blur", "Composite Dot Crawl", "RF Modulator Static",
            "Tape Head Dirt", "Video Drum Wobble"
        )
        glitchNames.forEachIndexed { i, name ->
            list.add(VfxItem("vfx_glitch_${i + 1}", name, "கிளிட்ச் $name", "Glitch & Retro Tech"))
        }

        // ======================================
        // 2. Film & Vintage Nostalgia (90 items)
        // ======================================
        val filmNames = listOf(
            "Super 8mm Vintage Film", "16mm Independent Grain", "35mm Hollywood Cinema", "70mm Imax Grain Texture",
            "Sepia Tone 1920s", "Vintage 70s Warmth", "Retro 80s Neon Film", "90s Disposable Camcorder",
            "Kodak Portra 400 Look", "Kodak Tri-X 400 B&W", "Kodak Ektachrome Vivid", "Kodachrome 64 Classic",
            "Fuji Velvia 50 Vibrant", "Fuji Provia 100 Natural", "Fuji Superia 400 Street", "Fuji Neopan 1600 Mono",
            "Ilford HP5 Plus Grain", "Cinestill 800T Halation", "Cinestill 50D Daylight", "Agfa Vista 200 Warm",
            "Polaroid 600 Instant Film", "Polaroid SX-70 Soft", "Dust & Scratches Heavy", "Dust & Scratches Subtle",
            "Film Gate Weave Jitter", "Film Burn Orange Flare", "Film Burn White Edge", "Film Burn Crimson Corner",
            "Light Leak Golden Ray", "Light Leak Sunset Orange", "Light Leak Magenta Glow", "Light Leak Emerald Ray",
            "Film Leader Countdown", "Sprocket Hole Frame", "Film Perforation Border", "Negative Film Inverted",
            "Halation Red Bloom", "Bleach Bypass Contrast", "Cross Processed E-to-C", "Technicolor 3-Strip 1939",
            "Technicolor 2-Strip 1928", "Tintype Antique Metal", "Daguerreotype Silver", "Cyanotype Blueprint",
            "Platinum Palladium Print", "Wet Plate Collodion", "Old Newspaper Halftone", "Yellowed Book Paper",
            "Sepia Matte Finish", "Warm Amber Sunlight", "Cool Vintage Twilight", "Retro Polaroid Border",
            "Faded Memories Tone", "Nostalgia Golden Hour", "Drive-In Movie Screen", "Silent Era Flicker",
            "Orwo Chrom Vintage", "Soviet Svema Film Look", "Konica VX Color Film", "Forte B&W Grain",
            "Film Splice Jump", "Projector Shutter Blade", "Film Melt Heat Burn", "Emulsion Scratches",
            "Darkroom Red Safety", "Solarized Sabattier", "Cyan Vintage Wash", "Amber Sepia Wash",
            "Film Grain ISO 100", "Film Grain ISO 400", "Film Grain ISO 800", "Film Grain ISO 1600",
            "Film Grain ISO 3200", "Film Grain ISO 6400", "Heavy Silver Halide", "Micro Grain Cinematic",
            "Organic Texture Dirt", "Vintage Vignette Round", "Vintage Vignette Square", "Film Frame Letterbox",
            "Academy Ratio 1.37:1", "Widescreen 2.39:1", "Cinerama Curved 2.59", "Ultra Panavision 70",
            "Film Dust Particle Mote", "Camera Gate Hair", "Fingerprint on Lens", "Lens Dust Flecks",
            "Old Lens Scratch", "Scratched Glass Overlay"
        )
        filmNames.forEachIndexed { i, name ->
            list.add(VfxItem("vfx_film_${i + 1}", name, "பிலிம் $name", "Film & Vintage"))
        }

        // ======================================
        // 3. Blurs, Focus & Optics (80 items)
        // ======================================
        val blurNames = listOf(
            "Radial Focus Blur", "Zoom Blur Pulse", "Directional Motion Blur", "Tilt Shift Miniature Lens",
            "Gaussian Soft Focus", "Prism Bokeh Circles", "Anamorphic Streak Blue", "Chromatic Edge Aberration",
            "Double Exposure Blend", "Afterimage Ghost Trail", "Motion Echo Stutter", "Dreamy Halo Glow",
            "Foggy Lens Mist", "Prism Glass Refract", "Kaleidoscope 4-Mirror", "Kaleidoscope 8-Mirror",
            "Kaleidoscope 12-Mirror", "Lens Distort Barrel", "Lens Distort Pincushion", "Fisheye 180° Ultra Wide",
            "Prism Rainbow Split", "Defocus Circle Bokeh", "Defocus Hexagonal Bokeh", "Defocus Heart Bokeh",
            "Defocus Star Bokeh", "Dream Fog Ethereal", "Soft Glamour Glow", "Vaseline Lens Smear",
            "Center Sharp Edge Blur", "Vignette Blur Falloff", "Horizontal Streak Blur", "Vertical Streak Blur",
            "Diagonal Motion Drift", "Spin Blur 360°", "Compound Motion Blur", "Camera Shake Blur",
            "High Speed Shutter Blur", "Slow Shutter Light Trail", "Light Streaks Long Exp", "Ghosting Light Blur",
            "Phosphor Trail Blur", "Water Drop Lens Blur", "Steam Fog Condensation", "Rain Streaks on Lens",
            "Frost Glass Texture", "Fluted Glass Ribs", "Frosted Glass Privacy", "Stained Glass Mosaic",
            "Refraction Water Ripple", "Underwater Optical Blur", "Heat Wave Refraction", "Mirage Shimmer Blur",
            "Anamorphic Horizontal Squeeze", "Anamorphic Vertical Flare", "Spherical Aberration", "Coma Optical Blur",
            "Astigmatism Blur", "Field Curvature Softness", "Vignetting Optical Falloff", "Diffraction Spikes 4-Point",
            "Diffraction Spikes 6-Point", "Diffraction Spikes 8-Point", "Star Filter Optics", "Cross Screen Star Filter",
            "Soft Net Diffusion", "Black Pro-Mist 1/8", "Black Pro-Mist 1/4", "Black Pro-Mist 1/2",
            "Black Pro-Mist 1", "Warm Pro-Mist Filter", "Glimmerglass Diffusion", "Classic Soft Optics",
            "Hollywood Black Magic", "Low Contrast Fog Filter", "Double Fog Atmosphere", "Bifocal Split Lens",
            "Split Field Diopter", "Macro Diopter Shallow", "Perspective Control Tilt", "Swirly Bokeh Petzval"
        )
        blurNames.forEachIndexed { i, name ->
            list.add(VfxItem("vfx_blur_${i + 1}", name, "மங்கல் $name", "Blurs & Optics"))
        }

        // ======================================
        // 4. Distortions & Warps (80 items)
        // ======================================
        val distortNames = listOf(
            "Water Ripple Sine Wave", "Convex Sphere Warp", "Concave Squeeze Mirror", "Twirl Spiral Vortex",
            "Quad Mirror 4-Way", "Horizontal Mirror Dual", "Vertical Mirror Dual", "Octagonal Mirror Symmetry",
            "Halftone Comic Book Dots", "Comic Pencil Sketch B&W", "Comic Color Ink Book", "Neon Contour Glow",
            "Oil Painting Canvas Impasto", "Watercolor Wet Wash", "Emboss 3D Relief", "Invert Color Negative",
            "Psychedelic Rainbow Spiral", "Thermal Heat Gradient", "X-Ray Fluoroscope", "Posterize 4-Level Pop",
            "Posterize 8-Level Retro", "Woodcut Print Texture", "Linocut Print Block", "Charcoal Sketch Rough",
            "Chalk Pastel Smudge", "Engraving Line Art", "Crosshatch Ink Texture", "Stipple Dot Gradient",
            "ASCII Text Matrix", "Glitch Melt Fluid", "Liquid Chrome Mercury", "Molten Gold Surface",
            "Glass Shatter Fragments", "Cracked Mirror Web", "Crystal Shard Multi-Facet", "Hexagonal Grid Mosaic",
            "Triangular Mesh Warp", "Voronoi Cell Texture", "Bubble Lens Bulge", "Pinch Center Vortex",
            "Twist Clockwise 180°", "Twist Counter 180°", "Waveform Ripple High Freq", "Flag Waving Cloth",
            "Curtain Ripple Silk", "Underwater Caustic Warp", "Heat Mirage Wave", "Shockwave Ring Warp",
            "Black Hole Gravity Pull", "Wormhole Space Bend", "Dimensional Rift Tear", "Mirror Ball Sphere",
            "Disco Ball Reflections", "Prism Facet Slices", "Kaleidoscopic Flower", "Tunnel Infinite Mirror",
            "Droste Effect Infinite", "Rubber Sheet Stretch", "Jelly Wobble Fluid", "Blob Morph Organic",
            "Magnetic Attractor Warp", "Electric Arc Distortion", "Plasma Ball Energy", "Magnetic Fluid Ferro",
            "Pixel Sorter Horizontal", "Pixel Sorter Vertical", "Pixel Melt Drip", "Slit Scan Time Smear",
            "Rolling Shutter Jello", "Rolling Shutter Skew", "Wobble Elastic Band", "Fold Origami Crease",
            "Page Curl 3D Corner", "Paper Scrape Texture", "Cardboard Relief 3D", "Glitch Slice Shift",
            "Tile Repeat 2x2", "Tile Repeat 3x3", "Tile Repeat 4x4", "Mirror Kaleidoscope Star"
        )
        distortNames.forEachIndexed { i, name ->
            list.add(VfxItem("vfx_distort_${i + 1}", name, "உருமாற்றம் $name", "Distortions & Warps"))
        }

        // ======================================
        // 5. Atmospheric & Light FX (80 items)
        // ======================================
        val atmoNames = listOf(
            "Golden Sunbeam God Rays", "Rainbow Prism Refraction", "Star Sparkles Diamond", "Golden Shimmer Dust",
            "Fire Embers Rising", "Smoke Cloud Drifting", "Raindrops on Camera Lens", "Gentle Snowfall Flakes",
            "Lightning Storm Strike", "Disco Strobe Colorful", "Neon Aura Outline", "Fairy Lights Twinkle",
            "Laser Beam Horizon Sweep", "Anamorphic Blue Flare", "Warm Sunlight Flare Top", "Cinematic Spotlight Wash",
            "Stage Smoke Fog Mist", "Underwater Bubbles Float", "Firefly Swarm Glowing", "Cosmic Stardust Glint",
            "Northern Lights Aurora", "Volcanic Ash Cloud", "Sandstorm Desert Dust", "Blizzard Snow Gust",
            "Thunderstorm Flash Deep", "Neon Cyber Light Tube", "Plasma Energy Orb", "Electric Lightning Arc",
            "Solar Wind Glow", "Bioluminescence Ocean", "Candlelight Warm Flicker", "Campfire Glow Flames",
            "Streetlight Amber Cone", "Headlights Car Beam", "Searchlight Sky Beam", "Lighthouse Rotating Beam",
            "Neon Sign Buzz Glow", "Fluorescent Tube Flicker", "Incandescent Filament", "Sparkler Firework Trails",
            "Firework Burst Golden", "Firework Burst Colorful", "Confetti Party Shower", "Glitter Powder Explosion",
            "Rose Petals Falling", "Autumn Leaves Drifting", "Cherry Blossom Sakura", "Dandelion Seeds Floating",
            "Soap Bubbles Iridescent", "Prism Rainbow Spray", "Sunbeam Dust Motes", "Morning Mist Rising",
            "Night Fog Ground Rolling", "Haze Heat Wave Shimmer", "Steam Vapor Exhaust", "Ice Frost Edge Growing",
            "Icicle Drip Glimmer", "Meteor Shower Streaks", "Comet Tail Glow", "Supernova Star Burst",
            "Nebula Cosmic Gas", "Black Hole Accretion", "Starlight Twinkle Field", "Milky Way Galaxy Glow",
            "Laser Show Concert", "Stage Pyrotechnics", "Glow Stick Neon Trail", "Fiber Optic Strands",
            "Prism Halo Ring", "Corona Sun Eclipse", "Moonlight Pale Beam", "Twilight Horizon Glow",
            "Golden Hour Sun Halo", "Magic Wand Sparkles", "Enchanted Forest Glow", "Mystic Rune Aura",
            "Cyber Grid Floor Light", "Tron Light Ribbon", "Neon Pulse Ring", "Energy Shield Hexagon"
        )
        atmoNames.forEachIndexed { i, name ->
            list.add(VfxItem("vfx_atmo_${i + 1}", name, "வளிமண்டலம் $name", "Atmospheric & Light"))
        }

        // ======================================
        // 6. Color Grading & Cinematic LUTs (85 items)
        // ======================================
        val colorNames = listOf(
            "Teal & Orange Blockbuster", "Cyberpunk Tokyo Neon", "Golden Hour Warmth", "Emerald Nature Green",
            "Film Noir High Contrast", "Dark Moody Urban Street", "Pastel Dream Sunset", "Warm Cafe Espresso",
            "High Octane Action Punch", "Arctic Cool Glacier", "Vintage Sepia Gold", "Cyber Blue Electric",
            "Sunset Magenta Violet", "Infrared Dream Pink", "Pop Art Vivid Contrast", "Matte Black Minimal",
            "Monochrome Platinum Clean", "Silver Screen Classic 1940", "Hollywood Golden Era", "Bleach Bypass Gritty",
            "Cross Processed Vibrant", "Kodak Warm Glow", "Fuji Cold Crisp", "Cinestill Tungsten Glow",
            "Moody Forest Deep Green", "Desert Sand Warm Amber", "Midnight Deep Blue", "Urban Concrete Desat",
            "Autumn Leaves Crimson", "Spring Floral Soft", "Winter Frost Cyan", "Summer Beach Bright",
            "Low Key Dramatic Shadow", "High Key Airy White", "Vintage 60s Technicolor", "Vintage 70s Earth Tones",
            "Vintage 80s Pastel Neon", "Vintage 90s Grunge Wash", "Y2K Cyber Silver", "Modern Fashion Clean",
            "Vogue Editorial High Fashion", "National Geographic Nature", "Sports Illustrated Vivid", "Music Video Neon Pop",
            "Indie Film Soft Shadows", "A24 Aesthetic Muted", "Wes Anderson Symmetrical Pastel", "Tarantino Warm Punch",
            "Fincher Green Tint Moody", "Nolan Cold Silver", "Villeneuve Desert Tone", "Kubrick Cool Symmetry",
            "Wong Kar-wai Neon Step", "Goth Dark Velvet", "Vampire Crimson Midnight", "Steampunk Copper Rust",
            "Cybernetic Mint Neon", "Solarized Chrome", "Duotone Royal Purple", "Duotone Sunset Yellow",
            "Duotone Cyber Cyan", "Duotone Crimson Black", "Tritone Vintage Gold", "Tritone Ocean Breeze",
            "Warm Highlights Cold Shadows", "Teal Highlights Warm Shadows", "Rose Gold Shimmer", "Champagne Luxury Warm",
            "Deep Emerald Velvet", "Sapphire Night Sky", "Ruby Red Passion", "Amethyst Dream Violet",
            "Topaz Golden Radiance", "Obsidian Black Carbon", "Pearl White Minimal", "Terracotta Clay Warm",
            "Olive Drab Military", "Mustard Vintage Retro", "Coral Reef Vibrant", "Cobalt Deep Ocean",
            "Lilac Soft Romance", "Burgundy Rich Wine", "Charcoal Heavy Contrast", "Ivory Soft Delicate", "Pristine Studio Clean"
        )
        colorNames.forEachIndexed { i, name ->
            list.add(VfxItem("vfx_color_${i + 1}", name, "வண்ணம் $name", "Cinematic Color LUTs", isColorGrade = true))
        }

        // Total: 90 + 90 + 80 + 80 + 80 + 85 = 505 distinct VFX items!
        list
    }
}
