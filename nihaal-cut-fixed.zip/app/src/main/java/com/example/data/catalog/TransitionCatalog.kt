package com.example.data.catalog

data class TransitionItem(
    val id: String,
    val name: String,
    val tamilName: String,
    val category: String,
    val iconDescription: String = "Transition"
)

object TransitionCatalog {
    val categories = listOf(
        "All",
        "Basic & Dissolves",
        "Camera & Pan",
        "3D & Cube",
        "Glitch & Cyber",
        "Light & Flare",
        "Wipes & Shapes",
        "Paper & Slideshow",
        "Cinematic FX"
    )

    val allTransitions: List<TransitionItem> by lazy {
        val list = mutableListOf<TransitionItem>()

        // 1. Basic & Dissolves (60 items)
        val basicNames = listOf(
            "Cross Dissolve", "Fade to Black", "Fade to White", "Blur Dissolve", "Dip to Gray",
            "Double Exposure", "Exponential Fade", "Glow Fade", "Radial Dissolve", "Soft Edge Dissolve",
            "Film Dissolve", "Dreamy Dissolve", "Additive Dissolve", "Non-Additive Mix", "Smooth Cross",
            "Ghost Dissolve", "Luma Dissolve", "Color Dip Amber", "Color Dip Cyan", "Color Dip Crimson",
            "Micro Dissolve", "Fast Dissolve", "Slow Ethereal Fade", "Cross Zoom Fade", "Flash Dissolve",
            "Linear Fade", "Contrast Dissolve", "Vivid Dissolve", "Monochrome Fade", "Warm Wash Fade",
            "Cool Breeze Fade", "Golden Fade", "Shadow Dissolve", "Highlight Dissolve", "Silhouette Fade",
            "Atmosphere Dissolve", "Twilight Fade", "Midnight Melt", "Dawn Dissolve", "Dusk Dip",
            "Velvet Fade", "Silk Dissolve", "Canvas Fade", "Watercolor Melt", "Charcoal Fade",
            "Pastel Dissolve", "Sepia Dip", "Retro Melt", "Vintage Dissolve", "Matte Fade",
            "Aura Dissolve", "Zen Fade", "Crystal Dissolve", "Opal Melt", "Pearl Fade",
            "Silver Dissolve", "Bronze Fade", "Quartz Melt", "Amber Dissolve", "Obsidian Fade"
        )
        basicNames.forEachIndexed { i, name ->
            list.add(TransitionItem("basic_${i + 1}", name, "அடிப்படை $name", "Basic & Dissolves"))
        }

        // 2. Camera & Pan (75 items)
        val cameraNames = listOf(
            "Slide Left", "Slide Right", "Slide Up", "Slide Down", "Push Left", "Push Right",
            "Push Up", "Push Down", "Whip Pan Left", "Whip Pan Right", "Whip Pan Up", "Whip Pan Down",
            "Diagonal Slide TL-BR", "Diagonal Slide TR-BL", "Diagonal Push TL-BR", "Diagonal Push TR-BL",
            "Roll Left 90°", "Roll Right 90°", "Roll 180° Spin", "Roll 360° Barrel", "Squeeze Horizontal",
            "Squeeze Vertical", "Swing In Left", "Swing In Right", "Swing Drop Down", "Swing Flip Up",
            "Crash Zoom In", "Snap Zoom Out", "Vertigo Dolly Zoom", "Orbit Left 180°", "Orbit Right 180°",
            "Tilt Up Swift", "Tilt Down Swift", "Dutch Angle Whip", "Shutter Pan Left", "Shutter Pan Right",
            "Fly Through Center", "Pendulum Swing", "Elastic Whip Left", "Elastic Whip Right",
            "Quick Pan Diagonal", "Jitter Pan Up", "Smooth Glide Left", "Smooth Glide Right",
            "Cinema Crane Up", "Cinema Crane Down", "Drone Flyover", "Drone Orbit", "POV Turn Left",
            "POV Turn Right", "Handheld Shake Whip", "Action Snap Left", "Action Snap Right",
            "Dynamic Swoosh Up", "Dynamic Swoosh Down", "Fisheye Slide", "Parallax Slide Left",
            "Parallax Slide Right", "Multi-Layer Push", "Split Camera Left", "Split Camera Right",
            "Floating Glide", "Steadicam Follow", "Hyperlapse Pan", "Speed Ramp Whip", "Dash Left",
            "Dash Right", "Vault Up", "Dive Down", "Brisk Pan Left", "Brisk Pan Right", "Drift Turn Left",
            "Drift Turn Right", "Spinning Glide", "Velocity Slide"
        )
        cameraNames.forEachIndexed { i, name ->
            list.add(TransitionItem("camera_${i + 1}", name, "கேமரா $name", "Camera & Pan"))
        }

        // 3. 3D & Cube (65 items)
        val cubeNames = listOf(
            "3D Cube Turn Left", "3D Cube Turn Right", "3D Cube Turn Up", "3D Cube Turn Down",
            "3D Flip X Horizontal", "3D Flip Y Vertical", "3D Door Open Left", "3D Door Open Right",
            "3D Double Door Split", "3D Revolving Door", "3D Cylinder Left", "3D Cylinder Right",
            "3D Sphere Rotate", "3D Tunnel Zoom", "3D Hexagon Flip", "3D Prism Rotate",
            "Card Turn Classic", "Flipping Panels 3D", "Rotating Grid 3D", "3D Accordion Fold",
            "3D Accordion Unfold", "3D Carousel Left", "3D Carousel Right", "3D Book Page Flip",
            "3D Cube Zoom Exit", "3D Box Reveal", "3D Pyramid Spin", "3D Diamond Turn",
            "3D Flying Card", "3D Shutter Flip", "3D Floating Tiles", "3D Origami Fold",
            "3D Cuboid Slide", "3D Room Turn Left", "3D Room Turn Right", "3D Horizon Flip",
            "3D Twist Left", "3D Twist Right", "3D Vortex Spin", "3D Spiral Stair",
            "3D Convex Roll", "3D Concave Twist", "3D Pillar Rotate", "3D Window Slat",
            "3D Venetian Flip", "3D Split Flap", "3D Flip Clock", "3D Cube Cascade",
            "3D Matrix Tile Turn", "3D Hex Flip", "3D Block Shift", "3D Parallax Cube",
            "3D Rotating Pillar", "3D Folding Screen", "3D Stage Curvature", "3D Skybox Spin",
            "3D Polygon Warp", "3D Space Warp", "3D Hypercube", "3D Gravity Drop",
            "3D Levitate Up", "3D Ring Turn", "3D Orbiting Slice", "3D Depth Shift", "3D Isometric Snap"
        )
        cubeNames.forEachIndexed { i, name ->
            list.add(TransitionItem("cube_${i + 1}", name, "3D $name", "3D & Cube"))
        }

        // 4. Glitch & Cyber (65 items)
        val glitchNames = listOf(
            "RGB Split Glitch", "Digital Noise Flash", "VHS Tracking Tear", "Datamosh Warp",
            "Scanline Roll Down", "Scanline Roll Up", "Pixel Stutter", "Byte Inversion Glitch",
            "Cyber Grid Pulse", "Static Noise Burst", "Hologram Flicker", "Signal Lost Screen",
            "Color Bleed Glitch", "Matrix Code Wipe", "Glitch Strobe Quick", "Analog Sync Error",
            "VCR Blue Screen", "Audio Waveform Glitch", "Cyber Slicer", "Chromatic Jitter",
            "RGB Shift Left", "RGB Shift Right", "Corrupted Block Tear", "Bad Cable Flash",
            "Laser Line Glitch", "Pixel Melting", "Binary Stream Wipe", "Holo Slice Horizontal",
            "Holo Slice Vertical", "Magnetic Interference", "Glitch Pop Inverted", "Frame Dropper",
            "Tape Chew Glitch", "Cathode Ray Jump", "Displacement Glitch", "CRT Power Down",
            "Cyber Hex Reveal", "Circuit Board Wipe", "Quantum Flicker", "Neural Net Glitch",
            "Pixel Glitch Disperse", "Data Packet Loss", "Glitch Echo", "RGB Waveform Jump",
            "Screen Distortion Jitter", "High Voltage Glitch", "Cyberpunk Strobe", "Arcade Glitch",
            "8-Bit Glitch Warp", "Terminal Crash Wipe", "Sub-Zero Glitch", "Neon Glitch Flare",
            "Interlaced Tear", "Overdrive Glitch", "Pixel Stretch", "Digital Disintegrate",
            "Color Channel Scramble", "Ghosting Artifact", "Temporal Drift", "Byte Shift Wipe",
            "CRT Deflection Error", "Video Tape Static", "Cyber Beam Glitch", "Static Burst Wipe", "Glitch Impact"
        )
        glitchNames.forEachIndexed { i, name ->
            list.add(TransitionItem("glitch_${i + 1}", name, "கிளிட்ச் $name", "Glitch & Cyber"))
        }

        // 5. Light & Flare (65 items)
        val lightNames = listOf(
            "White Flash Strobe", "Warm Anamorphic Flare", "Cool Cyan Flare", "Light Leak Golden",
            "Light Leak Sunset", "Prism Rainbow Sweep", "Sunburst Ray Burst", "Film Burn Flash",
            "Neon Pulse Glow", "Glow Dissolve Bright", "Bokeh Blur Circle", "Directional Lens Flare",
            "Candle Flicker Glow", "Rainbow Light Bloom", "Laser Beam Sweep", "Solar Flare Burst",
            "Vintage Projector Flash", "Golden Hour Glow", "Aurora Borealis Sweep", "Neon Streak Wipe",
            "Prism Split Flare", "Flashbulb Strobe", "Spotlight Sweep Left", "Spotlight Sweep Right",
            "Light Tunnel Zoom", "Soft Fog Glow", "Ethereal Beam", "Halo Glow Bloom",
            "Sparkle Flash", "Glimmer Streak", "Star Lens Flare", "Warm Lamp Glow",
            "Cyber Glow Flash", "Light Leak Crimson", "Light Leak Violet", "Light Leak Emerald",
            "Prism Refraction Sweep", "Sun Flare Top", "Sun Flare Bottom", "Optical Glow Burst",
            "Diffuse Glow Flash", "Incandescent Warm Flare", "Fluorescent Flicker", "Sodium Vapor Glow",
            "Cinema Beam Sweep", "Stage Light Wash", "Ambient Light Bloom", "Luminescence Wipe",
            "Glow Pulse Fast", "Lens Reflection Sweep", "Prism Flare Burst", "Radiant Sun Wipe",
            "Dream Flash White", "Soft Veil Light", "Golden Dust Flare", "Light Ripple Wave",
            "Glow Horizon Sweep", "Prism Orbit Flare", "Blinding Light Burst", "Morning Dew Glow",
            "Sunset Flare Sweep", "Twilight Light Leak", "Crystal Light Refract", "Phosphor Glow", "Lumen Flash"
        )
        lightNames.forEachIndexed { i, name ->
            list.add(TransitionItem("light_${i + 1}", name, "ஒளி $name", "Light & Flare"))
        }

        // 6. Wipes & Shapes (75 items)
        val shapeNames = listOf(
            "Clock Wipe 360°", "Circle Open Center", "Circle Close Center", "Heart Wipe Open",
            "Heart Wipe Close", "Star Wipe 5-Point", "Star Wipe 4-Point", "Diamond Wipe Expand",
            "Diamond Wipe Shrink", "Split Wipe Horizontal", "Split Wipe Vertical", "Diagonal Slice TL",
            "Diagonal Slice TR", "Venetian Blinds Horizontal", "Venetian Blinds Vertical", "Checkerboard Grid",
            "Curtain Open Center", "Curtain Close Center", "Shutter Iris Open", "Shutter Iris Close",
            "Pinwheel Wipe 4-Blade", "Pinwheel Wipe 8-Blade", "Spiral Wipe Expanding", "Spiral Wipe Contracting",
            "Honeycomb Hex Reveal", "Triangular Wipe Left", "Triangular Wipe Right", "Mosaic Disintegrate",
            "Linear Wipe Left", "Linear Wipe Right", "Linear Wipe Up", "Linear Wipe Down",
            "Center Box Wipe", "Cross Wipe", "Plus Sign Expand", "Multi-Bar Horizontal",
            "Multi-Bar Vertical", "Random Bars Wipe", "Circular Ripple Wipe", "Water Drop Wipe",
            "Radial Clock Inverted", "Radial Fan Wipe", "Dual Circle Split", "Oval Mask Wipe",
            "Rhombus Reveal", "Trapezoid Wipe", "Pentagon Expand", "Octagon Iris Wipe",
            "Grid Tile Scatter", "Blinds Reveal Slow", "Stripe Sweep 45°", "Chevron Arrow Left",
            "Chevron Arrow Right", "Arrow Down Wipe", "Arrow Up Wipe", "Crosshair Wipe",
            "Target Ring Wipe", "Waveform Shape Wipe", "Burst Star 8-Point", "Spark Shape Expand",
            "Puzzle Piece Wipe", "Zigzag Wipe Horizontal", "Zigzag Wipe Vertical", "Wave Strip Wipe",
            "Multi-Slice Horizontal", "Multi-Slice Vertical", "Pixel Grid Reveal", "Block Wipe Cascade",
            "Window Shade Up", "Window Shade Down", "Barn Door Open", "Barn Door Close",
            "Corner Sweep TL", "Corner Sweep BR", "Circle Wipe Invert"
        )
        shapeNames.forEachIndexed { i, name ->
            list.add(TransitionItem("shape_${i + 1}", name, "வடிவம் $name", "Wipes & Shapes"))
        }

        // 7. Paper & Slideshow (60 items)
        val paperNames = listOf(
            "Page Curl Corner TL", "Page Curl Corner BR", "Scrapbook Tape Peel", "Polaroid Photo Drop",
            "Film Reel Strip Horizontal", "Film Reel Strip Vertical", "Torn Paper Horizontal", "Torn Paper Vertical",
            "Paper Fold 3D Halves", "Paper Fold 3D Quarters", "Burning Film Edge", "Ink Stamp Drop",
            "Adhesive Tape Pull", "Postcard Flip 3D", "Comic Book Panel Shift", "Playing Card Shuffle",
            "Vintage Slide Projector", "Film Negative Strip", "Notebook Page Turn", "Magazine Spread Fold",
            "Paper Crumple Open", "Paper Air Plane Fly", "Sketchbook Flip", "Cardboard Slide",
            "Envelope Open Reveal", "Calendar Page Tear", "Card Stack Drop", "Polaroid Stack Shuffle",
            "Photo Album Turn", "Sticky Note Peel", "Old Map Unfold", "Billboard Flap",
            "Film Leader Countdown", "Sprocket Hole Slide", "Contact Sheet Shift", "Blueprint Roll Open",
            "Newspaper Press Wipe", "Ticket Stub Tear", "Poster Peel Down", "Foil Wrapper Tear",
            "Card Deck Cut", "Bookmark Slide", "Scroll Roll Open", "Scroll Roll Close",
            "Origami Bird Fold", "Origami Box Unfold", "Card Fan Reveal", "Receipt Print Roll",
            "Passport Stamp Shift", "Film Clapper Snap", "Drafting Table Shift", "Color Palette Swipe",
            "Sticker Peel Left", "Sticker Peel Right", "Wax Seal Melt", "Vintage Card Snap",
            "Photo Frame Slide", "Matte Board Drop", "Slide Carousel Click", "Paper Texture Melt"
        )
        paperNames.forEachIndexed { i, name ->
            list.add(TransitionItem("paper_${i + 1}", name, "காகிதம் $name", "Paper & Slideshow"))
        }

        // 8. Cinematic FX (60 items)
        val cinematicNames = listOf(
            "Smoke Cloud Dissolve", "Ink Splash Dispersion", "Water Ripple Wave", "Glass Shatter Realistic",
            "Fire Flame Wipe Up", "Raindrop Splash Blur", "Desert Sandstorm Drift", "Particle Spark Dissolve",
            "Golden Ember Rise", "Cosmic Stardust Drift", "Lightning Strike Flash", "Energy Shockwave Wave",
            "Space Warp Speed", "Underwater Bubble Burst", "Snow Frost Freeze", "Ice Crack Shatter",
            "Meteor Streak Flash", "Volcanic Ash Cloud", "Prism Rainbow Burst", "Fluid Color Mixing",
            "Aurora Wave Swirl", "Galactic Vortex Spin", "Cyber Portal Open", "Dark Matter Vapor",
            "Crystal Shard Scatter", "Time Warp Echo", "Nebula Cloud Drift", "Liquid Metal Flow",
            "Heat Distortion Shimmer", "Echo Chamber Blur", "Chamber Reverberation", "Prism Reflection Burst",
            "Supernova Flash", "Solar Wind Breeze", "Deep Sea Current", "Magma Glow Wipe",
            "Thundercloud Darken", "Blizzard Whiteout", "Tornado Spin Wipe", "Avalanche Slide",
            "Shockwave Ground Slam", "Soundwave Ring Expand", "Plasma Arc Jump", "Laser Grid Dissolve",
            "Vortex Tunnel Sink", "Dimension Rift Open", "Quantum Tunnel Swirl", "Gravity Well Pull",
            "Starlight Shimmer", "Neon Lightning Burst", "Cosmic Dust Scatter", "Firefly Glow Swarm",
            "Crystal Growth Wipe", "Amber Resin Freeze", "Opal Iridescence Melt", "Solar Flare Wave",
            "Deep Space Drift", "Cinematic Motion Blur", "Film Grain Dissolve", "Action Impact Flash"
        )
        cinematicNames.forEachIndexed { i, name ->
            list.add(TransitionItem("cinematic_${i + 1}", name, "சினிமா $name", "Cinematic FX"))
        }

        // Check count: 60 + 75 + 65 + 65 + 65 + 75 + 60 + 60 = 525 transitions!
        list
    }
}
