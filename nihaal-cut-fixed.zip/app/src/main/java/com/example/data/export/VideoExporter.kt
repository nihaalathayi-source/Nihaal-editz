@file:OptIn(androidx.media3.common.util.UnstableApi::class)

package com.example.data.export

import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.util.Log
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.audio.SpeedProvider
import androidx.media3.effect.Presentation
import androidx.media3.transformer.Composition
import androidx.media3.transformer.EditedMediaItem
import androidx.media3.transformer.EditedMediaItemSequence
import androidx.media3.transformer.Effects
import androidx.media3.transformer.ExportException
import androidx.media3.transformer.ProgressHolder
import androidx.media3.transformer.Transformer
import com.example.data.local.TimelineClipEntity
import com.example.data.media.VideoEffectEngine
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

object VideoExporter {

    data class ExportConfig(
        val resolutionWidth: Int = 1080,
        val resolutionHeight: Int = 1920,
        val fps: Int = 30,
        val bitrate: Int = 4_000_000,
        val durationMs: Long = 5000L
    )

    suspend fun exportProjectToGallery(
        context: Context,
        projectName: String,
        clips: List<TimelineClipEntity>,
        config: ExportConfig,
        onProgress: (Float, String) -> Unit
    ): Uri? {
        val validClips = clips
            .sortedBy { it.orderIndex }
            .filter { it.mediaUri.isNotBlank() && !it.mediaUri.startsWith("sample://") }

        if (validClips.isEmpty()) {
            onProgress(0f, "Add a real video or photo before exporting.")
            return null
        }

        val cleanName = projectName.replace("[^a-zA-Z0-9_-]".toRegex(), "_")
        val fileName = "${cleanName}_${System.currentTimeMillis()}.mp4"
        val tempFile = File(context.cacheDir, fileName)
        if (tempFile.exists()) tempFile.delete()

        return try {
            onProgress(0.03f, "Preparing ${validClips.size} clips...")
            val editedItems = validClips.map { clip -> buildEditedItem(clip, config) }
            val sequence = EditedMediaItemSequence.withAudioAndVideoFrom(editedItems)
            val composition = Composition.Builder(sequence).build()

            onProgress(0.07f, "Rendering real video, audio, speed and effects...")

            val exportResult = withContext(Dispatchers.Main.immediate) {
                val result = CompletableDeferred<Result<androidx.media3.transformer.ExportResult>>()
                val transformer = Transformer.Builder(context)
                    .setVideoMimeType("video/avc")
                    .setPortraitEncodingEnabled(true)
                    .addListener(object : Transformer.Listener {
                        override fun onCompleted(
                            completedComposition: Composition,
                            exportResult: androidx.media3.transformer.ExportResult
                        ) {
                            result.complete(Result.success(exportResult))
                        }

                        override fun onError(
                            failedComposition: Composition,
                            exportResult: androidx.media3.transformer.ExportResult,
                            exception: ExportException
                        ) {
                            result.complete(Result.failure(exception))
                        }

                        override fun onFallbackApplied(
                            fallbackComposition: Composition,
                            originalTransformationRequest: androidx.media3.transformer.TransformationRequest,
                            fallbackTransformationRequest: androidx.media3.transformer.TransformationRequest
                        ) = Unit
                    })
                    .build()

                val progressScope = CoroutineScope(Dispatchers.Main.immediate + SupervisorJob())
                progressScope.launch {
                    val holder = ProgressHolder()
                    while (!result.isCompleted) {
                        val state = transformer.getProgress(holder)
                        val progress = when (state) {
                            Transformer.PROGRESS_STATE_AVAILABLE -> holder.progress / 100f
                            else -> 0f
                        }
                        onProgress(0.08f + progress * 0.82f, "Exporting… ${(progress * 100).toInt()}%")
                        delay(250L)
                    }
                }

                try {
                    transformer.start(composition, tempFile.absolutePath)
                    result.await()
                } finally {
                    progressScope.cancel()
                }
            }

            exportResult.getOrElse { throw it }
            if (!tempFile.exists() || tempFile.length() < 1024L) {
                throw IllegalStateException("Transformer completed without a valid MP4 output")
            }

            onProgress(0.93f, "Saving finished video to Gallery...")
            val uri = withContext(Dispatchers.IO) { saveToMediaStore(context, tempFile, fileName) }
            tempFile.delete()
            if (uri != null) onProgress(1f, "Export complete — saved to Gallery.")
            uri
        } catch (e: Exception) {
            tempFile.delete()
            Log.e("VideoExporter", "Real export failed", e)
            onProgress(0f, "Export failed: ${e.message ?: "unknown error"}")
            null
        }
    }

    private fun buildEditedItem(clip: TimelineClipEntity, config: ExportConfig): EditedMediaItem {
        val mediaBuilder = MediaItem.Builder().setUri(Uri.parse(clip.mediaUri))
        if (clip.isVideo) {
            mediaBuilder.setClippingConfiguration(
                MediaItem.ClippingConfiguration.Builder()
                    .setStartPositionMs(clip.inMs.coerceAtLeast(0L))
                    .setEndPositionMs(clip.outMs.coerceAtLeast(clip.inMs + 1L))
                    .build()
            )
        }
        val baseMediaItem = mediaBuilder.build()

        val videoEffects = mutableListOf<androidx.media3.common.Effect>()
        videoEffects += VideoEffectEngine.buildEffects(clip)
        videoEffects += Presentation.createForHeight(config.resolutionHeight)

        val builder = EditedMediaItem.Builder(baseMediaItem)
            .setEffects(Effects(emptyList(), videoEffects))
            .setSpeed(constantSpeedProvider(clip.speed.coerceIn(0.1f, 4f)))
            .setFrameRate(config.fps)

        if (!clip.isVideo) {
            val durationUs = ((clip.outMs - clip.inMs).coerceAtLeast(100L) * 1000L)
            return builder.setDurationUs(durationUs).setRemoveAudio(true).build()
        }
        return builder.build()
    }

    private fun constantSpeedProvider(speed: Float): SpeedProvider = object : SpeedProvider {
        override fun getSpeed(presentationTimeUs: Long): Float = speed
        override fun getNextSpeedChangeTimeUs(timeUs: Long): Long = C.TIME_UNSET
    }

    private fun saveToMediaStore(context: Context, sourceFile: File, fileName: String): Uri? {
        val resolver = context.contentResolver
        val contentValues = ContentValues().apply {
            put(MediaStore.Video.Media.DISPLAY_NAME, fileName)
            put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
            put(MediaStore.Video.Media.DATE_ADDED, System.currentTimeMillis() / 1000)
            put(MediaStore.Video.Media.DATE_MODIFIED, System.currentTimeMillis() / 1000)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                put(MediaStore.Video.Media.RELATIVE_PATH, "${Environment.DIRECTORY_MOVIES}/NihaalCut")
                put(MediaStore.Video.Media.IS_PENDING, 1)
            }
        }

        val collection = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            MediaStore.Video.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
        } else {
            MediaStore.Video.Media.EXTERNAL_CONTENT_URI
        }

        val insertedUri = resolver.insert(collection, contentValues) ?: return null
        return try {
            resolver.openOutputStream(insertedUri)?.use { output ->
                sourceFile.inputStream().use { input -> input.copyTo(output) }
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val done = ContentValues().apply { put(MediaStore.Video.Media.IS_PENDING, 0) }
                resolver.update(insertedUri, done, null, null)
            }
            insertedUri
        } catch (e: Exception) {
            Log.e("VideoExporter", "MediaStore write failed", e)
            resolver.delete(insertedUri, null, null)
            null
        }
    }

    fun openVideoInGallery(context: Context, videoUri: Uri) {
        val intent = Intent(Intent.ACTION_VIEW).apply {
            setDataAndType(videoUri, "video/mp4")
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        try {
            context.startActivity(intent)
        } catch (e: Exception) {
            Log.w("VideoExporter", "Could not launch viewer: ${e.message}")
        }
    }
}
