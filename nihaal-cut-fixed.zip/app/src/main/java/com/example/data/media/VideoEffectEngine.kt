@file:OptIn(androidx.media3.common.util.UnstableApi::class)

package com.example.data.media

import android.graphics.Matrix
import androidx.media3.common.Effect
import androidx.media3.effect.Brightness
import androidx.media3.effect.Contrast
import androidx.media3.effect.GaussianBlur
import androidx.media3.effect.HslAdjustment
import androidx.media3.effect.MatrixTransformation
import androidx.media3.effect.RgbAdjustment
import androidx.media3.effect.ScaleAndRotateTransformation
import com.example.data.local.TimelineClipEntity
import kotlin.math.abs
import kotlin.math.sin

/**
 * Shared effect recipes for preview + export.
 *
 * The catalog contains 1500+ named presets, but the names are metadata rather than
 * 1500 bespoke shader implementations. This engine maps each preset to a deterministic
 * visual recipe so every catalog item has a real renderable result instead of being UI-only.
 */
object VideoEffectEngine {

    fun buildEffects(clip: TimelineClipEntity): List<Effect> = buildList {
        val durationMs = (clip.outMs - clip.inMs).coerceAtLeast(100L)

        if (clip.rotation != 0 || abs(clip.freeRotation) > 0.01f || clip.scale != 1f || clip.flipH || clip.flipV) {
            add(
                ScaleAndRotateTransformation.Builder()
                    .setRotationDegrees(clip.rotation + clip.freeRotation)
                    .setScale(
                        (if (clip.flipH) -1f else 1f) * clip.scale,
                        (if (clip.flipV) -1f else 1f) * clip.scale
                    )
                    .build()
            )
        }

        if (abs(clip.brightness - 1f) > 0.001f) {
            add(Brightness((clip.brightness - 1f).coerceIn(-1f, 1f)))
        }
        if (abs(clip.contrast - 1f) > 0.001f) {
            add(Contrast((clip.contrast - 1f).coerceIn(-1f, 1f)))
        }
        if (abs(clip.saturation - 1f) > 0.001f) {
            add(
                HslAdjustment.Builder()
                    .adjustSaturation(((clip.saturation - 1f) * 100f).coerceIn(-100f, 100f))
                    .build()
            )
        }
        if (abs(clip.temperature) > 0.01f || abs(clip.tint) > 0.01f) {
            add(
                RgbAdjustment.Builder()
                    .setRedScale((1f + clip.temperature * 0.28f + clip.tint * 0.08f).coerceAtLeast(0f))
                    .setGreenScale((1f + clip.temperature * 0.04f - clip.tint * 0.05f).coerceAtLeast(0f))
                    .setBlueScale((1f - clip.temperature * 0.28f + clip.tint * 0.08f).coerceAtLeast(0f))
                    .build()
            )
        }
        if (clip.blurRadius > 0.05f) {
            add(GaussianBlur(clip.blurRadius.coerceIn(0.1f, 40f)))
        }

        buildFilterRecipe(clip)?.let(::add)
        addAnimationRecipes(clip, durationMs).forEach(::add)
        addVfxRecipes(clip, durationMs).forEach(::add)
        clip.transitionName?.takeIf { it.isNotBlank() }?.let { transition ->
            val transitionDuration = clip.transitionDurationMs.coerceIn(80L, durationMs)
            if (transition.lowercase().contains("fade") || transition.lowercase().contains("dissolve") || transition.lowercase().contains("flash")) {
                add(TimedBrightness(transitionDuration) { t ->
                    -0.70f * (1f - (t / transitionDuration.toFloat()).coerceIn(0f, 1f))
                })
            } else {
                add(TimedTransform(durationMs, Mode.IN, transitionDuration, transition))
            }
        }
    }

    private fun buildFilterRecipe(clip: TimelineClipEntity): Effect? {
        val name = clip.filterName?.lowercase() ?: return null
        val strength = clip.filterIntensity.coerceIn(0f, 1f)
        if (strength <= 0f) return null

        return when {
            name.contains("b&w") || name.contains("black") || name.contains("mono") || name.contains("grayscale") ->
                HslAdjustment.Builder().adjustSaturation(-100f * strength).build()
            name.contains("warm") || name.contains("gold") || name.contains("sunset") || name.contains("orange") || name.contains("fire") ->
                RgbAdjustment.Builder()
                    .setRedScale(1f + 0.28f * strength)
                    .setGreenScale(1f + 0.10f * strength)
                    .setBlueScale(1f - 0.12f * strength)
                    .build()
            name.contains("cool") || name.contains("ice") || name.contains("blue") || name.contains("ocean") ->
                RgbAdjustment.Builder()
                    .setRedScale(1f - 0.12f * strength)
                    .setGreenScale(1f + 0.05f * strength)
                    .setBlueScale(1f + 0.28f * strength)
                    .build()
            name.contains("emerald") || name.contains("green") ->
                RgbAdjustment.Builder()
                    .setRedScale(1f - 0.10f * strength)
                    .setGreenScale(1f + 0.24f * strength)
                    .setBlueScale(1f + 0.04f * strength)
                    .build()
            name.contains("cyber") || name.contains("neon") || name.contains("magenta") ->
                RgbAdjustment.Builder()
                    .setRedScale(1f + 0.22f * strength)
                    .setGreenScale(1f - 0.06f * strength)
                    .setBlueScale(1f + 0.22f * strength)
                    .build()
            name.contains("vivid") || name.contains("cinematic") || name.contains("dramatic") ->
                Contrast((0.18f * strength).coerceIn(-1f, 1f))
            else -> null
        }
    }

    private fun addAnimationRecipes(clip: TimelineClipEntity, durationMs: Long): List<Effect> {
        val result = mutableListOf<Effect>()
        clip.inAnimation?.takeIf { it.isNotBlank() }?.let {
            result += TimedTransform(durationMs, Mode.IN, clip.inAnimDurationMs, it)
        }
        clip.outAnimation?.takeIf { it.isNotBlank() }?.let {
            result += TimedTransform(durationMs, Mode.OUT, clip.outAnimDurationMs, it)
        }
        clip.comboAnimation?.takeIf { it.isNotBlank() }?.let {
            result += TimedTransform(durationMs, Mode.COMBO, durationMs, it, clip.comboSpeed)
        }
        return result
    }

    private fun addVfxRecipes(clip: TimelineClipEntity, durationMs: Long): List<Effect> {
        val name = clip.effectName?.lowercase() ?: return emptyList()
        val strength = clip.vfxIntensity.coerceIn(0f, 1f)
        val result = mutableListOf<Effect>()

        when {
            name.contains("blur") || name.contains("dream") || name.contains("soft focus") ->
                result += GaussianBlur((2f + 14f * strength).coerceIn(0.1f, 40f))
            name.contains("glitch") || name.contains("chromatic") || name.contains("rgb") || name.contains("prism") || name.contains("aberration") -> {
                result += RgbAdjustment.Builder()
                    .setRedScale(1f + 0.14f * strength)
                    .setBlueScale(1f + 0.16f * strength)
                    .build()
                result += TimedTransform(durationMs, Mode.COMBO, durationMs, "glitch", clip.vfxSpeed)
            }
            name.contains("shake") || name.contains("whip") || name.contains("jitter") || name.contains("quake") ->
                result += TimedTransform(durationMs, Mode.COMBO, durationMs, "shake", clip.vfxSpeed)
            name.contains("zoom") || name.contains("pulse") || name.contains("zoom pulse") ->
                result += TimedTransform(durationMs, Mode.COMBO, durationMs, "pulse", clip.vfxSpeed)
            name.contains("flash") || name.contains("strobe") || name.contains("flicker") ->
                result += TimedBrightness(durationMs) { t ->
                    val wave = ((sin(t / 1000f * clip.vfxSpeed * 18f) + 1f) / 2f)
                    wave * 0.30f * strength
                }
            name.contains("vhs") || name.contains("crt") || name.contains("old tv") || name.contains("scanline") || name.contains("film") || name.contains("tape") -> {
                result += Contrast((0.12f * strength).coerceIn(-1f, 1f))
                result += RgbAdjustment.Builder()
                    .setRedScale(1f + 0.05f * strength)
                    .setBlueScale(1f - 0.05f * strength)
                    .build()
            }
            name.contains("light") || name.contains("leak") || name.contains("glow") || name.contains("bloom") || name.contains("neon") ->
                result += RgbAdjustment.Builder()
                    .setRedScale(1f + 0.18f * strength)
                    .setGreenScale(1f + 0.06f * strength)
                    .build()
            name.contains("fire") || name.contains("ember") || name.contains("burn") ->
                result += RgbAdjustment.Builder()
                    .setRedScale(1f + 0.26f * strength)
                    .setGreenScale(1f + 0.10f * strength)
                    .setBlueScale(1f - 0.10f * strength)
                    .build()
            name.contains("ice") || name.contains("frost") || name.contains("snow") ->
                result += RgbAdjustment.Builder()
                    .setRedScale(1f - 0.12f * strength)
                    .setBlueScale(1f + 0.25f * strength)
                    .build()
            else -> {
                result += Contrast((0.08f * strength).coerceIn(-1f, 1f))
                result += TimedTransform(durationMs, Mode.COMBO, durationMs, name, clip.vfxSpeed)
            }
        }
        return result
    }

    private enum class Mode { IN, OUT, COMBO }

    private class TimedTransform(
        private val durationMs: Long,
        private val mode: Mode,
        private val activeDurationMs: Long,
        private val rawName: String,
        private val speed: Float = 1f
    ) : MatrixTransformation {
        private val name = rawName.lowercase()

        override fun getMatrix(presentationTimeUs: Long): Matrix {
            val t = (presentationTimeUs / 1000L).coerceIn(0L, durationMs)
            val active = activeDurationMs.coerceAtLeast(60L)
            val p = when (mode) {
                Mode.IN -> ease((t.toFloat() / active).coerceIn(0f, 1f))
                Mode.OUT -> ease(((durationMs - t).toFloat() / active).coerceIn(0f, 1f))
                Mode.COMBO -> ((t / 1000f) * speed).let { ((sin(it * 2.0f * Math.PI.toFloat()) + 1f) / 2f) }
            }

            var scale = 1f
            var rotation = 0f
            var tx = 0f
            var ty = 0f

            when {
                name.contains("shake") || name.contains("jitter") || name.contains("quake") -> {
                    val a = 0.045f
                    tx = sin(t / 1000f * speed * 26f) * a
                    ty = sin(t / 1000f * speed * 31f + 0.7f) * a
                }
                name.contains("slide") || name.contains("push") || name.contains("glide") || name.contains("swipe") || name.contains("panel") -> {
                    val dx = when {
                        name.contains("left") -> -1f
                        name.contains("right") -> 1f
                        else -> 0f
                    }
                    val dy = when {
                        name.contains("up") -> -1f
                        name.contains("down") -> 1f
                        else -> 0f
                    }
                    if (mode == Mode.IN) {
                        tx = dx * (1f - p) * 0.95f
                        ty = dy * (1f - p) * 0.95f
                    } else if (mode == Mode.OUT) {
                        tx = dx * p * 0.95f
                        ty = dy * p * 0.95f
                    }
                }
                name.contains("spin") || name.contains("rotate") || name.contains("twirl") || name.contains("spiral") -> {
                    rotation = if (mode == Mode.OUT) p * 24f else (1f - p) * -24f
                    if (name.contains("vortex")) rotation *= 3f
                }
                name.contains("zoom") || name.contains("scale") || name.contains("pop") || name.contains("bounce") || name.contains("pulse") || name.contains("squeeze") -> {
                    when (mode) {
                        Mode.IN -> scale = when {
                            name.contains("bounce") || name.contains("elastic") -> 1f + 0.16f * sin(p * Math.PI.toFloat())
                            else -> 1.28f - 0.28f * p
                        }
                        Mode.OUT -> scale = when {
                            name.contains("bounce") || name.contains("elastic") -> 1f + 0.12f * sin(p * Math.PI.toFloat())
                            else -> 1f - 0.20f * p
                        }
                        Mode.COMBO -> scale = 1f + 0.08f * sin(t / 1000f * speed * 6f)
                    }
                }
                name.contains("pendulum") || name.contains("wobble") || name.contains("float") -> {
                    rotation = sin(t / 1000f * speed * 3f) * 6f
                    ty = sin(t / 1000f * speed * 2f) * 0.035f
                }
                name.contains("heartbeat") || name.contains("breathe") -> {
                    scale = 1f + 0.055f * sin(t / 1000f * speed * 4f)
                }
                name.contains("glitch") || name.contains("distort") -> {
                    tx = sin(t / 1000f * speed * 43f) * 0.025f
                    ty = sin(t / 1000f * speed * 37f) * 0.018f
                    rotation = sin(t / 1000f * speed * 19f) * 1.2f
                }
                name.contains("fade") -> {
                    // Brightness fade is layered separately; keep the matrix neutral.
                }
                else -> {
                    scale = 1f + 0.025f * sin(t / 1000f * speed * 2f)
                }
            }

            return Matrix().apply {
                postScale(scale, scale)
                postRotate(rotation)
                postTranslate(tx, ty)
            }
        }

        private fun ease(x: Float): Float = x * x * (3f - 2f * x)
    }

    private class TimedBrightness(
        private val durationMs: Long,
        private val valueAt: (Float) -> Float
    ) : androidx.media3.effect.RgbMatrix {
        override fun getMatrix(presentationTimeUs: Long, useHdr: Boolean): FloatArray {
            val t = (presentationTimeUs / 1000L).coerceIn(0L, durationMs).toFloat()
            return Brightness(valueAt(t)).getMatrix(presentationTimeUs, useHdr)
        }
    }
}
