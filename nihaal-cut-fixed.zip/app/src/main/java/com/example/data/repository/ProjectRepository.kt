package com.example.data.repository

import com.example.data.local.ProjectDao
import com.example.data.local.ProjectEntity
import com.example.data.local.TextLayerEntity
import com.example.data.local.TimelineClipEntity
import kotlinx.coroutines.flow.Flow

class ProjectRepository(private val projectDao: ProjectDao) {
    val allProjects: Flow<List<ProjectEntity>> = projectDao.getAllProjects()

    fun getProject(id: String): Flow<ProjectEntity?> = projectDao.getProjectById(id)

    fun getClips(projectId: String): Flow<List<TimelineClipEntity>> =
        projectDao.getClipsForProject(projectId)

    fun getTextLayers(projectId: String): Flow<List<TextLayerEntity>> =
        projectDao.getTextLayersForProject(projectId)

    suspend fun saveProject(project: ProjectEntity) {
        projectDao.insertProject(project)
    }

    suspend fun saveProjectWithClips(project: ProjectEntity, clips: List<TimelineClipEntity>) {
        projectDao.insertProject(project)
        projectDao.deleteClipsForProject(project.id)
        if (clips.isNotEmpty()) {
            projectDao.insertClips(clips)
        }
    }

    suspend fun saveTextLayers(projectId: String, layers: List<TextLayerEntity>) {
        projectDao.deleteTextLayersForProject(projectId)
        if (layers.isNotEmpty()) {
            projectDao.insertTextLayers(layers)
        }
    }

    suspend fun deleteProject(id: String) {
        projectDao.deleteTextLayersForProject(id)
        projectDao.deleteClipsForProject(id)
        projectDao.deleteProjectById(id)
    }
}
