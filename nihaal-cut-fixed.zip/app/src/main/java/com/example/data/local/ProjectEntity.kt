package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "projects")
data class ProjectEntity(
    @PrimaryKey val id: String,
    val name: String,
    val createdAt: Long = System.currentTimeMillis(),
    val modifiedAt: Long = System.currentTimeMillis(),
    val aspectPreset: String = "9:16",
    val canvasWidth: Int = 1080,
    val canvasHeight: Int = 1920,
    val fps: Int = 30,
    val durationMs: Long = 0L,
    val clipCount: Int = 0,
    val thumbnailUri: String? = null,
    val isDraft: Boolean = true
)

@Entity(tableName = "timeline_clips")
data class TimelineClipEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0L,
    val projectId: String,
    val orderIndex: Int,
    val mediaUri: String,
    val mediaName: String,
    val isVideo: Boolean,
    val inMs: Long,
    val outMs: Long,
    val originalDurationMs: Long,
    val speed: Float = 1.0f,
    val volume: Float = 1.0f,
    val brightness: Float = 1.0f,
    val contrast: Float = 1.0f,
    val saturation: Float = 1.0f,
    val temperature: Float = 0.0f,
    val tint: Float = 0.0f,
    val highlights: Float = 0.0f,
    val shadows: Float = 0.0f,
    val blurRadius: Float = 0.0f,
    val vignette: Float = 0.0f,
    val grain: Float = 0.0f,
    val sharpness: Float = 0.0f,
    val rotation: Int = 0,
    val freeRotation: Float = 0f,
    val flipH: Boolean = false,
    val flipV: Boolean = false,
    val scale: Float = 1.0f,
    val transX: Float = 0f,
    val transY: Float = 0f,
    val fadeInSec: Float = 0f,
    val fadeOutSec: Float = 0f,
    val fitMode: String = "contain",
    val cropRatio: String? = null,
    val speedCurve: String? = null,
    val filterName: String? = null,
    val filterIntensity: Float = 1.0f,
    val effectName: String? = null,
    val vfxIntensity: Float = 1.0f,
    val vfxSpeed: Float = 1.0f,
    val inAnimation: String? = null,
    val inAnimDurationMs: Long = 600L,
    val outAnimation: String? = null,
    val outAnimDurationMs: Long = 600L,
    val comboAnimation: String? = null,
    val comboSpeed: Float = 1.0f,
    val transitionName: String? = null,
    val transitionDurationMs: Long = 600L
)

@Entity(tableName = "text_layers")
data class TextLayerEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0L,
    val projectId: String,
    val text: String,
    val startTimeMs: Long,
    val durationMs: Long = 3000L,
    val posX: Float = 0.5f,
    val posY: Float = 0.75f,
    val scale: Float = 1.0f,
    val stylePreset: String = "Classic",
    val textColor: Long = 0xFFFFFFFF,
    val animType: String = "pop"
)
