package com.example.data.model

object SampleMediaProvider {
    val sampleVideos = listOf(
        MediaItem(
            id = "sample_vid_1",
            uri = "sample://drone_city",
            name = "Cyberpunk City Sunset",
            isVideo = true,
            durationMs = 8500L,
            width = 1080,
            height = 1920,
            thumbnailUri = "https://images.unsplash.com/photo-1514565131-fce0801e5785?w=500&auto=format&fit=crop&q=60"
        ),
        MediaItem(
            id = "sample_vid_2",
            uri = "sample://neon_drive",
            name = "Neon Highway Timelapse",
            isVideo = true,
            durationMs = 6200L,
            width = 1080,
            height = 1920,
            thumbnailUri = "https://images.unsplash.com/photo-1509198397868-475647b2a1e5?w=500&auto=format&fit=crop&q=60"
        ),
        MediaItem(
            id = "sample_vid_3",
            uri = "sample://nature_falls",
            name = "Misty Mountain Falls",
            isVideo = true,
            durationMs = 7400L,
            width = 1080,
            height = 1920,
            thumbnailUri = "https://images.unsplash.com/photo-1432405972618-c60b0225b8f9?w=500&auto=format&fit=crop&q=60"
        ),
        MediaItem(
            id = "sample_vid_4",
            uri = "sample://urban_dance",
            name = "Street Dance Rhythm",
            isVideo = true,
            durationMs = 5800L,
            width = 1080,
            height = 1920,
            thumbnailUri = "https://images.unsplash.com/photo-1508700115892-45ecd05ae2ad?w=500&auto=format&fit=crop&q=60"
        )
    )

    val samplePhotos = listOf(
        MediaItem(
            id = "sample_img_1",
            uri = "sample://portrait_glow",
            name = "Portrait Neon Glow",
            isVideo = false,
            durationMs = 3000L,
            width = 1080,
            height = 1920,
            thumbnailUri = "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=500&auto=format&fit=crop&q=60"
        ),
        MediaItem(
            id = "sample_img_2",
            uri = "sample://retro_car",
            name = "Vintage Crimson Ride",
            isVideo = false,
            durationMs = 3000L,
            width = 1080,
            height = 1350,
            thumbnailUri = "https://images.unsplash.com/photo-1552519507-da3b142c6e3d?w=500&auto=format&fit=crop&q=60"
        ),
        MediaItem(
            id = "sample_img_3",
            uri = "sample://architecture_minimal",
            name = "Minimal Geometry",
            isVideo = false,
            durationMs = 3000L,
            width = 1080,
            height = 1080,
            thumbnailUri = "https://images.unsplash.com/photo-1513694203232-719a280e022f?w=500&auto=format&fit=crop&q=60"
        )
    )
}
