package com.example

import com.example.data.catalog.AnimationCatalog
import com.example.data.catalog.TransitionCatalog
import com.example.data.catalog.VfxCatalog
import org.junit.Assert.assertEquals
import org.junit.Test

class CatalogIntegrityTest {
    @Test fun catalogSizesStayIntact() {
        assertEquals(510, AnimationCatalog.allAnimations.size)
        assertEquals(525, TransitionCatalog.allTransitions.size)
        assertEquals(505, VfxCatalog.allVfx.size)
    }
}
