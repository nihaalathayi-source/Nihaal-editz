# Nihaal Cut — Engineering Audit & Fix Log

## What was broken

- Export generated a synthetic dark MP4 and ignored the timeline source clips.
- Export progress/status messages claimed shaders, transitions and audio compositing that were not actually happening.
- Video preview used Coil image loading instead of a real media player.
- Device videos were all assigned a hard-coded 5-second duration.
- Animation/VFX UI stored human-readable catalog names while the preview engine only recognized a few internal keys, so most 500+ entries had no visual effect.
- VFX color-grade selections were stored in `filterName` but the dialog read `effectName`, so selection state could disappear; slider/apply callbacks also reset the color-grade flag.
- The preview transform block contained a duplicate `rotationZ` assignment.

## Fixes applied

- Added AndroidX Media3 1.11.1 ExoPlayer + Transformer + Effect dependencies.
- Replaced the fake frame encoder with a real Media3 Transformer export pipeline using the actual timeline URIs, clip trimming, per-clip speed, filters/effects, and Gallery/MediaStore output.
- Added a real ExoPlayer-based editor preview for imported video clips with per-clip Media3 video effects.
- Preview/timeline playback speed now follows the active clip speed.
- Added shared name-driven effect recipes so every catalog preset maps to a deterministic renderable family rather than only a handful of hard-coded keys.
- Added transition recipes so all catalog transition names at least produce a real visual transformation family; bespoke 1:1 shader assets are not falsely claimed.
- Fixed VFX color-grade state and slider behavior.
- Device media import now detects whether the URI is video/photo and reads the real video duration asynchronously.

## Catalog inventory

The supplied project already contains the requested catalog-scale data:

- Animations: 510 total (180 IN + 150 OUT + 180 COMBO)
- Transitions: 525 total
- VFX: 505 total (including color grades)
- Combined: 1,540 named catalog entries

## Important limitation

This project still does **not** contain 1,540 bespoke GPU shader/asset implementations. The catalog is now wired to reusable render recipes by keyword/category so the presets actually do something without pretending that every named preset is a unique shader. A future phase can add dedicated shader/texture assets for specific marquee effects.

## Verification

Static audit and source-level patching were completed. The supplied ZIP did not contain a Gradle wrapper script/JAR and this environment does not have a system Gradle executable, so a full Android Studio/Gradle build could not be executed here.
